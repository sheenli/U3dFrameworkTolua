---@class UnityEngine.TizenActivityIndicatorStyle : System.Enum
---@field public DontShow UnityEngine.TizenActivityIndicatorStyle @static
---@field public Large UnityEngine.TizenActivityIndicatorStyle @static
---@field public InversedLarge UnityEngine.TizenActivityIndicatorStyle @static
---@field public Small UnityEngine.TizenActivityIndicatorStyle @static
---@field public InversedSmall UnityEngine.TizenActivityIndicatorStyle @static
---@field public value__ number
local m = {}

UnityEngine.TizenActivityIndicatorStyle = m
return m
