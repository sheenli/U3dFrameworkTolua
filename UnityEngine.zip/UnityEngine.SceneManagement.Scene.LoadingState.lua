---@class UnityEngine.SceneManagement.Scene.LoadingState : System.Enum
---@field public NotLoaded UnityEngine.SceneManagement.Scene.LoadingState @static
---@field public Loading UnityEngine.SceneManagement.Scene.LoadingState @static
---@field public Loaded UnityEngine.SceneManagement.Scene.LoadingState @static
---@field public value__ number
local m = {}

UnityEngine.SceneManagement.Scene.LoadingState = m
return m
