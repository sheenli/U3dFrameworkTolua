---@class UnityEngine.ParticleSystemTriggerEventType : System.Enum
---@field public Inside UnityEngine.ParticleSystemTriggerEventType @static
---@field public Outside UnityEngine.ParticleSystemTriggerEventType @static
---@field public Enter UnityEngine.ParticleSystemTriggerEventType @static
---@field public Exit UnityEngine.ParticleSystemTriggerEventType @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemTriggerEventType = m
return m
