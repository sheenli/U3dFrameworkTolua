---@class UnityEngine.RenderTexture : UnityEngine.Texture
---@field public active UnityEngine.RenderTexture @static
---@field public enabled boolean @static
---@field public width number
---@field public height number
---@field public depth number
---@field public isPowerOfTwo boolean
---@field public sRGB boolean
---@field public format UnityEngine.RenderTextureFormat
---@field public useMipMap boolean
---@field public autoGenerateMips boolean
---@field public dimension UnityEngine.Rendering.TextureDimension
---@field public isCubemap boolean
---@field public isVolume boolean
---@field public volumeDepth number
---@field public antiAliasing number
---@field public enableRandomWrite boolean
---@field public colorBuffer UnityEngine.RenderBuffer
---@field public depthBuffer UnityEngine.RenderBuffer
---@field public generateMips boolean
local m = {}

---@overload fun(width:number, height:number, depthBuffer:number, format:UnityEngine.RenderTextureFormat, readWrite:UnityEngine.RenderTextureReadWrite):UnityEngine.RenderTexture @static
---@overload fun(width:number, height:number, depthBuffer:number, format:UnityEngine.RenderTextureFormat):UnityEngine.RenderTexture @static
---@overload fun(width:number, height:number, depthBuffer:number):UnityEngine.RenderTexture @static
---@overload fun(width:number, height:number):UnityEngine.RenderTexture @static
---@static
---@param width number
---@param height number
---@param depthBuffer number
---@param format UnityEngine.RenderTextureFormat
---@param readWrite UnityEngine.RenderTextureReadWrite
---@param antiAliasing number
---@return UnityEngine.RenderTexture
function m.GetTemporary(width, height, depthBuffer, format, readWrite, antiAliasing) end

---@static
---@param temp UnityEngine.RenderTexture
function m.ReleaseTemporary(temp) end

---@return boolean
function m:Create() end

function m:Release() end

---@return boolean
function m:IsCreated() end

---@overload fun(discardColor:boolean, discardDepth:boolean)
function m:DiscardContents() end

function m:MarkRestoreExpected() end

function m:GenerateMips() end

---@return System.IntPtr
function m:GetNativeDepthBufferPtr() end

---@param propertyName string
function m:SetGlobalShaderProperty(propertyName) end

---@return UnityEngine.Vector2
function m:GetTexelOffset() end

---@static
---@param rt UnityEngine.RenderTexture
---@return boolean
function m.SupportsStencil(rt) end

---@param color UnityEngine.Color
function m:SetBorderColor(color) end

UnityEngine.RenderTexture = m
return m
