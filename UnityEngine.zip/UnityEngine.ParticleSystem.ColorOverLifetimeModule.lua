---@class UnityEngine.ParticleSystem.ColorOverLifetimeModule : System.ValueType
---@field public enabled boolean
---@field public color UnityEngine.ParticleSystem.MinMaxGradient
local m = {}

UnityEngine.ParticleSystem.ColorOverLifetimeModule = m
return m
