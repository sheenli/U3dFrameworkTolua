---@class UnityEngine.Apple.TV.Remote : System.Object
---@field public allowExitToHome boolean @static
---@field public allowRemoteRotation boolean @static
---@field public reportAbsoluteDpadValues boolean @static
---@field public touchesEnabled boolean @static
local m = {}

UnityEngine.Apple.TV.Remote = m
return m
