---@class UnityEngine.ParticleSystemScalingMode : System.Enum
---@field public Hierarchy UnityEngine.ParticleSystemScalingMode @static
---@field public Local UnityEngine.ParticleSystemScalingMode @static
---@field public Shape UnityEngine.ParticleSystemScalingMode @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemScalingMode = m
return m
