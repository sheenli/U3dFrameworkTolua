---@class UnityEngine.ParticleCollisionEvent : System.ValueType
---@field public intersection UnityEngine.Vector3
---@field public normal UnityEngine.Vector3
---@field public velocity UnityEngine.Vector3
---@field public collider UnityEngine.Component
---@field public colliderComponent UnityEngine.Component
local m = {}

UnityEngine.ParticleCollisionEvent = m
return m
