---@class UnityEngine.LightProbes : UnityEngine.Object
---@field public positions UnityEngine.Vector3[]
---@field public bakedProbes UnityEngine.Rendering.SphericalHarmonicsL2[]
---@field public count number
---@field public cellCount number
---@field public coefficients number[]
local m = {}

---@static
---@param position UnityEngine.Vector3
---@param renderer UnityEngine.Renderer
---@return UnityEngine.Rendering.SphericalHarmonicsL2
function m.GetInterpolatedProbe(position, renderer) end

---@param position UnityEngine.Vector3
---@param renderer UnityEngine.Renderer
---@param coefficients number[]
function m:GetInterpolatedLightProbe(position, renderer, coefficients) end

UnityEngine.LightProbes = m
return m
