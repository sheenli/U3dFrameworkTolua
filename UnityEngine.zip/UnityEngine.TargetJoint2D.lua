---@class UnityEngine.TargetJoint2D : UnityEngine.Joint2D
---@field public anchor UnityEngine.Vector2
---@field public target UnityEngine.Vector2
---@field public autoConfigureTarget boolean
---@field public maxForce number
---@field public dampingRatio number
---@field public frequency number
local m = {}

UnityEngine.TargetJoint2D = m
return m
