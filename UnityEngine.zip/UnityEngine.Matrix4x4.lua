---@class UnityEngine.Matrix4x4 : System.ValueType
---@field public zero UnityEngine.Matrix4x4 @static
---@field public identity UnityEngine.Matrix4x4 @static
---@field public m00 number
---@field public m10 number
---@field public m20 number
---@field public m30 number
---@field public m01 number
---@field public m11 number
---@field public m21 number
---@field public m31 number
---@field public m02 number
---@field public m12 number
---@field public m22 number
---@field public m32 number
---@field public m03 number
---@field public m13 number
---@field public m23 number
---@field public m33 number
---@field public inverse UnityEngine.Matrix4x4
---@field public transpose UnityEngine.Matrix4x4
---@field public isIdentity boolean
---@field public determinant number
---@field public Item number
---@field public Item number
local m = {}

---@static
---@param m UnityEngine.Matrix4x4
---@return UnityEngine.Matrix4x4
function m.Inverse(m) end

---@static
---@param m UnityEngine.Matrix4x4
---@return UnityEngine.Matrix4x4
function m.Transpose(m) end

---@static
---@param m UnityEngine.Matrix4x4
---@return number
function m.Determinant(m) end

---@param pos UnityEngine.Vector3
---@param q UnityEngine.Quaternion
---@param s UnityEngine.Vector3
function m:SetTRS(pos, q, s) end

---@static
---@param pos UnityEngine.Vector3
---@param q UnityEngine.Quaternion
---@param s UnityEngine.Vector3
---@return UnityEngine.Matrix4x4
function m.TRS(pos, q, s) end

---@static
---@param left number
---@param right number
---@param bottom number
---@param top number
---@param zNear number
---@param zFar number
---@return UnityEngine.Matrix4x4
function m.Ortho(left, right, bottom, top, zNear, zFar) end

---@static
---@param fov number
---@param aspect number
---@param zNear number
---@param zFar number
---@return UnityEngine.Matrix4x4
function m.Perspective(fov, aspect, zNear, zFar) end

---@static
---@param from UnityEngine.Vector3
---@param to UnityEngine.Vector3
---@param up UnityEngine.Vector3
---@return UnityEngine.Matrix4x4
function m.LookAt(from, to, up) end

---@virtual
---@return number
function m:GetHashCode() end

---@virtual
---@param other any
---@return boolean
function m:Equals(other) end

---@overload fun(lhs:UnityEngine.Matrix4x4, v:UnityEngine.Vector4):UnityEngine.Vector4 @static
---@static
---@param lhs UnityEngine.Matrix4x4
---@param rhs UnityEngine.Matrix4x4
---@return UnityEngine.Matrix4x4
function m.op_Multiply(lhs, rhs) end

---@static
---@param lhs UnityEngine.Matrix4x4
---@param rhs UnityEngine.Matrix4x4
---@return boolean
function m.op_Equality(lhs, rhs) end

---@static
---@param lhs UnityEngine.Matrix4x4
---@param rhs UnityEngine.Matrix4x4
---@return boolean
function m.op_Inequality(lhs, rhs) end

---@param i number
---@return UnityEngine.Vector4
function m:GetColumn(i) end

---@param i number
---@return UnityEngine.Vector4
function m:GetRow(i) end

---@param i number
---@param v UnityEngine.Vector4
function m:SetColumn(i, v) end

---@param i number
---@param v UnityEngine.Vector4
function m:SetRow(i, v) end

---@param v UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:MultiplyPoint(v) end

---@param v UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:MultiplyPoint3x4(v) end

---@param v UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:MultiplyVector(v) end

---@static
---@param v UnityEngine.Vector3
---@return UnityEngine.Matrix4x4
function m.Scale(v) end

---@static
---@param v UnityEngine.Vector3
---@return UnityEngine.Matrix4x4
function m.Translate(v) end

---@overload fun(format:string):string
---@virtual
---@return string
function m:ToString() end

UnityEngine.Matrix4x4 = m
return m
