---@class UnityEngine.ParticleSystem.MinMaxCurve : System.ValueType
---@field public mode UnityEngine.ParticleSystemCurveMode
---@field public curveScalar number
---@field public curveMultiplier number
---@field public curveMax UnityEngine.AnimationCurve
---@field public curveMin UnityEngine.AnimationCurve
---@field public constantMax number
---@field public constantMin number
---@field public constant number
---@field public curve UnityEngine.AnimationCurve
local m = {}

---@overload fun(time:number, lerpFactor:number):number
---@param time number
---@return number
function m:Evaluate(time) end

---@static
---@param constant number
---@return UnityEngine.ParticleSystem.MinMaxCurve
function m.op_Implicit(constant) end

UnityEngine.ParticleSystem.MinMaxCurve = m
return m
