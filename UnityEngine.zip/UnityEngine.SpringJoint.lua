---@class UnityEngine.SpringJoint : UnityEngine.Joint
---@field public spring number
---@field public damper number
---@field public minDistance number
---@field public maxDistance number
---@field public tolerance number
local m = {}

UnityEngine.SpringJoint = m
return m
