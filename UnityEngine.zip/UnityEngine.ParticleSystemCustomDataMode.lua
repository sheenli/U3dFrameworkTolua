---@class UnityEngine.ParticleSystemCustomDataMode : System.Enum
---@field public Disabled UnityEngine.ParticleSystemCustomDataMode @static
---@field public Vector UnityEngine.ParticleSystemCustomDataMode @static
---@field public Color UnityEngine.ParticleSystemCustomDataMode @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemCustomDataMode = m
return m
