---@class UnityEngine.AssetBundle : UnityEngine.Object
---@field public mainAsset UnityEngine.Object
---@field public isStreamedSceneAssetBundle boolean
local m = {}

---@overload fun(path:string, crc:number):UnityEngine.AssetBundleCreateRequest @static
---@overload fun(path:string):UnityEngine.AssetBundleCreateRequest @static
---@static
---@param path string
---@param crc number
---@param offset number
---@return UnityEngine.AssetBundleCreateRequest
function m.LoadFromFileAsync(path, crc, offset) end

---@overload fun(path:string, crc:number):UnityEngine.AssetBundle @static
---@overload fun(path:string):UnityEngine.AssetBundle @static
---@static
---@param path string
---@param crc number
---@param offset number
---@return UnityEngine.AssetBundle
function m.LoadFromFile(path, crc, offset) end

---@overload fun(binary:string):UnityEngine.AssetBundleCreateRequest @static
---@static
---@param binary string
---@param crc number
---@return UnityEngine.AssetBundleCreateRequest
function m.LoadFromMemoryAsync(binary, crc) end

---@overload fun(binary:string):UnityEngine.AssetBundle @static
---@static
---@param binary string
---@param crc number
---@return UnityEngine.AssetBundle
function m.LoadFromMemory(binary, crc) end

---@param name string
---@return boolean
function m:Contains(name) end

---@overload fun(name:string):UnityEngine.Object
---@overload fun(name:string, type:System.Type):UnityEngine.Object
---@param name string
---@return UnityEngine.Object
function m:Load(name) end

---@param name string
---@param type System.Type
---@return UnityEngine.AssetBundleRequest
function m:LoadAsync(name, type) end

---@overload fun():UnityEngine.Object[]
---@overload fun():UnityEngine.Object[]
---@param type System.Type
---@return UnityEngine.Object[]
function m:LoadAll(type) end

---@overload fun(name:string):UnityEngine.Object
---@overload fun(name:string, type:System.Type):UnityEngine.Object
---@param name string
---@return UnityEngine.Object
function m:LoadAsset(name) end

---@overload fun(name:string):UnityEngine.AssetBundleRequest
---@overload fun(name:string, type:System.Type):UnityEngine.AssetBundleRequest
---@param name string
---@return UnityEngine.AssetBundleRequest
function m:LoadAssetAsync(name) end

---@overload fun(name:string):UnityEngine.Object[]
---@overload fun(name:string, type:System.Type):UnityEngine.Object[]
---@param name string
---@return UnityEngine.Object[]
function m:LoadAssetWithSubAssets(name) end

---@overload fun(name:string):UnityEngine.AssetBundleRequest
---@overload fun(name:string, type:System.Type):UnityEngine.AssetBundleRequest
---@param name string
---@return UnityEngine.AssetBundleRequest
function m:LoadAssetWithSubAssetsAsync(name) end

---@overload fun():UnityEngine.Object[]
---@overload fun(type:System.Type):UnityEngine.Object[]
---@return UnityEngine.Object[]
function m:LoadAllAssets() end

---@overload fun():UnityEngine.AssetBundleRequest
---@overload fun(type:System.Type):UnityEngine.AssetBundleRequest
---@return UnityEngine.AssetBundleRequest
function m:LoadAllAssetsAsync() end

---@param unloadAllLoadedObjects boolean
function m:Unload(unloadAllLoadedObjects) end

---@return string[]
function m:AllAssetNames() end

---@return string[]
function m:GetAllAssetNames() end

---@return string[]
function m:GetAllScenePaths() end

---@static
---@param path string
---@return UnityEngine.AssetBundle
function m.CreateFromFile(path) end

---@static
---@param binary string
---@return UnityEngine.AssetBundleCreateRequest
function m.CreateFromMemory(binary) end

---@static
---@param binary string
---@return UnityEngine.AssetBundle
function m.CreateFromMemoryImmediate(binary) end

UnityEngine.AssetBundle = m
return m
