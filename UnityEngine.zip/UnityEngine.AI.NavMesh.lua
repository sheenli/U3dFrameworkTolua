---@class UnityEngine.AI.NavMesh : System.Object
---@field public onPreUpdate fun() @static
---@field public AllAreas number @static
---@field public avoidancePredictionTime number @static
---@field public pathfindingIterationsPerFrame number @static
local m = {}

---@overload fun(sourcePosition:UnityEngine.Vector3, targetPosition:UnityEngine.Vector3, filter:UnityEngine.AI.NavMeshQueryFilter):boolean, UnityEngine.AI.NavMeshHit @static
---@static
---@param sourcePosition UnityEngine.Vector3
---@param targetPosition UnityEngine.Vector3
---@param areaMask number
---@return boolean, UnityEngine.AI.NavMeshHit
function m.Raycast(sourcePosition, targetPosition, areaMask) end

---@overload fun(sourcePosition:UnityEngine.Vector3, targetPosition:UnityEngine.Vector3, filter:UnityEngine.AI.NavMeshQueryFilter, path:UnityEngine.AI.NavMeshPath):boolean @static
---@static
---@param sourcePosition UnityEngine.Vector3
---@param targetPosition UnityEngine.Vector3
---@param areaMask number
---@param path UnityEngine.AI.NavMeshPath
---@return boolean
function m.CalculatePath(sourcePosition, targetPosition, areaMask, path) end

---@overload fun(sourcePosition:UnityEngine.Vector3, filter:UnityEngine.AI.NavMeshQueryFilter):boolean, UnityEngine.AI.NavMeshHit @static
---@static
---@param sourcePosition UnityEngine.Vector3
---@param areaMask number
---@return boolean, UnityEngine.AI.NavMeshHit
function m.FindClosestEdge(sourcePosition, areaMask) end

---@overload fun(sourcePosition:UnityEngine.Vector3, maxDistance:number, filter:UnityEngine.AI.NavMeshQueryFilter):boolean, UnityEngine.AI.NavMeshHit @static
---@static
---@param sourcePosition UnityEngine.Vector3
---@param maxDistance number
---@param areaMask number
---@return boolean, UnityEngine.AI.NavMeshHit
function m.SamplePosition(sourcePosition, maxDistance, areaMask) end

---@static
---@param layer number
---@param cost number
function m.SetLayerCost(layer, cost) end

---@static
---@param layer number
---@return number
function m.GetLayerCost(layer) end

---@static
---@param layerName string
---@return number
function m.GetNavMeshLayerFromName(layerName) end

---@static
---@param areaIndex number
---@param cost number
function m.SetAreaCost(areaIndex, cost) end

---@static
---@param areaIndex number
---@return number
function m.GetAreaCost(areaIndex) end

---@static
---@param areaName string
---@return number
function m.GetAreaFromName(areaName) end

---@static
---@return UnityEngine.AI.NavMeshTriangulation
function m.CalculateTriangulation() end

---@static
---@return UnityEngine.Vector3__, System.Int32__
function m.Triangulate() end

---@static
function m.AddOffMeshLinks() end

---@static
function m.RestoreNavMesh() end

---@overload fun(navMeshData:UnityEngine.AI.NavMeshData, position:UnityEngine.Vector3, rotation:UnityEngine.Quaternion):UnityEngine.AI.NavMeshDataInstance @static
---@static
---@param navMeshData UnityEngine.AI.NavMeshData
---@return UnityEngine.AI.NavMeshDataInstance
function m.AddNavMeshData(navMeshData) end

---@static
---@param handle UnityEngine.AI.NavMeshDataInstance
function m.RemoveNavMeshData(handle) end

---@overload fun(link:UnityEngine.AI.NavMeshLinkData, position:UnityEngine.Vector3, rotation:UnityEngine.Quaternion):UnityEngine.AI.NavMeshLinkInstance @static
---@static
---@param link UnityEngine.AI.NavMeshLinkData
---@return UnityEngine.AI.NavMeshLinkInstance
function m.AddLink(link) end

---@static
---@param handle UnityEngine.AI.NavMeshLinkInstance
function m.RemoveLink(handle) end

---@static
---@return UnityEngine.AI.NavMeshBuildSettings
function m.CreateSettings() end

---@static
---@param agentTypeID number
function m.RemoveSettings(agentTypeID) end

---@static
---@param agentTypeID number
---@return UnityEngine.AI.NavMeshBuildSettings
function m.GetSettingsByID(agentTypeID) end

---@static
---@return number
function m.GetSettingsCount() end

---@static
---@param index number
---@return UnityEngine.AI.NavMeshBuildSettings
function m.GetSettingsByIndex(index) end

---@static
---@param agentTypeID number
---@return string
function m.GetSettingsNameFromID(agentTypeID) end

UnityEngine.AI.NavMesh = m
return m
