---@class UnityEngine.LightProbeGroup : UnityEngine.Behaviour
---@field public probePositions UnityEngine.Vector3[]
local m = {}

UnityEngine.LightProbeGroup = m
return m
