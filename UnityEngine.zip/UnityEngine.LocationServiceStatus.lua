---@class UnityEngine.LocationServiceStatus : System.Enum
---@field public Stopped UnityEngine.LocationServiceStatus @static
---@field public Initializing UnityEngine.LocationServiceStatus @static
---@field public Running UnityEngine.LocationServiceStatus @static
---@field public Failed UnityEngine.LocationServiceStatus @static
---@field public value__ number
local m = {}

UnityEngine.LocationServiceStatus = m
return m
