---@class UnityEngine.ConfigurableJoint : UnityEngine.Joint
---@field public secondaryAxis UnityEngine.Vector3
---@field public xMotion UnityEngine.ConfigurableJointMotion
---@field public yMotion UnityEngine.ConfigurableJointMotion
---@field public zMotion UnityEngine.ConfigurableJointMotion
---@field public angularXMotion UnityEngine.ConfigurableJointMotion
---@field public angularYMotion UnityEngine.ConfigurableJointMotion
---@field public angularZMotion UnityEngine.ConfigurableJointMotion
---@field public linearLimitSpring UnityEngine.SoftJointLimitSpring
---@field public angularXLimitSpring UnityEngine.SoftJointLimitSpring
---@field public angularYZLimitSpring UnityEngine.SoftJointLimitSpring
---@field public linearLimit UnityEngine.SoftJointLimit
---@field public lowAngularXLimit UnityEngine.SoftJointLimit
---@field public highAngularXLimit UnityEngine.SoftJointLimit
---@field public angularYLimit UnityEngine.SoftJointLimit
---@field public angularZLimit UnityEngine.SoftJointLimit
---@field public targetPosition UnityEngine.Vector3
---@field public targetVelocity UnityEngine.Vector3
---@field public xDrive UnityEngine.JointDrive
---@field public yDrive UnityEngine.JointDrive
---@field public zDrive UnityEngine.JointDrive
---@field public targetRotation UnityEngine.Quaternion
---@field public targetAngularVelocity UnityEngine.Vector3
---@field public rotationDriveMode UnityEngine.RotationDriveMode
---@field public angularXDrive UnityEngine.JointDrive
---@field public angularYZDrive UnityEngine.JointDrive
---@field public slerpDrive UnityEngine.JointDrive
---@field public projectionMode UnityEngine.JointProjectionMode
---@field public projectionDistance number
---@field public projectionAngle number
---@field public configuredInWorldSpace boolean
---@field public swapBodies boolean
local m = {}

UnityEngine.ConfigurableJoint = m
return m
