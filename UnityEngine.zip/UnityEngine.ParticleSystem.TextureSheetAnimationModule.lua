---@class UnityEngine.ParticleSystem.TextureSheetAnimationModule : System.ValueType
---@field public enabled boolean
---@field public numTilesX number
---@field public numTilesY number
---@field public animation UnityEngine.ParticleSystemAnimationType
---@field public useRandomRow boolean
---@field public frameOverTime UnityEngine.ParticleSystem.MinMaxCurve
---@field public frameOverTimeMultiplier number
---@field public startFrame UnityEngine.ParticleSystem.MinMaxCurve
---@field public startFrameMultiplier number
---@field public cycleCount number
---@field public rowIndex number
---@field public uvChannelMask UnityEngine.Rendering.UVChannelFlags
---@field public flipU number
---@field public flipV number
local m = {}

UnityEngine.ParticleSystem.TextureSheetAnimationModule = m
return m
