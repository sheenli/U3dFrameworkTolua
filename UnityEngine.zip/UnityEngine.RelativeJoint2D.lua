---@class UnityEngine.RelativeJoint2D : UnityEngine.Joint2D
---@field public maxForce number
---@field public maxTorque number
---@field public correctionScale number
---@field public autoConfigureOffset boolean
---@field public linearOffset UnityEngine.Vector2
---@field public angularOffset number
---@field public target UnityEngine.Vector2
local m = {}

UnityEngine.RelativeJoint2D = m
return m
