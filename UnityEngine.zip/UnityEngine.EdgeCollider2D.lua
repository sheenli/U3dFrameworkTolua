---@class UnityEngine.EdgeCollider2D : UnityEngine.Collider2D
---@field public edgeRadius number
---@field public edgeCount number
---@field public pointCount number
---@field public points UnityEngine.Vector2[]
local m = {}

function m:Reset() end

UnityEngine.EdgeCollider2D = m
return m
