---@class UnityEngine.AI.NavMeshLinkData : System.ValueType
---@field public startPosition UnityEngine.Vector3
---@field public endPosition UnityEngine.Vector3
---@field public costModifier number
---@field public bidirectional boolean
---@field public width number
---@field public area number
---@field public agentTypeID number
local m = {}

UnityEngine.AI.NavMeshLinkData = m
return m
