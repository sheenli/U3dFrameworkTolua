---@class UnityEngine.AI.NavMeshLinkInstance : System.ValueType
---@field public valid boolean
---@field public owner UnityEngine.Object
local m = {}

function m:Remove() end

UnityEngine.AI.NavMeshLinkInstance = m
return m
