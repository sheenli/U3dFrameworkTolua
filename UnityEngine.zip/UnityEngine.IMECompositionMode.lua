---@class UnityEngine.IMECompositionMode : System.Enum
---@field public Auto UnityEngine.IMECompositionMode @static
---@field public On UnityEngine.IMECompositionMode @static
---@field public Off UnityEngine.IMECompositionMode @static
---@field public value__ number
local m = {}

UnityEngine.IMECompositionMode = m
return m
