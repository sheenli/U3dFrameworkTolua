---@class UnityEngine.ParticleSystemNoiseQuality : System.Enum
---@field public Low UnityEngine.ParticleSystemNoiseQuality @static
---@field public Medium UnityEngine.ParticleSystemNoiseQuality @static
---@field public High UnityEngine.ParticleSystemNoiseQuality @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemNoiseQuality = m
return m
