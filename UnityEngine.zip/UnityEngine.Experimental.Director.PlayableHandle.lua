---@class UnityEngine.Experimental.Director.PlayableHandle : System.ValueType
---@field public Null UnityEngine.Experimental.Director.PlayableHandle @static
---@field public graph UnityEngine.Experimental.Director.PlayableGraph
---@field public inputCount number
---@field public outputCount number
---@field public playState UnityEngine.Experimental.Director.PlayState
---@field public speed number
---@field public time number
---@field public isDone boolean
---@field public duration number
local m = {}

---@overload fun():UnityEngine.Experimental.Director.Playable
---@return UnityEngine.Experimental.Director.Playable
function m:GetObject() end

---@return boolean
function m:IsValid() end

---@param inputPort number
---@return UnityEngine.Experimental.Director.PlayableHandle
function m:GetInput(inputPort) end

---@param outputPort number
---@return UnityEngine.Experimental.Director.PlayableHandle
function m:GetOutput(outputPort) end

---@param inputIndex number
---@param weight number
---@return boolean
function m:SetInputWeight(inputIndex, weight) end

---@param inputIndex number
---@return number
function m:GetInputWeight(inputIndex) end

function m:Destroy() end

---@static
---@param x UnityEngine.Experimental.Director.PlayableHandle
---@param y UnityEngine.Experimental.Director.PlayableHandle
---@return boolean
function m.op_Equality(x, y) end

---@static
---@param x UnityEngine.Experimental.Director.PlayableHandle
---@param y UnityEngine.Experimental.Director.PlayableHandle
---@return boolean
function m.op_Inequality(x, y) end

---@virtual
---@param p any
---@return boolean
function m:Equals(p) end

---@virtual
---@return number
function m:GetHashCode() end

UnityEngine.Experimental.Director.PlayableHandle = m
return m
