---@class UnityEngine.Rigidbody : UnityEngine.Component
---@field public velocity UnityEngine.Vector3
---@field public angularVelocity UnityEngine.Vector3
---@field public drag number
---@field public angularDrag number
---@field public mass number
---@field public useGravity boolean
---@field public maxDepenetrationVelocity number
---@field public isKinematic boolean
---@field public freezeRotation boolean
---@field public constraints UnityEngine.RigidbodyConstraints
---@field public collisionDetectionMode UnityEngine.CollisionDetectionMode
---@field public centerOfMass UnityEngine.Vector3
---@field public worldCenterOfMass UnityEngine.Vector3
---@field public inertiaTensorRotation UnityEngine.Quaternion
---@field public inertiaTensor UnityEngine.Vector3
---@field public detectCollisions boolean
---@field public useConeFriction boolean
---@field public position UnityEngine.Vector3
---@field public rotation UnityEngine.Quaternion
---@field public interpolation UnityEngine.RigidbodyInterpolation
---@field public solverIterations number
---@field public solverIterationCount number
---@field public solverVelocityIterations number
---@field public solverVelocityIterationCount number
---@field public sleepVelocity number
---@field public sleepAngularVelocity number
---@field public sleepThreshold number
---@field public maxAngularVelocity number
local m = {}

---@param density number
function m:SetDensity(density) end

---@overload fun(force:UnityEngine.Vector3)
---@overload fun(x:number, y:number, z:number)
---@overload fun(x:number, y:number, z:number, mode:UnityEngine.ForceMode)
---@param force UnityEngine.Vector3
---@param mode UnityEngine.ForceMode
function m:AddForce(force, mode) end

---@overload fun(force:UnityEngine.Vector3)
---@overload fun(x:number, y:number, z:number)
---@overload fun(x:number, y:number, z:number, mode:UnityEngine.ForceMode)
---@param force UnityEngine.Vector3
---@param mode UnityEngine.ForceMode
function m:AddRelativeForce(force, mode) end

---@overload fun(torque:UnityEngine.Vector3)
---@overload fun(x:number, y:number, z:number)
---@overload fun(x:number, y:number, z:number, mode:UnityEngine.ForceMode)
---@param torque UnityEngine.Vector3
---@param mode UnityEngine.ForceMode
function m:AddTorque(torque, mode) end

---@overload fun(torque:UnityEngine.Vector3)
---@overload fun(x:number, y:number, z:number)
---@overload fun(x:number, y:number, z:number, mode:UnityEngine.ForceMode)
---@param torque UnityEngine.Vector3
---@param mode UnityEngine.ForceMode
function m:AddRelativeTorque(torque, mode) end

---@overload fun(force:UnityEngine.Vector3, position:UnityEngine.Vector3)
---@param force UnityEngine.Vector3
---@param position UnityEngine.Vector3
---@param mode UnityEngine.ForceMode
function m:AddForceAtPosition(force, position, mode) end

---@overload fun(explosionForce:number, explosionPosition:UnityEngine.Vector3, explosionRadius:number, upwardsModifier:number)
---@overload fun(explosionForce:number, explosionPosition:UnityEngine.Vector3, explosionRadius:number)
---@param explosionForce number
---@param explosionPosition UnityEngine.Vector3
---@param explosionRadius number
---@param upwardsModifier number
---@param mode UnityEngine.ForceMode
function m:AddExplosionForce(explosionForce, explosionPosition, explosionRadius, upwardsModifier, mode) end

---@param position UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:ClosestPointOnBounds(position) end

---@param relativePoint UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:GetRelativePointVelocity(relativePoint) end

---@param worldPoint UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:GetPointVelocity(worldPoint) end

---@param position UnityEngine.Vector3
function m:MovePosition(position) end

---@param rot UnityEngine.Quaternion
function m:MoveRotation(rot) end

function m:Sleep() end

---@return boolean
function m:IsSleeping() end

function m:WakeUp() end

function m:ResetCenterOfMass() end

function m:ResetInertiaTensor() end

---@overload fun(direction:UnityEngine.Vector3, maxDistance:number):boolean, UnityEngine.RaycastHit
---@overload fun(direction:UnityEngine.Vector3):boolean, UnityEngine.RaycastHit
---@param direction UnityEngine.Vector3
---@param maxDistance number
---@param queryTriggerInteraction UnityEngine.QueryTriggerInteraction
---@return boolean, UnityEngine.RaycastHit
function m:SweepTest(direction, maxDistance, queryTriggerInteraction) end

---@overload fun(direction:UnityEngine.Vector3, maxDistance:number):UnityEngine.RaycastHit[]
---@overload fun(direction:UnityEngine.Vector3):UnityEngine.RaycastHit[]
---@param direction UnityEngine.Vector3
---@param maxDistance number
---@param queryTriggerInteraction UnityEngine.QueryTriggerInteraction
---@return UnityEngine.RaycastHit[]
function m:SweepTestAll(direction, maxDistance, queryTriggerInteraction) end

---@param a number
function m:SetMaxAngularVelocity(a) end

UnityEngine.Rigidbody = m
return m
