---@class UnityEngine.ParticleSystem.LightsModule : System.ValueType
---@field public enabled boolean
---@field public ratio number
---@field public useRandomDistribution boolean
---@field public light UnityEngine.Light
---@field public useParticleColor boolean
---@field public sizeAffectsRange boolean
---@field public alphaAffectsIntensity boolean
---@field public range UnityEngine.ParticleSystem.MinMaxCurve
---@field public rangeMultiplier number
---@field public intensity UnityEngine.ParticleSystem.MinMaxCurve
---@field public intensityMultiplier number
---@field public maxLights number
local m = {}

UnityEngine.ParticleSystem.LightsModule = m
return m
