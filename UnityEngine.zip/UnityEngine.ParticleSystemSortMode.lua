---@class UnityEngine.ParticleSystemSortMode : System.Enum
---@field public None UnityEngine.ParticleSystemSortMode @static
---@field public Distance UnityEngine.ParticleSystemSortMode @static
---@field public OldestInFront UnityEngine.ParticleSystemSortMode @static
---@field public YoungestInFront UnityEngine.ParticleSystemSortMode @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemSortMode = m
return m
