---@class UnityEngine.Physics : System.Object
---@field public IgnoreRaycastLayer number @static
---@field public kIgnoreRaycastLayer number @static
---@field public DefaultRaycastLayers number @static
---@field public kDefaultRaycastLayers number @static
---@field public AllLayers number @static
---@field public kAllLayers number @static
---@field public gravity UnityEngine.Vector3 @static
---@field public minPenetrationForPenalty number @static
---@field public defaultContactOffset number @static
---@field public bounceThreshold number @static
---@field public bounceTreshold number @static
---@field public sleepVelocity number @static
---@field public sleepAngularVelocity number @static
---@field public maxAngularVelocity number @static
---@field public defaultSolverIterations number @static
---@field public solverIterationCount number @static
---@field public defaultSolverVelocityIterations number @static
---@field public solverVelocityIterationCount number @static
---@field public sleepThreshold number @static
---@field public queriesHitTriggers boolean @static
---@field public queriesHitBackfaces boolean @static
---@field public penetrationPenaltyForce number @static
local m = {}

---@overload fun(origin:UnityEngine.Vector3, direction:UnityEngine.Vector3, maxDistance:number):boolean @static
---@overload fun(origin:UnityEngine.Vector3, direction:UnityEngine.Vector3):boolean @static
---@overload fun(origin:UnityEngine.Vector3, direction:UnityEngine.Vector3, maxDistance:number, layerMask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):boolean @static
---@overload fun(origin:UnityEngine.Vector3, direction:UnityEngine.Vector3, maxDistance:number, layerMask:number):boolean, UnityEngine.RaycastHit @static
---@overload fun(origin:UnityEngine.Vector3, direction:UnityEngine.Vector3, maxDistance:number):boolean, UnityEngine.RaycastHit @static
---@overload fun(origin:UnityEngine.Vector3, direction:UnityEngine.Vector3):boolean, UnityEngine.RaycastHit @static
---@overload fun(origin:UnityEngine.Vector3, direction:UnityEngine.Vector3, maxDistance:number, layerMask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):boolean, UnityEngine.RaycastHit @static
---@overload fun(ray:UnityEngine.Ray, maxDistance:number, layerMask:number):boolean @static
---@overload fun(ray:UnityEngine.Ray, maxDistance:number):boolean @static
---@overload fun(ray:UnityEngine.Ray):boolean @static
---@overload fun(ray:UnityEngine.Ray, maxDistance:number, layerMask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):boolean @static
---@overload fun(ray:UnityEngine.Ray, maxDistance:number, layerMask:number):boolean, UnityEngine.RaycastHit @static
---@overload fun(ray:UnityEngine.Ray, maxDistance:number):boolean, UnityEngine.RaycastHit @static
---@overload fun(ray:UnityEngine.Ray):boolean, UnityEngine.RaycastHit @static
---@overload fun(ray:UnityEngine.Ray, maxDistance:number, layerMask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):boolean, UnityEngine.RaycastHit @static
---@static
---@param origin UnityEngine.Vector3
---@param direction UnityEngine.Vector3
---@param maxDistance number
---@param layerMask number
---@return boolean
function m.Raycast(origin, direction, maxDistance, layerMask) end

---@overload fun(ray:UnityEngine.Ray, maxDistance:number):UnityEngine.RaycastHit[] @static
---@overload fun(ray:UnityEngine.Ray):UnityEngine.RaycastHit[] @static
---@overload fun(ray:UnityEngine.Ray, maxDistance:number, layerMask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):UnityEngine.RaycastHit[] @static
---@overload fun(origin:UnityEngine.Vector3, direction:UnityEngine.Vector3, maxDistance:number, layermask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):UnityEngine.RaycastHit[] @static
---@overload fun(origin:UnityEngine.Vector3, direction:UnityEngine.Vector3, maxDistance:number, layermask:number):UnityEngine.RaycastHit[] @static
---@overload fun(origin:UnityEngine.Vector3, direction:UnityEngine.Vector3, maxDistance:number):UnityEngine.RaycastHit[] @static
---@overload fun(origin:UnityEngine.Vector3, direction:UnityEngine.Vector3):UnityEngine.RaycastHit[] @static
---@static
---@param ray UnityEngine.Ray
---@param maxDistance number
---@param layerMask number
---@return UnityEngine.RaycastHit[]
function m.RaycastAll(ray, maxDistance, layerMask) end

---@overload fun(ray:UnityEngine.Ray, results:UnityEngine.RaycastHit[], maxDistance:number):number @static
---@overload fun(ray:UnityEngine.Ray, results:UnityEngine.RaycastHit[]):number @static
---@overload fun(ray:UnityEngine.Ray, results:UnityEngine.RaycastHit[], maxDistance:number, layerMask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):number @static
---@overload fun(origin:UnityEngine.Vector3, direction:UnityEngine.Vector3, results:UnityEngine.RaycastHit[], maxDistance:number, layermask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):number @static
---@overload fun(origin:UnityEngine.Vector3, direction:UnityEngine.Vector3, results:UnityEngine.RaycastHit[], maxDistance:number, layermask:number):number @static
---@overload fun(origin:UnityEngine.Vector3, direction:UnityEngine.Vector3, results:UnityEngine.RaycastHit[], maxDistance:number):number @static
---@overload fun(origin:UnityEngine.Vector3, direction:UnityEngine.Vector3, results:UnityEngine.RaycastHit[]):number @static
---@static
---@param ray UnityEngine.Ray
---@param results UnityEngine.RaycastHit[]
---@param maxDistance number
---@param layerMask number
---@return number
function m.RaycastNonAlloc(ray, results, maxDistance, layerMask) end

---@overload fun(start:UnityEngine.Vector3, _end:UnityEngine.Vector3):boolean @static
---@overload fun(start:UnityEngine.Vector3, _end:UnityEngine.Vector3, layerMask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):boolean @static
---@overload fun(start:UnityEngine.Vector3, _end:UnityEngine.Vector3, layerMask:number):boolean, UnityEngine.RaycastHit @static
---@overload fun(start:UnityEngine.Vector3, _end:UnityEngine.Vector3):boolean, UnityEngine.RaycastHit @static
---@overload fun(start:UnityEngine.Vector3, _end:UnityEngine.Vector3, layerMask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):boolean, UnityEngine.RaycastHit @static
---@static
---@param start UnityEngine.Vector3
---@param _end UnityEngine.Vector3
---@param layerMask number
---@return boolean
function m.Linecast(start, _end, layerMask) end

---@overload fun(position:UnityEngine.Vector3, radius:number, layerMask:number):UnityEngine.Collider[] @static
---@overload fun(position:UnityEngine.Vector3, radius:number):UnityEngine.Collider[] @static
---@static
---@param position UnityEngine.Vector3
---@param radius number
---@param layerMask number
---@param queryTriggerInteraction UnityEngine.QueryTriggerInteraction
---@return UnityEngine.Collider[]
function m.OverlapSphere(position, radius, layerMask, queryTriggerInteraction) end

---@overload fun(position:UnityEngine.Vector3, radius:number, results:UnityEngine.Collider[], layerMask:number):number @static
---@overload fun(position:UnityEngine.Vector3, radius:number, results:UnityEngine.Collider[]):number @static
---@static
---@param position UnityEngine.Vector3
---@param radius number
---@param results UnityEngine.Collider[]
---@param layerMask number
---@param queryTriggerInteraction UnityEngine.QueryTriggerInteraction
---@return number
function m.OverlapSphereNonAlloc(position, radius, results, layerMask, queryTriggerInteraction) end

---@overload fun(point0:UnityEngine.Vector3, point1:UnityEngine.Vector3, radius:number, layerMask:number):UnityEngine.Collider[] @static
---@overload fun(point0:UnityEngine.Vector3, point1:UnityEngine.Vector3, radius:number):UnityEngine.Collider[] @static
---@static
---@param point0 UnityEngine.Vector3
---@param point1 UnityEngine.Vector3
---@param radius number
---@param layerMask number
---@param queryTriggerInteraction UnityEngine.QueryTriggerInteraction
---@return UnityEngine.Collider[]
function m.OverlapCapsule(point0, point1, radius, layerMask, queryTriggerInteraction) end

---@overload fun(point0:UnityEngine.Vector3, point1:UnityEngine.Vector3, radius:number, results:UnityEngine.Collider[], layerMask:number):number @static
---@overload fun(point0:UnityEngine.Vector3, point1:UnityEngine.Vector3, radius:number, results:UnityEngine.Collider[]):number @static
---@static
---@param point0 UnityEngine.Vector3
---@param point1 UnityEngine.Vector3
---@param radius number
---@param results UnityEngine.Collider[]
---@param layerMask number
---@param queryTriggerInteraction UnityEngine.QueryTriggerInteraction
---@return number
function m.OverlapCapsuleNonAlloc(point0, point1, radius, results, layerMask, queryTriggerInteraction) end

---@overload fun(point1:UnityEngine.Vector3, point2:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3, maxDistance:number):boolean @static
---@overload fun(point1:UnityEngine.Vector3, point2:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3):boolean @static
---@overload fun(point1:UnityEngine.Vector3, point2:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3, maxDistance:number, layerMask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):boolean @static
---@overload fun(point1:UnityEngine.Vector3, point2:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3, maxDistance:number, layerMask:number):boolean, UnityEngine.RaycastHit @static
---@overload fun(point1:UnityEngine.Vector3, point2:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3, maxDistance:number):boolean, UnityEngine.RaycastHit @static
---@overload fun(point1:UnityEngine.Vector3, point2:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3):boolean, UnityEngine.RaycastHit @static
---@overload fun(point1:UnityEngine.Vector3, point2:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3, maxDistance:number, layerMask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):boolean, UnityEngine.RaycastHit @static
---@static
---@param point1 UnityEngine.Vector3
---@param point2 UnityEngine.Vector3
---@param radius number
---@param direction UnityEngine.Vector3
---@param maxDistance number
---@param layerMask number
---@return boolean
function m.CapsuleCast(point1, point2, radius, direction, maxDistance, layerMask) end

---@overload fun(origin:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3, maxDistance:number):boolean, UnityEngine.RaycastHit @static
---@overload fun(origin:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3):boolean, UnityEngine.RaycastHit @static
---@overload fun(origin:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3, maxDistance:number, layerMask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):boolean, UnityEngine.RaycastHit @static
---@overload fun(ray:UnityEngine.Ray, radius:number, maxDistance:number, layerMask:number):boolean @static
---@overload fun(ray:UnityEngine.Ray, radius:number, maxDistance:number):boolean @static
---@overload fun(ray:UnityEngine.Ray, radius:number):boolean @static
---@overload fun(ray:UnityEngine.Ray, radius:number, maxDistance:number, layerMask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):boolean @static
---@overload fun(ray:UnityEngine.Ray, radius:number, maxDistance:number, layerMask:number):boolean, UnityEngine.RaycastHit @static
---@overload fun(ray:UnityEngine.Ray, radius:number, maxDistance:number):boolean, UnityEngine.RaycastHit @static
---@overload fun(ray:UnityEngine.Ray, radius:number):boolean, UnityEngine.RaycastHit @static
---@overload fun(ray:UnityEngine.Ray, radius:number, maxDistance:number, layerMask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):boolean, UnityEngine.RaycastHit @static
---@static
---@param origin UnityEngine.Vector3
---@param radius number
---@param direction UnityEngine.Vector3
---@param maxDistance number
---@param layerMask number
---@return boolean, UnityEngine.RaycastHit
function m.SphereCast(origin, radius, direction, maxDistance, layerMask) end

---@overload fun(point1:UnityEngine.Vector3, point2:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3, maxDistance:number, layermask:number):UnityEngine.RaycastHit[] @static
---@overload fun(point1:UnityEngine.Vector3, point2:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3, maxDistance:number):UnityEngine.RaycastHit[] @static
---@overload fun(point1:UnityEngine.Vector3, point2:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3):UnityEngine.RaycastHit[] @static
---@static
---@param point1 UnityEngine.Vector3
---@param point2 UnityEngine.Vector3
---@param radius number
---@param direction UnityEngine.Vector3
---@param maxDistance number
---@param layermask number
---@param queryTriggerInteraction UnityEngine.QueryTriggerInteraction
---@return UnityEngine.RaycastHit[]
function m.CapsuleCastAll(point1, point2, radius, direction, maxDistance, layermask, queryTriggerInteraction) end

---@overload fun(point1:UnityEngine.Vector3, point2:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3, results:UnityEngine.RaycastHit[], maxDistance:number, layermask:number):number @static
---@overload fun(point1:UnityEngine.Vector3, point2:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3, results:UnityEngine.RaycastHit[], maxDistance:number):number @static
---@overload fun(point1:UnityEngine.Vector3, point2:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3, results:UnityEngine.RaycastHit[]):number @static
---@static
---@param point1 UnityEngine.Vector3
---@param point2 UnityEngine.Vector3
---@param radius number
---@param direction UnityEngine.Vector3
---@param results UnityEngine.RaycastHit[]
---@param maxDistance number
---@param layermask number
---@param queryTriggerInteraction UnityEngine.QueryTriggerInteraction
---@return number
function m.CapsuleCastNonAlloc(point1, point2, radius, direction, results, maxDistance, layermask, queryTriggerInteraction) end

---@overload fun(origin:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3, maxDistance:number):UnityEngine.RaycastHit[] @static
---@overload fun(origin:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3):UnityEngine.RaycastHit[] @static
---@overload fun(origin:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3, maxDistance:number, layerMask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):UnityEngine.RaycastHit[] @static
---@overload fun(ray:UnityEngine.Ray, radius:number, maxDistance:number, layerMask:number):UnityEngine.RaycastHit[] @static
---@overload fun(ray:UnityEngine.Ray, radius:number, maxDistance:number):UnityEngine.RaycastHit[] @static
---@overload fun(ray:UnityEngine.Ray, radius:number):UnityEngine.RaycastHit[] @static
---@overload fun(ray:UnityEngine.Ray, radius:number, maxDistance:number, layerMask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):UnityEngine.RaycastHit[] @static
---@static
---@param origin UnityEngine.Vector3
---@param radius number
---@param direction UnityEngine.Vector3
---@param maxDistance number
---@param layerMask number
---@return UnityEngine.RaycastHit[]
function m.SphereCastAll(origin, radius, direction, maxDistance, layerMask) end

---@overload fun(origin:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3, results:UnityEngine.RaycastHit[], maxDistance:number):number @static
---@overload fun(origin:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3, results:UnityEngine.RaycastHit[]):number @static
---@overload fun(origin:UnityEngine.Vector3, radius:number, direction:UnityEngine.Vector3, results:UnityEngine.RaycastHit[], maxDistance:number, layerMask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):number @static
---@overload fun(ray:UnityEngine.Ray, radius:number, results:UnityEngine.RaycastHit[], maxDistance:number, layerMask:number):number @static
---@overload fun(ray:UnityEngine.Ray, radius:number, results:UnityEngine.RaycastHit[], maxDistance:number):number @static
---@overload fun(ray:UnityEngine.Ray, radius:number, results:UnityEngine.RaycastHit[]):number @static
---@overload fun(ray:UnityEngine.Ray, radius:number, results:UnityEngine.RaycastHit[], maxDistance:number, layerMask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):number @static
---@static
---@param origin UnityEngine.Vector3
---@param radius number
---@param direction UnityEngine.Vector3
---@param results UnityEngine.RaycastHit[]
---@param maxDistance number
---@param layerMask number
---@return number
function m.SphereCastNonAlloc(origin, radius, direction, results, maxDistance, layerMask) end

---@overload fun(position:UnityEngine.Vector3, radius:number, layerMask:number):boolean @static
---@overload fun(position:UnityEngine.Vector3, radius:number):boolean @static
---@static
---@param position UnityEngine.Vector3
---@param radius number
---@param layerMask number
---@param queryTriggerInteraction UnityEngine.QueryTriggerInteraction
---@return boolean
function m.CheckSphere(position, radius, layerMask, queryTriggerInteraction) end

---@overload fun(start:UnityEngine.Vector3, _end:UnityEngine.Vector3, radius:number, layermask:number):boolean @static
---@overload fun(start:UnityEngine.Vector3, _end:UnityEngine.Vector3, radius:number):boolean @static
---@static
---@param start UnityEngine.Vector3
---@param _end UnityEngine.Vector3
---@param radius number
---@param layermask number
---@param queryTriggerInteraction UnityEngine.QueryTriggerInteraction
---@return boolean
function m.CheckCapsule(start, _end, radius, layermask, queryTriggerInteraction) end

---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, orientation:UnityEngine.Quaternion, layermask:number):boolean @static
---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, orientation:UnityEngine.Quaternion):boolean @static
---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3):boolean @static
---@static
---@param center UnityEngine.Vector3
---@param halfExtents UnityEngine.Vector3
---@param orientation UnityEngine.Quaternion
---@param layermask number
---@param queryTriggerInteraction UnityEngine.QueryTriggerInteraction
---@return boolean
function m.CheckBox(center, halfExtents, orientation, layermask, queryTriggerInteraction) end

---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, orientation:UnityEngine.Quaternion, layerMask:number):UnityEngine.Collider[] @static
---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, orientation:UnityEngine.Quaternion):UnityEngine.Collider[] @static
---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3):UnityEngine.Collider[] @static
---@static
---@param center UnityEngine.Vector3
---@param halfExtents UnityEngine.Vector3
---@param orientation UnityEngine.Quaternion
---@param layerMask number
---@param queryTriggerInteraction UnityEngine.QueryTriggerInteraction
---@return UnityEngine.Collider[]
function m.OverlapBox(center, halfExtents, orientation, layerMask, queryTriggerInteraction) end

---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, results:UnityEngine.Collider[], orientation:UnityEngine.Quaternion, layerMask:number):number @static
---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, results:UnityEngine.Collider[], orientation:UnityEngine.Quaternion):number @static
---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, results:UnityEngine.Collider[]):number @static
---@static
---@param center UnityEngine.Vector3
---@param halfExtents UnityEngine.Vector3
---@param results UnityEngine.Collider[]
---@param orientation UnityEngine.Quaternion
---@param layerMask number
---@param queryTriggerInteraction UnityEngine.QueryTriggerInteraction
---@return number
function m.OverlapBoxNonAlloc(center, halfExtents, results, orientation, layerMask, queryTriggerInteraction) end

---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, direction:UnityEngine.Vector3, orientation:UnityEngine.Quaternion, maxDistance:number, layermask:number):UnityEngine.RaycastHit[] @static
---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, direction:UnityEngine.Vector3, orientation:UnityEngine.Quaternion, maxDistance:number):UnityEngine.RaycastHit[] @static
---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, direction:UnityEngine.Vector3, orientation:UnityEngine.Quaternion):UnityEngine.RaycastHit[] @static
---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, direction:UnityEngine.Vector3):UnityEngine.RaycastHit[] @static
---@static
---@param center UnityEngine.Vector3
---@param halfExtents UnityEngine.Vector3
---@param direction UnityEngine.Vector3
---@param orientation UnityEngine.Quaternion
---@param maxDistance number
---@param layermask number
---@param queryTriggerInteraction UnityEngine.QueryTriggerInteraction
---@return UnityEngine.RaycastHit[]
function m.BoxCastAll(center, halfExtents, direction, orientation, maxDistance, layermask, queryTriggerInteraction) end

---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, direction:UnityEngine.Vector3, results:UnityEngine.RaycastHit[], orientation:UnityEngine.Quaternion, maxDistance:number, layermask:number):number @static
---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, direction:UnityEngine.Vector3, results:UnityEngine.RaycastHit[], orientation:UnityEngine.Quaternion, maxDistance:number):number @static
---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, direction:UnityEngine.Vector3, results:UnityEngine.RaycastHit[], orientation:UnityEngine.Quaternion):number @static
---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, direction:UnityEngine.Vector3, results:UnityEngine.RaycastHit[]):number @static
---@static
---@param center UnityEngine.Vector3
---@param halfExtents UnityEngine.Vector3
---@param direction UnityEngine.Vector3
---@param results UnityEngine.RaycastHit[]
---@param orientation UnityEngine.Quaternion
---@param maxDistance number
---@param layermask number
---@param queryTriggerInteraction UnityEngine.QueryTriggerInteraction
---@return number
function m.BoxCastNonAlloc(center, halfExtents, direction, results, orientation, maxDistance, layermask, queryTriggerInteraction) end

---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, direction:UnityEngine.Vector3, orientation:UnityEngine.Quaternion, maxDistance:number):boolean @static
---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, direction:UnityEngine.Vector3, orientation:UnityEngine.Quaternion):boolean @static
---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, direction:UnityEngine.Vector3):boolean @static
---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, direction:UnityEngine.Vector3, orientation:UnityEngine.Quaternion, maxDistance:number, layerMask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):boolean @static
---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, direction:UnityEngine.Vector3, orientation:UnityEngine.Quaternion, maxDistance:number, layerMask:number):boolean, UnityEngine.RaycastHit @static
---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, direction:UnityEngine.Vector3, orientation:UnityEngine.Quaternion, maxDistance:number):boolean, UnityEngine.RaycastHit @static
---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, direction:UnityEngine.Vector3, orientation:UnityEngine.Quaternion):boolean, UnityEngine.RaycastHit @static
---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, direction:UnityEngine.Vector3):boolean, UnityEngine.RaycastHit @static
---@overload fun(center:UnityEngine.Vector3, halfExtents:UnityEngine.Vector3, direction:UnityEngine.Vector3, orientation:UnityEngine.Quaternion, maxDistance:number, layerMask:number, queryTriggerInteraction:UnityEngine.QueryTriggerInteraction):boolean, UnityEngine.RaycastHit @static
---@static
---@param center UnityEngine.Vector3
---@param halfExtents UnityEngine.Vector3
---@param direction UnityEngine.Vector3
---@param orientation UnityEngine.Quaternion
---@param maxDistance number
---@param layerMask number
---@return boolean
function m.BoxCast(center, halfExtents, direction, orientation, maxDistance, layerMask) end

---@overload fun(collider1:UnityEngine.Collider, collider2:UnityEngine.Collider) @static
---@static
---@param collider1 UnityEngine.Collider
---@param collider2 UnityEngine.Collider
---@param ignore boolean
function m.IgnoreCollision(collider1, collider2, ignore) end

---@overload fun(layer1:number, layer2:number) @static
---@static
---@param layer1 number
---@param layer2 number
---@param ignore boolean
function m.IgnoreLayerCollision(layer1, layer2, ignore) end

---@static
---@param layer1 number
---@param layer2 number
---@return boolean
function m.GetIgnoreLayerCollision(layer1, layer2) end

---@static
---@param colliderA UnityEngine.Collider
---@param positionA UnityEngine.Vector3
---@param rotationA UnityEngine.Quaternion
---@param colliderB UnityEngine.Collider
---@param positionB UnityEngine.Vector3
---@param rotationB UnityEngine.Quaternion
---@return boolean, UnityEngine.Vector3, System.Single
function m.ComputePenetration(colliderA, positionA, rotationA, colliderB, positionB, rotationB) end

---@static
---@param point UnityEngine.Vector3
---@param collider UnityEngine.Collider
---@param position UnityEngine.Vector3
---@param rotation UnityEngine.Quaternion
---@return UnityEngine.Vector3
function m.ClosestPoint(point, collider, position, rotation) end

UnityEngine.Physics = m
return m
