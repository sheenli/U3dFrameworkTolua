---@class UnityEngine.WWWAudioExtensions : System.Object
local m = {}

---@overload fun(www:UnityEngine.WWW, threeD:boolean):UnityEngine.AudioClip @static
---@overload fun(www:UnityEngine.WWW, threeD:boolean, stream:boolean):UnityEngine.AudioClip @static
---@overload fun(www:UnityEngine.WWW, threeD:boolean, stream:boolean, audioType:UnityEngine.AudioType):UnityEngine.AudioClip @static
---@static
---@param www UnityEngine.WWW
---@return UnityEngine.AudioClip
function m.GetAudioClip(www) end

---@overload fun(www:UnityEngine.WWW, threeD:boolean):UnityEngine.AudioClip @static
---@overload fun(www:UnityEngine.WWW, threeD:boolean, audioType:UnityEngine.AudioType):UnityEngine.AudioClip @static
---@static
---@param www UnityEngine.WWW
---@return UnityEngine.AudioClip
function m.GetAudioClipCompressed(www) end

---@static
---@param www UnityEngine.WWW
---@return UnityEngine.MovieTexture
function m.GetMovieTexture(www) end

UnityEngine.WWWAudioExtensions = m
return m
