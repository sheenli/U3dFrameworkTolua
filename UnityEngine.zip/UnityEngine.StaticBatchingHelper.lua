---@class UnityEngine.StaticBatchingHelper : System.ValueType
local m = {}

UnityEngine.StaticBatchingHelper = m
return m
