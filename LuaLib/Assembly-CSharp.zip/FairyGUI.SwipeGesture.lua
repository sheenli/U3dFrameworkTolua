---@class FairyGUI.SwipeGesture : FairyGUI.EventDispatcher
---@field public ACTION_DISTANCE number @static
---@field public velocity UnityEngine.Vector2
---@field public position UnityEngine.Vector2
---@field public delta UnityEngine.Vector2
---@field public actionDistance number
---@field public snapping boolean
---@field public host FairyGUI.GObject
---@field public onBegin FairyGUI.EventListener
---@field public onEnd FairyGUI.EventListener
---@field public onMove FairyGUI.EventListener
---@field public onAction FairyGUI.EventListener
local m = {}

function m:Dispose() end

---@param value boolean
function m:Enable(value) end

FairyGUI.SwipeGesture = m
return m
