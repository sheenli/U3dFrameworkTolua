---@class FairyGUI.AsyncCreationHelper.DisplayListItem : System.Object
---@field public packageItem FairyGUI.PackageItem
---@field public type FairyGUI.ObjectType
---@field public childCount number
---@field public listItemCount number
local m = {}

FairyGUI.AsyncCreationHelper.DisplayListItem = m
return m
