---@class FairyGUI.PlayTransitionAction : FairyGUI.ControllerAction
---@field public transitionName string
---@field public playTimes number
---@field public delay number
---@field public stopOnExit boolean
local m = {}

---@virtual
---@param buffer FairyGUI.Utils.ByteBuffer
function m:Setup(buffer) end

FairyGUI.PlayTransitionAction = m
return m
