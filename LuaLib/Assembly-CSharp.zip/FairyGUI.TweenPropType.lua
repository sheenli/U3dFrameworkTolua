---@class FairyGUI.TweenPropType : System.Enum
---@field public None FairyGUI.TweenPropType @static
---@field public X FairyGUI.TweenPropType @static
---@field public Y FairyGUI.TweenPropType @static
---@field public Z FairyGUI.TweenPropType @static
---@field public XY FairyGUI.TweenPropType @static
---@field public Position FairyGUI.TweenPropType @static
---@field public Width FairyGUI.TweenPropType @static
---@field public Height FairyGUI.TweenPropType @static
---@field public Size FairyGUI.TweenPropType @static
---@field public ScaleX FairyGUI.TweenPropType @static
---@field public ScaleY FairyGUI.TweenPropType @static
---@field public Scale FairyGUI.TweenPropType @static
---@field public Rotation FairyGUI.TweenPropType @static
---@field public RotationX FairyGUI.TweenPropType @static
---@field public RotationY FairyGUI.TweenPropType @static
---@field public Alpha FairyGUI.TweenPropType @static
---@field public Progress FairyGUI.TweenPropType @static
---@field public value__ number
local m = {}

FairyGUI.TweenPropType = m
return m
