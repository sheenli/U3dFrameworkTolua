---@class EventDef : System.Object
---@field public ServerColsed number @static
---@field public ServerConnectFinish number @static
---@field public ServerConnectFailure number @static
---@field public ServerRequestTimeout number @static
---@field public ServerError number @static
---@field public SendLoginCompleted number @static
---@field public ServerResponse number @static
local m = {}

EventDef = m
return m
