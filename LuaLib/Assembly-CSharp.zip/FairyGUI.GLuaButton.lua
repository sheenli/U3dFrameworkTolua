---@class FairyGUI.GLuaButton : FairyGUI.GButton
local m = {}

---@virtual
---@param xml FairyGUI.Utils.XML
function m:ConstructFromXML(xml) end

---@virtual
function m:Dispose() end

FairyGUI.GLuaButton = m
return m
