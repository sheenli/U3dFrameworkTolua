---@class SevenZip.ISetCoderProperties : table
local m = {}

---@abstract
---@param propIDs SevenZip.CoderPropID[]
---@param properties any[]
function m:SetCoderProperties(propIDs, properties) end

SevenZip.ISetCoderProperties = m
return m
