---@class FairyGUI.IAnimationGear : table
---@field public playing boolean
---@field public frame number
---@field public timeScale number
---@field public ignoreEngineTimeScale boolean
local m = {}

---@abstract
---@param time number
function m:Advance(time) end

FairyGUI.IAnimationGear = m
return m
