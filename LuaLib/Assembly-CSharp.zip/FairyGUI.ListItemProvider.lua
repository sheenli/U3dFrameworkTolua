---@class FairyGUI.ListItemProvider : System.MulticastDelegate
local m = {}

---@virtual
---@param index number
---@return string
function m:Invoke(index) end

---@virtual
---@param index number
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(index, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return string
function m:EndInvoke(result) end

FairyGUI.ListItemProvider = m
return m
