---@class RemotelyVersionInfo.RemotelyInfo : System.Object
---@field public notic string
---@field public version string
---@field public ResUrl string
---@field public FullPackUrl string
local m = {}

RemotelyVersionInfo.RemotelyInfo = m
return m
