---@class InterchangeableEventListenerMgr : System.Object
local m = {}

---@overload fun(callback:fun(data:EventData), _priority:number):
---@overload fun(callback:fun(data:EventData)):
---@param callback fun(data:EventData)
---@param _priority number
---@param _dispatchOnce boolean
---@return InterchangeableEventListenerMgr
function m:SetDefCallback(callback, _priority, _dispatchOnce) end

---@overload fun(callback:fun(data:EventData), _priority:number):
---@overload fun(callback:fun(data:EventData)):
---@param callback fun(data:EventData)
---@param _priority number
---@param _dispatchOnce boolean
---@return InterchangeableEventListenerMgr
function m:SetNetworkCallback(callback, _priority, _dispatchOnce) end

---@overload fun(callback:fun(data:EventData), _priority:number):
---@overload fun(callback:fun(data:EventData)):
---@param callback fun(data:EventData)
---@param _priority number
---@param _dispatchOnce boolean
---@return InterchangeableEventListenerMgr
function m:SetSceneCallback(callback, _priority, _dispatchOnce) end

---@overload fun(callback:fun(data:EventData), _priority:number):
---@overload fun(callback:fun(data:EventData)):
---@param callback fun(data:EventData)
---@param _priority number
---@param _dispatchOnce boolean
---@return InterchangeableEventListenerMgr
function m:SetUICallback(callback, _priority, _dispatchOnce) end

---@overload fun(callback:fun(data:EventData), _priority:number):
---@overload fun(callback:fun(data:EventData)):
---@param callback fun(data:EventData)
---@param _priority number
---@param _dispatchOnce boolean
---@return InterchangeableEventListenerMgr
function m:SetModeCallback(callback, _priority, _dispatchOnce) end

---@overload fun(type:string, callback:fun(data:EventData), _priority:number)
---@overload fun(type:string, callback:fun(data:EventData))
---@overload fun(type:string)
---@param type string
---@param callback fun(data:EventData)
---@param _priority number
---@param _dispatchOnce boolean
function m:AddNetEvent(type, callback, _priority, _dispatchOnce) end

---@overload fun(type:string)
---@param type string
---@param callback fun(data:EventData)
function m:RemoveNetEvent(type, callback) end

---@overload fun(type:string, callback:fun(data:EventData), _priority:number)
---@overload fun(type:string, callback:fun(data:EventData))
---@overload fun(type:string)
---@param type string
---@param callback fun(data:EventData)
---@param _priority number
---@param _dispatchOnce boolean
function m:AddUIEvent(type, callback, _priority, _dispatchOnce) end

---@overload fun(type:string)
---@param type string
---@param callback fun(data:EventData)
function m:RemoveUIEvent(type, callback) end

---@overload fun(type:string, callback:fun(data:EventData), _priority:number)
---@overload fun(type:string, callback:fun(data:EventData))
---@overload fun(type:string)
---@param type string
---@param callback fun(data:EventData)
---@param _priority number
---@param _dispatchOnce boolean
function m:AddSceneEvent(type, callback, _priority, _dispatchOnce) end

---@overload fun(type:string)
---@param type string
---@param callback fun(data:EventData)
function m:RemoveSceneEvent(type, callback) end

---@overload fun(type:string, callback:fun(data:EventData), _priority:number)
---@overload fun(type:string, callback:fun(data:EventData))
---@overload fun(type:string)
---@param type string
---@param callback fun(data:EventData)
---@param _priority number
---@param _dispatchOnce boolean
function m:AddModeEvent(type, callback, _priority, _dispatchOnce) end

---@overload fun(type:string)
---@param type string
---@param callback fun(data:EventData)
function m:RemoveModeEvent(type, callback) end

---@overload fun(dis:EventDispatcherNode, type:string, callback:fun(data:EventData), _priority:number)
---@overload fun(dis:EventDispatcherNode, type:string, callback:fun(data:EventData))
---@overload fun(dis:EventDispatcherNode, type:string)
---@param dis EventDispatcherNode
---@param type string
---@param callback fun(data:EventData)
---@param _priority number
---@param _dispatchOnce boolean
function m:AddEvent(dis, type, callback, _priority, _dispatchOnce) end

---@overload fun(dis:EventDispatcherNode, type:string)
---@param dis EventDispatcherNode
---@param type string
---@param callback fun(data:EventData)
function m:RemoveEvent(dis, type, callback) end

function m:RemoveAll() end

InterchangeableEventListenerMgr = m
return m
