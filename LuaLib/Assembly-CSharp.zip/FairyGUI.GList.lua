---@class FairyGUI.GList : FairyGUI.GComponent
---@field public defaultItem string
---@field public foldInvisibleItems boolean
---@field public selectionMode FairyGUI.ListSelectionMode
---@field public itemRenderer fun(index:number, item:FairyGUI.GObject)
---@field public itemProvider fun(index:number):
---@field public scrollItemToViewOnClick boolean
---@field public onClickItem FairyGUI.EventListener
---@field public onRightClickItem FairyGUI.EventListener
---@field public layout FairyGUI.ListLayoutType
---@field public lineCount number
---@field public columnCount number
---@field public lineGap number
---@field public columnGap number
---@field public align FairyGUI.AlignType
---@field public verticalAlign FairyGUI.VertAlignType
---@field public autoResizeItem boolean
---@field public itemPool FairyGUI.GObjectPool
---@field public selectedIndex number
---@field public selectionController FairyGUI.Controller
---@field public touchItem FairyGUI.GObject
---@field public isVirtual boolean
---@field public numItems number
local m = {}

---@virtual
function m:Dispose() end

---@param url string
---@return FairyGUI.GObject
function m:GetFromPool(url) end

---@overload fun(url:string):
---@return FairyGUI.GObject
function m:AddItemFromPool() end

---@virtual
---@param child FairyGUI.GObject
---@param index number
---@return FairyGUI.GObject
function m:AddChildAt(child, index) end

---@virtual
---@param index number
---@param dispose boolean
---@return FairyGUI.GObject
function m:RemoveChildAt(index, dispose) end

---@param index number
function m:RemoveChildToPoolAt(index) end

---@param child FairyGUI.GObject
function m:RemoveChildToPool(child) end

---@overload fun(beginIndex:number, endIndex:number)
function m:RemoveChildrenToPool() end

---@return number[]
function m:GetSelection() end

---@param index number
---@param scrollItToView boolean
function m:AddSelection(index, scrollItToView) end

---@param index number
function m:RemoveSelection(index) end

function m:ClearSelection() end

function m:SelectAll() end

function m:SelectNone() end

function m:SelectReverse() end

---@param dir number
function m:HandleArrowKey(dir) end

---@overload fun(itemCount:number, minSize:number)
---@param itemCount number
function m:ResizeToFit(itemCount) end

---@virtual
---@param c FairyGUI.Controller
function m:HandleControllerChanged(c) end

---@overload fun(index:number, ani:boolean)
---@overload fun(index:number, ani:boolean, setFirst:boolean)
---@param index number
function m:ScrollToView(index) end

---@virtual
---@return number
function m:GetFirstChildInView() end

---@param index number
---@return number
function m:ChildIndexToItemIndex(index) end

---@param index number
---@return number
function m:ItemIndexToChildIndex(index) end

function m:SetVirtual() end

function m:SetVirtualAndLoop() end

function m:RefreshVirtualList() end

---@virtual
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos number
function m:Setup_BeforeAdd(buffer, beginPos) end

---@virtual
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos number
function m:Setup_AfterAdd(buffer, beginPos) end

FairyGUI.GList = m
return m
