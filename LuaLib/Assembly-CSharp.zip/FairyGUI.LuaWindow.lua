---@class FairyGUI.LuaWindow : FairyGUI.Window
local m = {}

---@param peerTable LuaInterface.LuaTable
function m:SetLuaTalbe(peerTable) end

---@virtual
function m:Dispose() end

FairyGUI.LuaWindow = m
return m
