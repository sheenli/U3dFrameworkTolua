---@class FairyGUI.GGroup : FairyGUI.GObject
---@field public layout FairyGUI.GroupLayoutType
---@field public lineGap number
---@field public columnGap number
local m = {}

---@overload fun()
---@param childSizeChanged boolean
function m:SetBoundsChangedFlag(childSizeChanged) end

function m:EnsureBoundsCorrect() end

---@virtual
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos number
function m:Setup_BeforeAdd(buffer, beginPos) end

---@virtual
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos number
function m:Setup_AfterAdd(buffer, beginPos) end

FairyGUI.GGroup = m
return m
