---@class FairyGUI.BlendModeUtils.BlendFactor : System.Object
---@field public srcFactor UnityEngine.Rendering.BlendMode
---@field public dstFactor UnityEngine.Rendering.BlendMode
---@field public pma boolean
local m = {}

FairyGUI.BlendModeUtils.BlendFactor = m
return m
