---@class FairyGUI.GoWrapper : FairyGUI.DisplayObject
---@field public supportStencil boolean
---@field public wrapTarget UnityEngine.GameObject
---@field public renderingOrder number
---@field public layer number
local m = {}

---@param target UnityEngine.GameObject
---@param cloneMaterial boolean
function m:setWrapTarget(target, cloneMaterial) end

function m:CacheRenderers() end

---@virtual
---@param context FairyGUI.UpdateContext
function m:Update(context) end

---@virtual
function m:Dispose() end

FairyGUI.GoWrapper = m
return m
