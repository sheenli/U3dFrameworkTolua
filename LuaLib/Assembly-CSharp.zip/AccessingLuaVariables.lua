---@class AccessingLuaVariables : UnityEngine.MonoBehaviour
local m = {}

AccessingLuaVariables = m
return m
