---@class FairyGUI.TypingEffect : System.Object
local m = {}

function m:Start() end

---@overload fun(interval:number):
---@return boolean
function m:Print() end

---@param interval number
function m:PrintAll(interval) end

function m:Cancel() end

FairyGUI.TypingEffect = m
return m
