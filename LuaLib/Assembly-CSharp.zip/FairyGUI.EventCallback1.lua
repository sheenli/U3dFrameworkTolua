---@class FairyGUI.EventCallback1 : System.MulticastDelegate
local m = {}

---@virtual
---@param context FairyGUI.EventContext
function m:Invoke(context) end

---@virtual
---@param context FairyGUI.EventContext
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(context, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

FairyGUI.EventCallback1 = m
return m
