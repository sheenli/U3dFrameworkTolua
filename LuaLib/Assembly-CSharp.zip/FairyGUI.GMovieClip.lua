---@class FairyGUI.GMovieClip : FairyGUI.GObject
---@field public onPlayEnd FairyGUI.EventListener
---@field public playing boolean
---@field public frame number
---@field public color UnityEngine.Color
---@field public flip FairyGUI.FlipType
---@field public material UnityEngine.Material
---@field public shader string
---@field public timeScale number
---@field public ignoreEngineTimeScale boolean
local m = {}

function m:Rewind() end

---@param anotherMc FairyGUI.GMovieClip
function m:SyncStatus(anotherMc) end

---@virtual
---@param time number
function m:Advance(time) end

---@param start number
---@param _end number
---@param times number
---@param endAt number
function m:SetPlaySettings(start, _end, times, endAt) end

---@virtual
function m:ConstructFromResource() end

---@virtual
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos number
function m:Setup_BeforeAdd(buffer, beginPos) end

FairyGUI.GMovieClip = m
return m
