---@class SevenZip.LzmaBench.CBitRandomGenerator : System.Object
local m = {}

function m:Init() end

---@param numBits number
---@return number
function m:GetRnd(numBits) end

SevenZip.LzmaBench.CBitRandomGenerator = m
return m
