---@class LuaInterface.InjectType : System.Enum
---@field public None LuaInterface.InjectType @static
---@field public After LuaInterface.InjectType @static
---@field public Before LuaInterface.InjectType @static
---@field public Replace LuaInterface.InjectType @static
---@field public ReplaceWithPreInvokeBase LuaInterface.InjectType @static
---@field public ReplaceWithPostInvokeBase LuaInterface.InjectType @static
---@field public value__ number
local m = {}

LuaInterface.InjectType = m
return m
