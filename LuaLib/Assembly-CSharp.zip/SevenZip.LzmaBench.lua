---@class SevenZip.LzmaBench : System.Object
local m = {}

---@static
---@param numIterations number
---@param dictionarySize number
---@return number
function m.LzmaBenchmark(numIterations, dictionarySize) end

SevenZip.LzmaBench = m
return m
