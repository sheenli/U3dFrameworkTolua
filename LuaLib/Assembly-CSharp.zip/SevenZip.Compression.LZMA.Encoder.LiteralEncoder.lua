---@class SevenZip.Compression.LZMA.Encoder.LiteralEncoder : System.Object
local m = {}

---@param numPosBits number
---@param numPrevBits number
function m:Create(numPosBits, numPrevBits) end

function m:Init() end

---@param pos number
---@param prevByte number
---@return SevenZip.Compression.LZMA.Encoder.LiteralEncoder.Encoder2
function m:GetSubCoder(pos, prevByte) end

SevenZip.Compression.LZMA.Encoder.LiteralEncoder = m
return m
