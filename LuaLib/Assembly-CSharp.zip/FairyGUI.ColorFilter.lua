---@class FairyGUI.ColorFilter : System.Object
---@field public target FairyGUI.DisplayObject
local m = {}

---@virtual
function m:Dispose() end

---@virtual
function m:Update() end

function m:Invert() end

---@param sat number
function m:AdjustSaturation(sat) end

---@param value number
function m:AdjustContrast(value) end

---@param value number
function m:AdjustBrightness(value) end

---@param value number
function m:AdjustHue(value) end

---@overload fun(color:UnityEngine.Color)
---@param color UnityEngine.Color
---@param amount number
function m:Tint(color, amount) end

function m:Reset() end

---@overload fun()
---@param ... number|number[]
function m:ConcatValues(...) end

FairyGUI.ColorFilter = m
return m
