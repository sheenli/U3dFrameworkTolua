---@class WXConstant : System.Object
---@field public WXAPPIDS table<number, string> @static
---@field public TransferWXAPPIDS table<number, string> @static
---@field public XLAppID table<number, string> @static
---@field public UMengAppID table<number, string> @static
---@field public UMengPushSecret table<number, string> @static
local m = {}

WXConstant = m
return m
