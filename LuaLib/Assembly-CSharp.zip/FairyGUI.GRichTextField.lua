---@class FairyGUI.GRichTextField : FairyGUI.GTextField
---@field public richTextField FairyGUI.RichTextField
---@field public emojies table<number, FairyGUI.Emoji>
local m = {}

FairyGUI.GRichTextField = m
return m
