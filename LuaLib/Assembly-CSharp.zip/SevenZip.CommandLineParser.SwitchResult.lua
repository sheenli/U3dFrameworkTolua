---@class SevenZip.CommandLineParser.SwitchResult : System.Object
---@field public ThereIs boolean
---@field public WithMinus boolean
---@field public PostStrings System.Collections.ArrayList
---@field public PostCharIndex number
local m = {}

SevenZip.CommandLineParser.SwitchResult = m
return m
