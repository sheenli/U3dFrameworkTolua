---@class EventDispatcherNode : LogicNode
local m = {}

---@param type string
---@param _listener fun(data:EventData)
---@return boolean
function m:HasListener(type, _listener) end

---@overload fun(type:number, _listener:fun(data:EventData), _priority:number)
---@overload fun(type:number, _listener:fun(data:EventData))
---@overload fun(type:string, _listener:fun(data:EventData), _priority:number, _dispatchOnce:boolean)
---@overload fun(type:string, _listener:fun(data:EventData), _priority:number)
---@overload fun(type:string, _listener:fun(data:EventData))
---@param type number
---@param _listener fun(data:EventData)
---@param _priority number
---@param _dispatchOnce boolean
function m:AttachListener(type, _listener, _priority, _dispatchOnce) end

---@overload fun(type:string, _listener:fun(data:EventData))
---@param type number
---@param _listener fun(data:EventData)
function m:DetachListener(type, _listener) end

---@virtual
function m:OnUpdate() end

---@overload fun(key:string)
---@overload fun(key:number, value:any)
---@overload fun(key:number, value:number)
---@overload fun(key:number, value:string)
---@overload fun(key:string, value:any)
---@overload fun(data:EventData)
---@param key number
function m:QueueEvent(key) end

---@return EventData
function m:GetEventData() end

---@param key string
---@param data any
function m:QueueEventLua(key, data) end

---@overload fun(key:string, value:any)
---@overload fun(data:EventData)
---@param key string
function m:QueueEventNow(key) end

EventDispatcherNode = m
return m
