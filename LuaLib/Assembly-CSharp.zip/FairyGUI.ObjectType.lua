---@class FairyGUI.ObjectType : System.Enum
---@field public Image FairyGUI.ObjectType @static
---@field public MovieClip FairyGUI.ObjectType @static
---@field public Swf FairyGUI.ObjectType @static
---@field public Graph FairyGUI.ObjectType @static
---@field public Loader FairyGUI.ObjectType @static
---@field public Group FairyGUI.ObjectType @static
---@field public Text FairyGUI.ObjectType @static
---@field public RichText FairyGUI.ObjectType @static
---@field public InputText FairyGUI.ObjectType @static
---@field public Component FairyGUI.ObjectType @static
---@field public List FairyGUI.ObjectType @static
---@field public Label FairyGUI.ObjectType @static
---@field public Button FairyGUI.ObjectType @static
---@field public ComboBox FairyGUI.ObjectType @static
---@field public ProgressBar FairyGUI.ObjectType @static
---@field public Slider FairyGUI.ObjectType @static
---@field public ScrollBar FairyGUI.ObjectType @static
---@field public value__ number
local m = {}

FairyGUI.ObjectType = m
return m
