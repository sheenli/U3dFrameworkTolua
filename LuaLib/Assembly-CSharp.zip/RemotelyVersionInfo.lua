---@class RemotelyVersionInfo : System.Object
---@field public vers RemotelyVersionInfo.RemotelyInfo[]
local m = {}

RemotelyVersionInfo = m
return m
