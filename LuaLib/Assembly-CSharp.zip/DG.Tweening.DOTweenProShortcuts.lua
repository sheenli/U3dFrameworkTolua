---@class DG.Tweening.DOTweenProShortcuts : System.Object
local m = {}

---@overload fun(target:UnityEngine.Transform, duration:number, axis:System.Nullable_1_UnityEngine_Vector3_, mode:DG.Tweening.SpiralMode, speed:number, frequency:number, depth:number): @static
---@overload fun(target:UnityEngine.Transform, duration:number, axis:System.Nullable_1_UnityEngine_Vector3_, mode:DG.Tweening.SpiralMode, speed:number, frequency:number): @static
---@overload fun(target:UnityEngine.Transform, duration:number, axis:System.Nullable_1_UnityEngine_Vector3_, mode:DG.Tweening.SpiralMode, speed:number): @static
---@overload fun(target:UnityEngine.Transform, duration:number, axis:System.Nullable_1_UnityEngine_Vector3_, mode:DG.Tweening.SpiralMode): @static
---@overload fun(target:UnityEngine.Transform, duration:number, axis:System.Nullable_1_UnityEngine_Vector3_): @static
---@overload fun(target:UnityEngine.Transform, duration:number): @static
---@overload fun(target:UnityEngine.Rigidbody, duration:number, axis:System.Nullable_1_UnityEngine_Vector3_, mode:DG.Tweening.SpiralMode, speed:number, frequency:number, depth:number, snapping:boolean): @static
---@overload fun(target:UnityEngine.Rigidbody, duration:number, axis:System.Nullable_1_UnityEngine_Vector3_, mode:DG.Tweening.SpiralMode, speed:number, frequency:number, depth:number): @static
---@overload fun(target:UnityEngine.Rigidbody, duration:number, axis:System.Nullable_1_UnityEngine_Vector3_, mode:DG.Tweening.SpiralMode, speed:number, frequency:number): @static
---@overload fun(target:UnityEngine.Rigidbody, duration:number, axis:System.Nullable_1_UnityEngine_Vector3_, mode:DG.Tweening.SpiralMode, speed:number): @static
---@overload fun(target:UnityEngine.Rigidbody, duration:number, axis:System.Nullable_1_UnityEngine_Vector3_, mode:DG.Tweening.SpiralMode): @static
---@overload fun(target:UnityEngine.Rigidbody, duration:number, axis:System.Nullable_1_UnityEngine_Vector3_): @static
---@overload fun(target:UnityEngine.Rigidbody, duration:number): @static
---@static
---@param target UnityEngine.Transform
---@param duration number
---@param axis System.Nullable_1_UnityEngine_Vector3_
---@param mode DG.Tweening.SpiralMode
---@param speed number
---@param frequency number
---@param depth number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOSpiral(target, duration, axis, mode, speed, frequency, depth, snapping) end

DG.Tweening.DOTweenProShortcuts = m
return m
