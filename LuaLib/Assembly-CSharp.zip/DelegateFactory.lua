---@class DelegateFactory : System.Object
---@field public dict table<System.Type, fun(func:LuaInterface.LuaFunction, self:LuaInterface.LuaTable, flag:boolean):> @static
local m = {}

---@static
function m.Init() end

---@static
function m.Register() end

---@overload fun(t:System.Type): @static
---@overload fun(t:System.Type, func:LuaInterface.LuaFunction, self:LuaInterface.LuaTable): @static
---@static
---@param t System.Type
---@param func LuaInterface.LuaFunction
---@return fun(...:any|any[]):
function m.CreateDelegate(t, func) end

---@overload fun(obj:fun(...:any|any[]):, dg:fun(...:any|any[]):): @static
---@static
---@param obj fun(...:any|any[]):
---@param func LuaInterface.LuaFunction
---@return fun(...:any|any[]):
function m.RemoveDelegate(obj, func) end

DelegateFactory = m
return m
