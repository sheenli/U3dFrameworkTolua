---@class FairyGUI.BlendMode : System.Enum
---@field public Normal FairyGUI.BlendMode @static
---@field public None FairyGUI.BlendMode @static
---@field public Add FairyGUI.BlendMode @static
---@field public Multiply FairyGUI.BlendMode @static
---@field public Screen FairyGUI.BlendMode @static
---@field public Erase FairyGUI.BlendMode @static
---@field public Mask FairyGUI.BlendMode @static
---@field public Below FairyGUI.BlendMode @static
---@field public Off FairyGUI.BlendMode @static
---@field public Custom1 FairyGUI.BlendMode @static
---@field public Custom2 FairyGUI.BlendMode @static
---@field public Custom3 FairyGUI.BlendMode @static
---@field public value__ number
local m = {}

FairyGUI.BlendMode = m
return m
