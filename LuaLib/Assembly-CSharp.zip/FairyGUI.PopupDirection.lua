---@class FairyGUI.PopupDirection : System.Enum
---@field public Auto FairyGUI.PopupDirection @static
---@field public Up FairyGUI.PopupDirection @static
---@field public Down FairyGUI.PopupDirection @static
---@field public value__ number
local m = {}

FairyGUI.PopupDirection = m
return m
