---@class FairyGUI.TextField.LineInfo : System.Object
---@field public width number
---@field public height number
---@field public textHeight number
---@field public charIndex number
---@field public charCount number
---@field public y number
local m = {}

---@static
---@return FairyGUI.TextField.LineInfo
function m.Borrow() end

---@overload fun(values:FairyGUI.TextField.LineInfo[]) @static
---@static
---@param value FairyGUI.TextField.LineInfo
function m.Return(value) end

FairyGUI.TextField.LineInfo = m
return m
