---@class SevenZip.CDoubleStream : System.IO.Stream
---@field public s1 System.IO.Stream
---@field public s2 System.IO.Stream
---@field public fileIndex number
---@field public skipSize number
---@field public CanRead boolean
---@field public CanWrite boolean
---@field public CanSeek boolean
---@field public Length number
---@field public Position number
local m = {}

---@virtual
function m:Flush() end

---@virtual
---@param buffer string
---@param offset number
---@param count number
---@return number
function m:Read(buffer, offset, count) end

---@virtual
---@param buffer string
---@param offset number
---@param count number
function m:Write(buffer, offset, count) end

---@virtual
---@param offset number
---@param origin System.IO.SeekOrigin
---@return number
function m:Seek(offset, origin) end

---@virtual
---@param value number
function m:SetLength(value) end

SevenZip.CDoubleStream = m
return m
