---@class SevenZip.InvalidParamException : System.ApplicationException
local m = {}

SevenZip.InvalidParamException = m
return m
