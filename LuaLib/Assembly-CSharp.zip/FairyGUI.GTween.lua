---@class FairyGUI.GTween : System.Object
---@field public catchCallbackExceptions boolean @static
local m = {}

---@overload fun(startValue:UnityEngine.Vector2, endValue:UnityEngine.Vector2, duration:number): @static
---@overload fun(startValue:UnityEngine.Vector3, endValue:UnityEngine.Vector3, duration:number): @static
---@overload fun(startValue:UnityEngine.Vector4, endValue:UnityEngine.Vector4, duration:number): @static
---@overload fun(startValue:UnityEngine.Color, endValue:UnityEngine.Color, duration:number): @static
---@static
---@param startValue number
---@param endValue number
---@param duration number
---@return FairyGUI.GTweener
function m.To(startValue, endValue, duration) end

---@static
---@param startValue number
---@param endValue number
---@param duration number
---@return FairyGUI.GTweener
function m.ToDouble(startValue, endValue, duration) end

---@static
---@param delay number
---@return FairyGUI.GTweener
function m.DelayedCall(delay) end

---@static
---@param startValue UnityEngine.Vector3
---@param amplitude number
---@param duration number
---@return FairyGUI.GTweener
function m.Shake(startValue, amplitude, duration) end

---@overload fun(target:any, propType:FairyGUI.TweenPropType): @static
---@static
---@param target any
---@return boolean
function m.IsTweening(target) end

---@overload fun(target:any, complete:boolean) @static
---@overload fun(target:any, propType:FairyGUI.TweenPropType, complete:boolean) @static
---@static
---@param target any
function m.Kill(target) end

---@overload fun(target:any, propType:FairyGUI.TweenPropType): @static
---@static
---@param target any
---@return FairyGUI.GTweener
function m.GetTween(target) end

---@static
function m.Clean() end

FairyGUI.GTween = m
return m
