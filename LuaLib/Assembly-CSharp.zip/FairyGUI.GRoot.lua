---@class FairyGUI.GRoot : FairyGUI.GComponent
---@field public contentScaleFactor number @static
---@field public inst FairyGUI.GRoot @static
---@field public modalLayer FairyGUI.GGraph
---@field public hasModalWindow boolean
---@field public modalWaiting boolean
---@field public touchTarget FairyGUI.GObject
---@field public hasAnyPopup boolean
---@field public focus FairyGUI.GObject
---@field public soundVolume number
local m = {}

---@overload fun(designResolutionX:number, designResolutionY:number, screenMatchMode:FairyGUI.UIContentScaler.ScreenMatchMode)
---@param designResolutionX number
---@param designResolutionY number
function m:SetContentScaleFactor(designResolutionX, designResolutionY) end

function m:ApplyContentScaleFactor() end

---@param win FairyGUI.Window
function m:ShowWindow(win) end

---@param win FairyGUI.Window
function m:HideWindow(win) end

---@overload fun(win:FairyGUI.Window, dispose:boolean)
---@param win FairyGUI.Window
function m:HideWindowImmediately(win) end

---@param win FairyGUI.Window
function m:BringToFront(win) end

function m:ShowModalWait() end

function m:CloseModalWait() end

function m:CloseAllExceptModals() end

function m:CloseAllWindows() end

---@return FairyGUI.Window
function m:GetTopWindow() end

---@param obj FairyGUI.DisplayObject
---@return FairyGUI.GObject
function m:DisplayObjectToGObject(obj) end

---@overload fun(popup:FairyGUI.GObject, target:FairyGUI.GObject)
---@overload fun(popup:FairyGUI.GObject, target:FairyGUI.GObject, downward:any)
---@param popup FairyGUI.GObject
function m:ShowPopup(popup) end

---@param popup FairyGUI.GObject
---@param target FairyGUI.GObject
---@param downward any
---@return UnityEngine.Vector2
function m:GetPoupPosition(popup, target, downward) end

---@overload fun(popup:FairyGUI.GObject, target:FairyGUI.GObject)
---@overload fun(popup:FairyGUI.GObject, target:FairyGUI.GObject, downward:any)
---@param popup FairyGUI.GObject
function m:TogglePopup(popup) end

---@overload fun(popup:FairyGUI.GObject)
function m:HidePopup() end

---@param msg string
function m:ShowTooltips(msg) end

---@param tooltipWin FairyGUI.GObject
function m:ShowTooltipsWin(tooltipWin) end

function m:HideTooltips() end

function m:EnableSound() end

function m:DisableSound() end

---@overload fun(clip:UnityEngine.AudioClip)
---@param clip UnityEngine.AudioClip
---@param volumeScale number
function m:PlayOneShotSound(clip, volumeScale) end

FairyGUI.GRoot = m
return m
