---@class FairyGUI.FillMethod : System.Enum
---@field public None FairyGUI.FillMethod @static
---@field public Horizontal FairyGUI.FillMethod @static
---@field public Vertical FairyGUI.FillMethod @static
---@field public Radial90 FairyGUI.FillMethod @static
---@field public Radial180 FairyGUI.FillMethod @static
---@field public Radial360 FairyGUI.FillMethod @static
---@field public value__ number
local m = {}

FairyGUI.FillMethod = m
return m
