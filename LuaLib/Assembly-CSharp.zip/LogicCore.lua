---@class LogicCore : EventDispatcherNode
---@field public Instance LogicCore @static
local m = {}

function m:Awake() end

LogicCore = m
return m
