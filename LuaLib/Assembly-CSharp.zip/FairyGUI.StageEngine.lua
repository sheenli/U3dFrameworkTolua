---@class FairyGUI.StageEngine : UnityEngine.MonoBehaviour
---@field public beingQuit boolean @static
---@field public ObjectsOnStage number
---@field public GraphicsOnStage number
local m = {}

FairyGUI.StageEngine = m
return m
