---@class FlyingWormConsole3.ConsoleProRemoteServer.QueuedLog : System.Object
---@field public message string
---@field public stackTrace string
---@field public type UnityEngine.LogType
local m = {}

FlyingWormConsole3.ConsoleProRemoteServer.QueuedLog = m
return m
