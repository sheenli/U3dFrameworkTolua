---@class FairyGUI.ITweenListener : table
local m = {}

---@abstract
---@param tweener FairyGUI.GTweener
function m:OnTweenStart(tweener) end

---@abstract
---@param tweener FairyGUI.GTweener
function m:OnTweenUpdate(tweener) end

---@abstract
---@param tweener FairyGUI.GTweener
function m:OnTweenComplete(tweener) end

FairyGUI.ITweenListener = m
return m
