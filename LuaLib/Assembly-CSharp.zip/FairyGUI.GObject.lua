---@class FairyGUI.GObject : FairyGUI.EventDispatcher
---@field public draggingObject FairyGUI.GObject @static
---@field public name string
---@field public data any
---@field public sourceWidth number
---@field public sourceHeight number
---@field public initWidth number
---@field public initHeight number
---@field public minWidth number
---@field public maxWidth number
---@field public minHeight number
---@field public maxHeight number
---@field public dragBounds System.Nullable_1_UnityEngine_Rect_
---@field public packageItem FairyGUI.PackageItem
---@field public id string
---@field public relations FairyGUI.Relations
---@field public parent FairyGUI.GComponent
---@field public displayObject FairyGUI.DisplayObject
---@field public onClick FairyGUI.EventListener
---@field public onRightClick FairyGUI.EventListener
---@field public onTouchBegin FairyGUI.EventListener
---@field public onTouchMove FairyGUI.EventListener
---@field public onTouchEnd FairyGUI.EventListener
---@field public onRollOver FairyGUI.EventListener
---@field public onRollOut FairyGUI.EventListener
---@field public onAddedToStage FairyGUI.EventListener
---@field public onRemovedFromStage FairyGUI.EventListener
---@field public onKeyDown FairyGUI.EventListener
---@field public onClickLink FairyGUI.EventListener
---@field public onPositionChanged FairyGUI.EventListener
---@field public onSizeChanged FairyGUI.EventListener
---@field public onDragStart FairyGUI.EventListener
---@field public onDragMove FairyGUI.EventListener
---@field public onDragEnd FairyGUI.EventListener
---@field public OnGearStop FairyGUI.EventListener
---@field public x number
---@field public y number
---@field public z number
---@field public xy UnityEngine.Vector2
---@field public position UnityEngine.Vector3
---@field public pixelSnapping boolean
---@field public width number
---@field public height number
---@field public size UnityEngine.Vector2
---@field public actualWidth number
---@field public actualHeight number
---@field public xMin number
---@field public yMin number
---@field public scaleX number
---@field public scaleY number
---@field public scale UnityEngine.Vector2
---@field public skew UnityEngine.Vector2
---@field public pivotX number
---@field public pivotY number
---@field public pivot UnityEngine.Vector2
---@field public pivotAsAnchor boolean
---@field public touchable boolean
---@field public grayed boolean
---@field public enabled boolean
---@field public rotation number
---@field public rotationX number
---@field public rotationY number
---@field public alpha number
---@field public visible boolean
---@field public sortingOrder number
---@field public focusable boolean
---@field public focused boolean
---@field public tooltips string
---@field public filter FairyGUI.IFilter
---@field public blendMode FairyGUI.BlendMode
---@field public gameObjectName string
---@field public inContainer boolean
---@field public onStage boolean
---@field public resourceURL string
---@field public gearXY FairyGUI.GearXY
---@field public gearSize FairyGUI.GearSize
---@field public gearLook FairyGUI.GearLook
---@field public group FairyGUI.GGroup
---@field public root FairyGUI.GRoot
---@field public text string
---@field public icon string
---@field public draggable boolean
---@field public dragging boolean
---@field public asImage FairyGUI.GImage
---@field public asCom FairyGUI.GComponent
---@field public asButton FairyGUI.GButton
---@field public asLabel FairyGUI.GLabel
---@field public asProgress FairyGUI.GProgressBar
---@field public asSlider FairyGUI.GSlider
---@field public asComboBox FairyGUI.GComboBox
---@field public asTextField FairyGUI.GTextField
---@field public asRichTextField FairyGUI.GRichTextField
---@field public asTextInput FairyGUI.GTextInput
---@field public asLoader FairyGUI.GLoader
---@field public asList FairyGUI.GList
---@field public asGraph FairyGUI.GGraph
---@field public asGroup FairyGUI.GGroup
---@field public asMovieClip FairyGUI.GMovieClip
local m = {}

---@overload fun(xv:number, yv:number, topLeftValue:boolean)
---@param xv number
---@param yv number
function m:SetXY(xv, yv) end

---@param xv number
---@param yv number
---@param zv number
function m:SetPosition(xv, yv, zv) end

---@overload fun(restraint:boolean)
function m:Center() end

function m:MakeFullScreen() end

---@overload fun(wv:number, hv:number, ignorePivot:boolean)
---@param wv number
---@param hv number
function m:SetSize(wv, hv) end

---@param wv number
---@param hv number
function m:SetScale(wv, hv) end

---@overload fun(xv:number, yv:number, asAnchor:boolean)
---@param xv number
---@param yv number
function m:SetPivot(xv, yv) end

function m:RequestFocus() end

---@param obj FairyGUI.GObject
function m:SetHome(obj) end

---@param index number
---@return FairyGUI.GearBase
function m:GetGear(index) end

function m:InvalidateBatchingState() end

---@virtual
---@param c FairyGUI.Controller
function m:HandleControllerChanged(c) end

---@overload fun(target:FairyGUI.GObject, relationType:FairyGUI.RelationType, usePercent:boolean)
---@param target FairyGUI.GObject
---@param relationType FairyGUI.RelationType
function m:AddRelation(target, relationType) end

---@param target FairyGUI.GObject
---@param relationType FairyGUI.RelationType
function m:RemoveRelation(target, relationType) end

function m:RemoveFromParent() end

---@overload fun(touchId:number)
function m:StartDrag() end

function m:StopDrag() end

---@overload fun(rect:UnityEngine.Rect):
---@param pt UnityEngine.Vector2
---@return UnityEngine.Vector2
function m:LocalToGlobal(pt) end

---@overload fun(rect:UnityEngine.Rect):
---@param pt UnityEngine.Vector2
---@return UnityEngine.Vector2
function m:GlobalToLocal(pt) end

---@param pt UnityEngine.Vector2
---@param r FairyGUI.GRoot
---@return UnityEngine.Vector2
function m:LocalToRoot(pt, r) end

---@param pt UnityEngine.Vector2
---@param r FairyGUI.GRoot
---@return UnityEngine.Vector2
function m:RootToLocal(pt, r) end

---@overload fun(pt:UnityEngine.Vector3, camera:UnityEngine.Camera):
---@param pt UnityEngine.Vector3
---@return UnityEngine.Vector2
function m:WorldToLocal(pt) end

---@param pt UnityEngine.Vector2
---@param targetSpace FairyGUI.GObject
---@return UnityEngine.Vector2
function m:TransformPoint(pt, targetSpace) end

---@param rect UnityEngine.Rect
---@param targetSpace FairyGUI.GObject
---@return UnityEngine.Rect
function m:TransformRect(rect, targetSpace) end

---@virtual
function m:Dispose() end

---@virtual
function m:ConstructFromResource() end

---@virtual
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos number
function m:Setup_BeforeAdd(buffer, beginPos) end

---@virtual
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos number
function m:Setup_AfterAdd(buffer, beginPos) end

---@param endValue UnityEngine.Vector2
---@param duration number
---@return FairyGUI.GTweener
function m:TweenMove(endValue, duration) end

---@param endValue number
---@param duration number
---@return FairyGUI.GTweener
function m:TweenMoveX(endValue, duration) end

---@param endValue number
---@param duration number
---@return FairyGUI.GTweener
function m:TweenMoveY(endValue, duration) end

---@param endValue UnityEngine.Vector2
---@param duration number
---@return FairyGUI.GTweener
function m:TweenScale(endValue, duration) end

---@param endValue number
---@param duration number
---@return FairyGUI.GTweener
function m:TweenScaleX(endValue, duration) end

---@param endValue number
---@param duration number
---@return FairyGUI.GTweener
function m:TweenScaleY(endValue, duration) end

---@param endValue UnityEngine.Vector2
---@param duration number
---@return FairyGUI.GTweener
function m:TweenResize(endValue, duration) end

---@param endValue number
---@param duration number
---@return FairyGUI.GTweener
function m:TweenFade(endValue, duration) end

---@param endValue number
---@param duration number
---@return FairyGUI.GTweener
function m:TweenRotate(endValue, duration) end

FairyGUI.GObject = m
return m
