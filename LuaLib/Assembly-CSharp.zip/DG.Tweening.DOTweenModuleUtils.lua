---@class DG.Tweening.DOTweenModuleUtils : System.Object
local m = {}

---@static
function m.Init() end

DG.Tweening.DOTweenModuleUtils = m
return m
