---@class FairyGUI.ChangePageAction : FairyGUI.ControllerAction
---@field public objectId string
---@field public controllerName string
---@field public targetPage string
local m = {}

---@virtual
---@param buffer FairyGUI.Utils.ByteBuffer
function m:Setup(buffer) end

FairyGUI.ChangePageAction = m
return m
