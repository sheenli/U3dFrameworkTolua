---@class FairyGUI.RectHitTest : System.Object
---@field public rect UnityEngine.Rect
local m = {}

---@virtual
---@param value boolean
function m:SetEnabled(value) end

---@virtual
---@param container FairyGUI.Container
---@param localPoint UnityEngine.Vector2
---@return boolean, UnityEngine.Vector2
function m:HitTest(container, localPoint) end

FairyGUI.RectHitTest = m
return m
