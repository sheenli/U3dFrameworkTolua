---@class FairyGUI.GTweener : System.Object
---@field public delay number
---@field public duration number
---@field public repeat number
---@field public target any
---@field public userData any
---@field public startValue FairyGUI.TweenValue
---@field public endValue FairyGUI.TweenValue
---@field public value FairyGUI.TweenValue
---@field public deltaValue FairyGUI.TweenValue
---@field public normalizedTime number
---@field public completed boolean
---@field public allCompleted boolean
local m = {}

---@param value number
---@return FairyGUI.GTweener
function m:SetDelay(value) end

---@param value number
---@return FairyGUI.GTweener
function m:SetDuration(value) end

---@param value number
---@return FairyGUI.GTweener
function m:SetBreakpoint(value) end

---@param value FairyGUI.EaseType
---@return FairyGUI.GTweener
function m:SetEase(value) end

---@param value number
---@return FairyGUI.GTweener
function m:SetEasePeriod(value) end

---@param value number
---@return FairyGUI.GTweener
function m:SetEaseOvershootOrAmplitude(value) end

---@overload fun(repeat:number):
---@param repeat number
---@param yoyo boolean
---@return FairyGUI.GTweener
function m:SetRepeat(repeat, yoyo) end

---@param value number
---@return FairyGUI.GTweener
function m:SetTimeScale(value) end

---@param value boolean
---@return FairyGUI.GTweener
function m:SetIgnoreEngineTimeScale(value) end

---@param value boolean
---@return FairyGUI.GTweener
function m:SetSnapping(value) end

---@overload fun(value:any, propType:FairyGUI.TweenPropType):
---@param value any
---@return FairyGUI.GTweener
function m:SetTarget(value) end

---@param value any
---@return FairyGUI.GTweener
function m:SetUserData(value) end

---@overload fun(callback:fun(tweener:FairyGUI.GTweener)):
---@param callback fun()
---@return FairyGUI.GTweener
function m:OnUpdate(callback) end

---@overload fun(callback:fun(tweener:FairyGUI.GTweener)):
---@param callback fun()
---@return FairyGUI.GTweener
function m:OnStart(callback) end

---@overload fun(callback:fun(tweener:FairyGUI.GTweener)):
---@param callback fun()
---@return FairyGUI.GTweener
function m:OnComplete(callback) end

---@param value FairyGUI.ITweenListener
---@return FairyGUI.GTweener
function m:SetListener(value) end

---@param paused boolean
---@return FairyGUI.GTweener
function m:SetPaused(paused) end

---@param time number
function m:Seek(time) end

---@overload fun()
---@param complete boolean
function m:Kill(complete) end

FairyGUI.GTweener = m
return m
