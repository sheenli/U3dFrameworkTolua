---@class CompressHelper : System.Object
local m = {}

---@static
---@param inStream System.IO.Stream
---@param outStream System.IO.Stream
function m.LZMAEncode(inStream, outStream) end

---@static
---@param inStream System.IO.Stream
---@param outStream System.IO.Stream
function m.LZMADecode(inStream, outStream) end

---@static
---@param inFile string
---@param outFile string
function m.CompressFileLZMA(inFile, outFile) end

---@static
---@param inFile string
---@param outFile string
function m.DecompressFileLZMA(inFile, outFile) end

---@static
---@param www UnityEngine.WWW
---@param outFile string
function m.DecompressWWWLZMA(www, outFile) end

---@static
function m.test() end

---@overload fun(bytes:string): @static
---@static
---@param bytes string
---@param outFile string
function m.DecompressBytesLZMA(bytes, outFile) end

---@static
---@param bytes string
---@param outFile string
function m.CompressBytesLZMA(bytes, outFile) end

CompressHelper = m
return m
