---@class BaseMode : System.Object
---@field public eventMgr InterchangeableEventListenerMgr
---@field public IsLoginDataOk boolean
local m = {}

---@virtual
function m:OnClear() end

---@virtual
function m:OnDestroy() end

---@virtual
function m:OnInitData() end

---@virtual
function m:OnLogin() end

BaseMode = m
return m
