---@class FairyGUI.PageOption : System.Object
---@field public controller FairyGUI.Controller
---@field public index number
---@field public name string
---@field public id string
local m = {}

function m:Clear() end

FairyGUI.PageOption = m
return m
