---@class FairyGUI.MovieClip : FairyGUI.Image
---@field public interval number
---@field public swing boolean
---@field public repeatDelay number
---@field public timeScale number
---@field public ignoreEngineTimeScale boolean
---@field public frameCount number
---@field public frames FairyGUI.MovieClip.Frame[]
---@field public onPlayEnd FairyGUI.EventListener
---@field public playing boolean
---@field public frame number
local m = {}

---@param texture FairyGUI.NTexture
---@param frames FairyGUI.MovieClip.Frame[]
---@param boundsRect UnityEngine.Rect
function m:SetData(texture, frames, boundsRect) end

function m:Clear() end

function m:Rewind() end

---@param anotherMc FairyGUI.MovieClip
function m:SyncStatus(anotherMc) end

---@param time number
function m:Advance(time) end

---@overload fun(start:number, _end:number, times:number, endAt:number)
function m:SetPlaySettings() end

---@virtual
---@param context FairyGUI.UpdateContext
function m:Update(context) end

FairyGUI.MovieClip = m
return m
