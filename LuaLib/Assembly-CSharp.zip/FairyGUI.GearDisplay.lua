---@class FairyGUI.GearDisplay : FairyGUI.GearBase
---@field public pages string[]
---@field public connected boolean
local m = {}

---@virtual
function m:Apply() end

---@virtual
function m:UpdateState() end

---@return number
function m:AddLock() end

---@param token number
function m:ReleaseLock(token) end

FairyGUI.GearDisplay = m
return m
