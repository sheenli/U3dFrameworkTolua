---@class DG.Tweening.DOTweenModulePhysics : System.Object
local m = {}

---@overload fun(target:UnityEngine.Rigidbody, endValue:UnityEngine.Vector3, duration:number): @static
---@static
---@param target UnityEngine.Rigidbody
---@param endValue UnityEngine.Vector3
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOMove(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.Rigidbody, endValue:number, duration:number): @static
---@static
---@param target UnityEngine.Rigidbody
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOMoveX(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.Rigidbody, endValue:number, duration:number): @static
---@static
---@param target UnityEngine.Rigidbody
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOMoveY(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.Rigidbody, endValue:number, duration:number): @static
---@static
---@param target UnityEngine.Rigidbody
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOMoveZ(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.Rigidbody, endValue:UnityEngine.Vector3, duration:number): @static
---@static
---@param target UnityEngine.Rigidbody
---@param endValue UnityEngine.Vector3
---@param duration number
---@param mode DG.Tweening.RotateMode
---@return DG.Tweening.Tweener
function m.DORotate(target, endValue, duration, mode) end

---@overload fun(target:UnityEngine.Rigidbody, towards:UnityEngine.Vector3, duration:number, axisConstraint:DG.Tweening.AxisConstraint): @static
---@overload fun(target:UnityEngine.Rigidbody, towards:UnityEngine.Vector3, duration:number): @static
---@static
---@param target UnityEngine.Rigidbody
---@param towards UnityEngine.Vector3
---@param duration number
---@param axisConstraint DG.Tweening.AxisConstraint
---@param up System.Nullable_1_UnityEngine_Vector3_
---@return DG.Tweening.Tweener
function m.DOLookAt(target, towards, duration, axisConstraint, up) end

---@overload fun(target:UnityEngine.Rigidbody, endValue:UnityEngine.Vector3, jumpPower:number, numJumps:number, duration:number): @static
---@static
---@param target UnityEngine.Rigidbody
---@param endValue UnityEngine.Vector3
---@param jumpPower number
---@param numJumps number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Sequence
function m.DOJump(target, endValue, jumpPower, numJumps, duration, snapping) end

---@overload fun(target:UnityEngine.Rigidbody, path:UnityEngine.Vector3[], duration:number, pathType:DG.Tweening.PathType, pathMode:DG.Tweening.PathMode, resolution:number): @static
---@overload fun(target:UnityEngine.Rigidbody, path:UnityEngine.Vector3[], duration:number, pathType:DG.Tweening.PathType, pathMode:DG.Tweening.PathMode): @static
---@overload fun(target:UnityEngine.Rigidbody, path:UnityEngine.Vector3[], duration:number, pathType:DG.Tweening.PathType): @static
---@overload fun(target:UnityEngine.Rigidbody, path:UnityEngine.Vector3[], duration:number): @static
---@static
---@param target UnityEngine.Rigidbody
---@param path UnityEngine.Vector3[]
---@param duration number
---@param pathType DG.Tweening.PathType
---@param pathMode DG.Tweening.PathMode
---@param resolution number
---@param gizmoColor System.Nullable_1_UnityEngine_Color_
---@return DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_
function m.DOPath(target, path, duration, pathType, pathMode, resolution, gizmoColor) end

---@overload fun(target:UnityEngine.Rigidbody, path:UnityEngine.Vector3[], duration:number, pathType:DG.Tweening.PathType, pathMode:DG.Tweening.PathMode, resolution:number): @static
---@overload fun(target:UnityEngine.Rigidbody, path:UnityEngine.Vector3[], duration:number, pathType:DG.Tweening.PathType, pathMode:DG.Tweening.PathMode): @static
---@overload fun(target:UnityEngine.Rigidbody, path:UnityEngine.Vector3[], duration:number, pathType:DG.Tweening.PathType): @static
---@overload fun(target:UnityEngine.Rigidbody, path:UnityEngine.Vector3[], duration:number): @static
---@static
---@param target UnityEngine.Rigidbody
---@param path UnityEngine.Vector3[]
---@param duration number
---@param pathType DG.Tweening.PathType
---@param pathMode DG.Tweening.PathMode
---@param resolution number
---@param gizmoColor System.Nullable_1_UnityEngine_Color_
---@return DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_
function m.DOLocalPath(target, path, duration, pathType, pathMode, resolution, gizmoColor) end

DG.Tweening.DOTweenModulePhysics = m
return m
