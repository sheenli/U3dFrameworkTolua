---@class FairyGUI.GearText : FairyGUI.GearBase
local m = {}

---@virtual
function m:Apply() end

---@virtual
function m:UpdateState() end

FairyGUI.GearText = m
return m
