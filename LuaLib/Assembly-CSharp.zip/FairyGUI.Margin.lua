---@class FairyGUI.Margin : System.ValueType
---@field public left number
---@field public right number
---@field public top number
---@field public bottom number
local m = {}

FairyGUI.Margin = m
return m
