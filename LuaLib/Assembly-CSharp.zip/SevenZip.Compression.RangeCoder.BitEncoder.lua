---@class SevenZip.Compression.RangeCoder.BitEncoder : System.ValueType
---@field public kNumBitModelTotalBits number @static
---@field public kBitModelTotal number @static
---@field public kNumBitPriceShiftBits number @static
local m = {}

function m:Init() end

---@param symbol number
function m:UpdateModel(symbol) end

---@param encoder SevenZip.Compression.RangeCoder.Encoder
---@param symbol number
function m:Encode(encoder, symbol) end

---@param symbol number
---@return number
function m:GetPrice(symbol) end

---@return number
function m:GetPrice0() end

---@return number
function m:GetPrice1() end

SevenZip.Compression.RangeCoder.BitEncoder = m
return m
