---@class FairyGUI.EventDispatcher : System.Object
local m = {}

---@overload fun(strType:string, callback:fun()) @virtual
---@virtual
---@param strType string
---@param callback fun(context:FairyGUI.EventContext)
function m:AddEventListener(strType, callback) end

---@overload fun(strType:string, callback:fun()) @virtual
---@virtual
---@param strType string
---@param callback fun(context:FairyGUI.EventContext)
function m:RemoveEventListener(strType, callback) end

---@overload fun(strType:string)
function m:RemoveEventListeners() end

---@overload fun(strType:string, data:any):
---@overload fun(strType:string, data:any, initiator:any):
---@overload fun(context:FairyGUI.EventContext): @virtual
---@param strType string
---@return boolean
function m:DispatchEvent(strType) end

---@param strType string
---@param data any
---@return boolean
function m:BubbleEvent(strType, data) end

---@param strType string
---@param data any
---@return boolean
function m:BroadcastEvent(strType, data) end

FairyGUI.EventDispatcher = m
return m
