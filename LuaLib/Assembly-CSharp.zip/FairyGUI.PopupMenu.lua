---@class FairyGUI.PopupMenu : System.Object
---@field public itemCount number
---@field public contentPane FairyGUI.GComponent
---@field public list FairyGUI.GList
local m = {}

---@overload fun(caption:string, callback:fun(context:FairyGUI.EventContext)):
---@param caption string
---@param callback fun()
---@return FairyGUI.GButton
function m:AddItem(caption, callback) end

---@overload fun(caption:string, index:number, callback:fun(context:FairyGUI.EventContext)):
---@param caption string
---@param index number
---@param callback fun()
---@return FairyGUI.GButton
function m:AddItemAt(caption, index, callback) end

function m:AddSeperator() end

---@param index number
---@return string
function m:GetItemName(index) end

---@param name string
---@param caption string
function m:SetItemText(name, caption) end

---@param name string
---@param visible boolean
function m:SetItemVisible(name, visible) end

---@param name string
---@param grayed boolean
function m:SetItemGrayed(name, grayed) end

---@param name string
---@param checkable boolean
function m:SetItemCheckable(name, checkable) end

---@param name string
---@param check boolean
function m:SetItemChecked(name, check) end

---@param name string
---@return boolean
function m:isItemChecked(name) end

---@param name string
---@return boolean
function m:RemoveItem(name) end

function m:ClearItems() end

function m:Dispose() end

---@overload fun(target:FairyGUI.GObject, downward:any)
function m:Show() end

FairyGUI.PopupMenu = m
return m
