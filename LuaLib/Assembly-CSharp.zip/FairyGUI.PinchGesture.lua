---@class FairyGUI.PinchGesture : FairyGUI.EventDispatcher
---@field public scale number
---@field public delta number
---@field public host FairyGUI.GObject
---@field public onBegin FairyGUI.EventListener
---@field public onEnd FairyGUI.EventListener
---@field public onAction FairyGUI.EventListener
local m = {}

function m:Dispose() end

---@param value boolean
function m:Enable(value) end

FairyGUI.PinchGesture = m
return m
