---@class FairyGUI.HitTestMode : System.Enum
---@field public Default FairyGUI.HitTestMode @static
---@field public Raycast FairyGUI.HitTestMode @static
---@field public value__ number
local m = {}

FairyGUI.HitTestMode = m
return m
