---@class EventData_1_GameServerMsg_ : EventData
local m = {}

EventData_1_GameServerMsg_ = m
return m
