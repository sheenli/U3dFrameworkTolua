---@class ABMgr : EventDispatcherNode
---@field public Instance ABMgr @static
local m = {}

---@overload fun(ABName:string, callBack:fun(obj:UnityEngine.AssetBundle), keepInMemory:boolean)
---@overload fun(ABName:string, callBack:fun(obj:UnityEngine.AssetBundle))
---@overload fun(ABName:string)
---@param ABName string
---@param callBack fun(obj:UnityEngine.AssetBundle)
---@param keepInMemory boolean
---@param Async boolean
function m:LoadAB(ABName, callBack, keepInMemory, Async) end

---@param ABName string
---@return ABMgr.PackInfo
function m:GetAB(ABName) end

---@virtual
function m:OnUpdate() end

---@virtual
function m:OnDestroy() end

---@overload fun()
---@param forced boolean
function m:UnLoadAll(forced) end

---@overload fun(abName:string)
---@param abName string
---@param immediate boolean
function m:UnLoadAB(abName, immediate) end

---@return System.Collections.IEnumerator
function m:Test() end

ABMgr = m
return m
