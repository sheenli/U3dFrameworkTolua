---@class FairyGUI.TweenValue : System.Object
---@field public x number
---@field public y number
---@field public z number
---@field public w number
---@field public d number
---@field public vec2 UnityEngine.Vector2
---@field public vec3 UnityEngine.Vector3
---@field public vec4 UnityEngine.Vector4
---@field public color UnityEngine.Color
---@field public Item number
local m = {}

function m:SetZero() end

FairyGUI.TweenValue = m
return m
