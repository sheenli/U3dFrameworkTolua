---@class SevenZip.CommandLineParser.CommandForm : System.Object
---@field public IDString string
---@field public PostStringMode boolean
local m = {}

SevenZip.CommandLineParser.CommandForm = m
return m
