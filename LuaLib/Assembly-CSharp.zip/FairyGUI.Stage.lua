---@class FairyGUI.Stage : FairyGUI.Container
---@field public inst FairyGUI.Stage @static
---@field public touchScreen boolean @static
---@field public keyboardInput boolean @static
---@field public isTouchOnUI boolean @static
---@field public stageHeight number
---@field public stageWidth number
---@field public soundVolume number
---@field public onStageResized FairyGUI.EventListener
---@field public touchTarget FairyGUI.DisplayObject
---@field public focus FairyGUI.DisplayObject
---@field public touchPosition UnityEngine.Vector2
---@field public touchCount number
---@field public keyboard FairyGUI.IKeyboard
local m = {}

---@static
function m.Instantiate() end

---@virtual
function m:Dispose() end

---@param touchId number
---@return UnityEngine.Vector2
function m:GetTouchPosition(touchId) end

---@param result number[]
---@return number[]
function m:GetAllTouch(result) end

function m:ResetInputState() end

---@param touchId number
function m:CancelClick(touchId) end

function m:EnableSound() end

function m:DisableSound() end

---@overload fun(clip:UnityEngine.AudioClip)
---@param clip UnityEngine.AudioClip
---@param volumeScale number
function m:PlayOneShotSound(clip, volumeScale) end

---@param text string
---@param autocorrection boolean
---@param multiline boolean
---@param secure boolean
---@param alert boolean
---@param textPlaceholder string
---@param keyboardType number
---@param hideInput boolean
function m:OpenKeyboard(text, autocorrection, multiline, secure, alert, textPlaceholder, keyboardType, hideInput) end

function m:CloseKeyboard() end

---@param value string
function m:InputString(value) end

---@overload fun(screenPos:UnityEngine.Vector2, buttonDown:boolean, buttonUp:boolean)
---@overload fun(hit:UnityEngine.RaycastHit, buttonDown:boolean):
---@overload fun(hit:UnityEngine.RaycastHit, buttonDown:boolean, buttonUp:boolean):
---@param screenPos UnityEngine.Vector2
---@param buttonDown boolean
function m:SetCustomInput(screenPos, buttonDown) end

---@param target FairyGUI.Container
function m:ApplyPanelOrder(target) end

---@param panelSortingOrder number
function m:SortWorldSpacePanelsByZOrder(panelSortingOrder) end

---@param texture FairyGUI.NTexture
function m:MonitorTexture(texture) end

---@param touchId number
---@param target FairyGUI.EventDispatcher
function m:AddTouchMonitor(touchId, target) end

---@param target FairyGUI.EventDispatcher
function m:RemoveTouchMonitor(target) end

FairyGUI.Stage = m
return m
