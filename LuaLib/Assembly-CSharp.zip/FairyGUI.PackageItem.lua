---@class FairyGUI.PackageItem : System.Object
---@field public owner FairyGUI.UIPackage
---@field public type FairyGUI.PackageItemType
---@field public objectType FairyGUI.ObjectType
---@field public id string
---@field public name string
---@field public width number
---@field public height number
---@field public file string
---@field public exported boolean
---@field public texture FairyGUI.NTexture
---@field public rawData FairyGUI.Utils.ByteBuffer
---@field public scale9Grid System.Nullable_1_UnityEngine_Rect_
---@field public scaleByTile boolean
---@field public tileGridIndice number
---@field public pixelHitTestData FairyGUI.PixelHitTestData
---@field public interval number
---@field public repeatDelay number
---@field public swing boolean
---@field public frames FairyGUI.MovieClip.Frame[]
---@field public translated boolean
---@field public extensionCreator fun():
---@field public bitmapFont FairyGUI.BitmapFont
---@field public audioClip FairyGUI.NAudioClip
local m = {}

---@return any
function m:Load() end

FairyGUI.PackageItem = m
return m
