---@class FairyGUI.StencilEraser : System.Object
---@field public gameObject UnityEngine.GameObject
---@field public meshFilter UnityEngine.MeshFilter
---@field public meshRenderer UnityEngine.MeshRenderer
---@field public enabled boolean
local m = {}

FairyGUI.StencilEraser = m
return m
