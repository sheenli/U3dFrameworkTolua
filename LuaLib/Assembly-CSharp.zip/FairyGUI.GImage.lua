---@class FairyGUI.GImage : FairyGUI.GObject
---@field public color UnityEngine.Color
---@field public flip FairyGUI.FlipType
---@field public fillMethod FairyGUI.FillMethod
---@field public fillOrigin number
---@field public fillClockwise boolean
---@field public fillAmount number
---@field public texture FairyGUI.NTexture
---@field public material UnityEngine.Material
---@field public shader string
local m = {}

---@virtual
function m:ConstructFromResource() end

---@virtual
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos number
function m:Setup_BeforeAdd(buffer, beginPos) end

FairyGUI.GImage = m
return m
