---@class FairyGUI.GearLook : FairyGUI.GearBase
local m = {}

---@virtual
function m:Apply() end

---@virtual
---@param tweener FairyGUI.GTweener
function m:OnTweenStart(tweener) end

---@virtual
---@param tweener FairyGUI.GTweener
function m:OnTweenUpdate(tweener) end

---@virtual
---@param tweener FairyGUI.GTweener
function m:OnTweenComplete(tweener) end

---@virtual
function m:UpdateState() end

FairyGUI.GearLook = m
return m
