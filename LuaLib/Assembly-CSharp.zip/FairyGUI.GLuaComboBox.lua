---@class FairyGUI.GLuaComboBox : FairyGUI.GComboBox
local m = {}

---@virtual
---@param xml FairyGUI.Utils.XML
function m:ConstructFromXML(xml) end

---@virtual
function m:Dispose() end

FairyGUI.GLuaComboBox = m
return m
