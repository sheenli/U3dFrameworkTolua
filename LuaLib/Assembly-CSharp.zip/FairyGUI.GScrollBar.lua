---@class FairyGUI.GScrollBar : FairyGUI.GComponent
---@field public displayPerc number
---@field public scrollPerc number
---@field public minSize number
local m = {}

---@param target FairyGUI.ScrollPane
---@param vertical boolean
function m:SetScrollPane(target, vertical) end

FairyGUI.GScrollBar = m
return m
