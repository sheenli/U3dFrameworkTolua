---@class SevenZip.Compression.LZMA.Decoder : System.Object
local m = {}

---@virtual
---@param inStream System.IO.Stream
---@param outStream System.IO.Stream
---@param inSize number
---@param outSize number
---@param progress SevenZip.ICodeProgress
function m:Code(inStream, outStream, inSize, outSize, progress) end

---@virtual
---@param properties string
function m:SetDecoderProperties(properties) end

---@param stream System.IO.Stream
---@return boolean
function m:Train(stream) end

SevenZip.Compression.LZMA.Decoder = m
return m
