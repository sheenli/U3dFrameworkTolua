---@class SevenZip.ISetDecoderProperties : table
local m = {}

---@abstract
---@param properties string
function m:SetDecoderProperties(properties) end

SevenZip.ISetDecoderProperties = m
return m
