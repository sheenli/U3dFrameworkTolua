---@class FairyGUI.RelationType : System.Enum
---@field public Left_Left FairyGUI.RelationType @static
---@field public Left_Center FairyGUI.RelationType @static
---@field public Left_Right FairyGUI.RelationType @static
---@field public Center_Center FairyGUI.RelationType @static
---@field public Right_Left FairyGUI.RelationType @static
---@field public Right_Center FairyGUI.RelationType @static
---@field public Right_Right FairyGUI.RelationType @static
---@field public Top_Top FairyGUI.RelationType @static
---@field public Top_Middle FairyGUI.RelationType @static
---@field public Top_Bottom FairyGUI.RelationType @static
---@field public Middle_Middle FairyGUI.RelationType @static
---@field public Bottom_Top FairyGUI.RelationType @static
---@field public Bottom_Middle FairyGUI.RelationType @static
---@field public Bottom_Bottom FairyGUI.RelationType @static
---@field public Width FairyGUI.RelationType @static
---@field public Height FairyGUI.RelationType @static
---@field public LeftExt_Left FairyGUI.RelationType @static
---@field public LeftExt_Right FairyGUI.RelationType @static
---@field public RightExt_Left FairyGUI.RelationType @static
---@field public RightExt_Right FairyGUI.RelationType @static
---@field public TopExt_Top FairyGUI.RelationType @static
---@field public TopExt_Bottom FairyGUI.RelationType @static
---@field public BottomExt_Top FairyGUI.RelationType @static
---@field public BottomExt_Bottom FairyGUI.RelationType @static
---@field public Size FairyGUI.RelationType @static
---@field public value__ number
local m = {}

FairyGUI.RelationType = m
return m
