---@class FairyGUI.ChildrenRenderOrder : System.Enum
---@field public Ascent FairyGUI.ChildrenRenderOrder @static
---@field public Descent FairyGUI.ChildrenRenderOrder @static
---@field public Arch FairyGUI.ChildrenRenderOrder @static
---@field public value__ number
local m = {}

FairyGUI.ChildrenRenderOrder = m
return m
