---@class SevenZip.Compression.RangeCoder.Decoder : System.Object
---@field public kTopValue number @static
---@field public Range number
---@field public Code number
---@field public Stream System.IO.Stream
local m = {}

---@param stream System.IO.Stream
function m:Init(stream) end

function m:ReleaseStream() end

function m:CloseStream() end

function m:Normalize() end

function m:Normalize2() end

---@param total number
---@return number
function m:GetThreshold(total) end

---@param start number
---@param size number
---@param total number
function m:Decode(start, size, total) end

---@param numTotalBits number
---@return number
function m:DecodeDirectBits(numTotalBits) end

---@param size0 number
---@param numTotalBits number
---@return number
function m:DecodeBit(size0, numTotalBits) end

SevenZip.Compression.RangeCoder.Decoder = m
return m
