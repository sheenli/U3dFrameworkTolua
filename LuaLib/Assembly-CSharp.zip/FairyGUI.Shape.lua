---@class FairyGUI.Shape : FairyGUI.DisplayObject
---@field public empty boolean
---@field public color UnityEngine.Color
local m = {}

---@overload fun(lineSize:number, colors:UnityEngine.Color[])
---@param lineSize number
---@param lineColor UnityEngine.Color
---@param fillColor UnityEngine.Color
function m:DrawRect(lineSize, lineColor, fillColor) end

---@param fillColor UnityEngine.Color
---@param cornerRadius number[]
function m:DrawRoundRect(fillColor, cornerRadius) end

---@overload fun(colors:UnityEngine.Color[])
---@param fillColor UnityEngine.Color
function m:DrawEllipse(fillColor) end

---@overload fun(points:UnityEngine.Vector2[], colors:UnityEngine.Color[])
---@param points UnityEngine.Vector2[]
---@param fillColor UnityEngine.Color
function m:DrawPolygon(points, fillColor) end

function m:Clear() end

---@virtual
---@param context FairyGUI.UpdateContext
function m:Update(context) end

FairyGUI.Shape = m
return m
