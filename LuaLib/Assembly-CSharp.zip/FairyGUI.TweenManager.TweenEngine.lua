---@class FairyGUI.TweenManager.TweenEngine : UnityEngine.MonoBehaviour
local m = {}

FairyGUI.TweenManager.TweenEngine = m
return m
