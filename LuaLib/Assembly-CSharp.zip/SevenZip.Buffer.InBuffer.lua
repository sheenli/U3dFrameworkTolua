---@class SevenZip.Buffer.InBuffer : System.Object
local m = {}

---@param stream System.IO.Stream
function m:Init(stream) end

---@return boolean
function m:ReadBlock() end

function m:ReleaseStream() end

---@overload fun():
---@param b number
---@return boolean
function m:ReadByte(b) end

---@return number
function m:GetProcessedSize() end

SevenZip.Buffer.InBuffer = m
return m
