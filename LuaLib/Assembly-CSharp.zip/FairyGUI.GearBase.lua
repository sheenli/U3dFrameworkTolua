---@class FairyGUI.GearBase : System.Object
---@field public disableAllTweenEffect boolean @static
---@field public controller FairyGUI.Controller
---@field public tweenConfig FairyGUI.GearTweenConfig
local m = {}

---@param buffer FairyGUI.Utils.ByteBuffer
function m:Setup(buffer) end

---@virtual
---@param dx number
---@param dy number
function m:UpdateFromRelations(dx, dy) end

---@abstract
function m:Apply() end

---@abstract
function m:UpdateState() end

FairyGUI.GearBase = m
return m
