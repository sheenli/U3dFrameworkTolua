---@class SimplePoolGameobject : SimplePool_1_UnityEngine_GameObject_
local m = {}

---@virtual
function m:Clear() end

---@virtual
---@return UnityEngine.GameObject
function m:Get() end

---@virtual
---@param obj UnityEngine.GameObject
function m:Pop(obj) end

SimplePoolGameobject = m
return m
