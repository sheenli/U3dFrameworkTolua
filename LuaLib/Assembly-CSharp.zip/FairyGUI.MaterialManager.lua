---@class FairyGUI.MaterialManager : System.Object
local m = {}

---@param grahpics FairyGUI.NGraphics
---@param context FairyGUI.UpdateContext
---@return FairyGUI.NMaterial
function m:GetMaterial(grahpics, context) end

function m:DestroyMaterials() end

function m:RefreshMaterials() end

function m:Release() end

FairyGUI.MaterialManager = m
return m
