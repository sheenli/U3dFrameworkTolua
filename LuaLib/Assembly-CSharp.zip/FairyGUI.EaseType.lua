---@class FairyGUI.EaseType : System.Enum
---@field public Linear FairyGUI.EaseType @static
---@field public SineIn FairyGUI.EaseType @static
---@field public SineOut FairyGUI.EaseType @static
---@field public SineInOut FairyGUI.EaseType @static
---@field public QuadIn FairyGUI.EaseType @static
---@field public QuadOut FairyGUI.EaseType @static
---@field public QuadInOut FairyGUI.EaseType @static
---@field public CubicIn FairyGUI.EaseType @static
---@field public CubicOut FairyGUI.EaseType @static
---@field public CubicInOut FairyGUI.EaseType @static
---@field public QuartIn FairyGUI.EaseType @static
---@field public QuartOut FairyGUI.EaseType @static
---@field public QuartInOut FairyGUI.EaseType @static
---@field public QuintIn FairyGUI.EaseType @static
---@field public QuintOut FairyGUI.EaseType @static
---@field public QuintInOut FairyGUI.EaseType @static
---@field public ExpoIn FairyGUI.EaseType @static
---@field public ExpoOut FairyGUI.EaseType @static
---@field public ExpoInOut FairyGUI.EaseType @static
---@field public CircIn FairyGUI.EaseType @static
---@field public CircOut FairyGUI.EaseType @static
---@field public CircInOut FairyGUI.EaseType @static
---@field public ElasticIn FairyGUI.EaseType @static
---@field public ElasticOut FairyGUI.EaseType @static
---@field public ElasticInOut FairyGUI.EaseType @static
---@field public BackIn FairyGUI.EaseType @static
---@field public BackOut FairyGUI.EaseType @static
---@field public BackInOut FairyGUI.EaseType @static
---@field public BounceIn FairyGUI.EaseType @static
---@field public BounceOut FairyGUI.EaseType @static
---@field public BounceInOut FairyGUI.EaseType @static
---@field public Custom FairyGUI.EaseType @static
---@field public value__ number
local m = {}

FairyGUI.EaseType = m
return m
