---@class FairyGUI.GroupLayoutType : System.Enum
---@field public None FairyGUI.GroupLayoutType @static
---@field public Horizontal FairyGUI.GroupLayoutType @static
---@field public Vertical FairyGUI.GroupLayoutType @static
---@field public value__ number
local m = {}

FairyGUI.GroupLayoutType = m
return m
