---@class FairyGUI.VertAlignType : System.Enum
---@field public Top FairyGUI.VertAlignType @static
---@field public Middle FairyGUI.VertAlignType @static
---@field public Bottom FairyGUI.VertAlignType @static
---@field public value__ number
local m = {}

FairyGUI.VertAlignType = m
return m
