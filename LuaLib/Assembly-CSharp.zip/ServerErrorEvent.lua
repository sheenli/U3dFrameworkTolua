---@class ServerErrorEvent : EventData_1_ErrorData_
local m = {}

ServerErrorEvent = m
return m
