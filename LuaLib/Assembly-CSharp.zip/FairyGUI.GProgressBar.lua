---@class FairyGUI.GProgressBar : FairyGUI.GComponent
---@field public titleType FairyGUI.ProgressTitleType
---@field public max number
---@field public value number
---@field public reverse boolean
local m = {}

---@param value number
---@param duration number
---@return FairyGUI.GTweener
function m:TweenValue(value, duration) end

---@param newValue number
function m:Update(newValue) end

---@virtual
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos number
function m:Setup_AfterAdd(buffer, beginPos) end

---@virtual
function m:Dispose() end

FairyGUI.GProgressBar = m
return m
