---@class FairyGUI.GTweenCallback1 : System.MulticastDelegate
local m = {}

---@virtual
---@param tweener FairyGUI.GTweener
function m:Invoke(tweener) end

---@virtual
---@param tweener FairyGUI.GTweener
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(tweener, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

FairyGUI.GTweenCallback1 = m
return m
