---@class FairyGUI.GearXYValue : System.Object
---@field public x number
---@field public y number
local m = {}

FairyGUI.GearXYValue = m
return m
