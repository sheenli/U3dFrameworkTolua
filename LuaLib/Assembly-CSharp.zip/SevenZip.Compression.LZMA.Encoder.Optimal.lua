---@class SevenZip.Compression.LZMA.Encoder.Optimal : System.Object
---@field public State SevenZip.Compression.LZMA.Base.State
---@field public Prev1IsChar boolean
---@field public Prev2 boolean
---@field public PosPrev2 number
---@field public BackPrev2 number
---@field public Price number
---@field public PosPrev number
---@field public BackPrev number
---@field public Backs0 number
---@field public Backs1 number
---@field public Backs2 number
---@field public Backs3 number
local m = {}

function m:MakeAsChar() end

function m:MakeAsShortRep() end

---@return boolean
function m:IsShortRep() end

SevenZip.Compression.LZMA.Encoder.Optimal = m
return m
