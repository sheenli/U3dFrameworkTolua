---@class SceneMgr : EventDispatcherNode
---@field public ChangeSceneFinished string @static
---@field public Instance SceneMgr @static
---@field public OpenLoadUI fun(obj:TaskBase[])
---@field public CloseLoadUI fun()
---@field public oldScenes System.Collections.Generic.Queue_1_SceneBase_
---@field public currentScene SceneBase
local m = {}

function m:Awake() end

---@overload fun(scneneType:string, t:System.Type, func:fun():)
---@overload fun(scneneType:string, t:System.Type)
---@overload fun(scneneType:string)
---@param scneneType string
---@param t System.Type
---@param func fun():
---@param param any
function m:GotoScene(scneneType, t, func, param) end

---@virtual
function m:OnDestroy() end

---@param sceneName string
---@return SceneBase
function m:GetScnene(sceneName) end

---@param data EventData
function m:OnHanderEvent(data) end

SceneMgr = m
return m
