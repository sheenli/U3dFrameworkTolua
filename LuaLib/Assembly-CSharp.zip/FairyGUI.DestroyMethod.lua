---@class FairyGUI.DestroyMethod : System.Enum
---@field public Destroy FairyGUI.DestroyMethod @static
---@field public Unload FairyGUI.DestroyMethod @static
---@field public None FairyGUI.DestroyMethod @static
---@field public value__ number
local m = {}

FairyGUI.DestroyMethod = m
return m
