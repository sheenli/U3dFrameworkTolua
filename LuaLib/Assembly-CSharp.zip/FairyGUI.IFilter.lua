---@class FairyGUI.IFilter : table
---@field public target FairyGUI.DisplayObject
local m = {}

---@abstract
function m:Update() end

---@abstract
function m:Dispose() end

FairyGUI.IFilter = m
return m
