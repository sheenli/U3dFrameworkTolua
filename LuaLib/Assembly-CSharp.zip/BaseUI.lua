---@class BaseUI : FairyGUI.Window
---@field public eventMgr InterchangeableEventListenerMgr
---@field public isDotDel boolean
---@field public PackName string
---@field public ResName string
local m = {}

---@param paramData any
function m:SetData(paramData) end

---@return any
function m:GetData() end

---@virtual
function m:Dispose() end

function m:Refresh() end

BaseUI = m
return m
