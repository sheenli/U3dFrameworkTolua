---@class FairyGUI.IHitTest : table
local m = {}

---@abstract
---@param value boolean
function m:SetEnabled(value) end

---@abstract
---@param container FairyGUI.Container
---@param localPoint UnityEngine.Vector2
---@return boolean, UnityEngine.Vector2
function m:HitTest(container, localPoint) end

FairyGUI.IHitTest = m
return m
