---@class DG.Tweening.DOTweenAnimationExtensions : System.Object
local m = {}

---@static
---@param t UnityEngine.Component
---@return boolean
function m.IsSameOrSubclassOf(t) end

DG.Tweening.DOTweenAnimationExtensions = m
return m
