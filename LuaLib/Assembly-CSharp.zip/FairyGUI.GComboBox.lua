---@class FairyGUI.GComboBox : FairyGUI.GComponent
---@field public visibleItemCount number
---@field public dropdown FairyGUI.GComponent
---@field public onChanged FairyGUI.EventListener
---@field public icon string
---@field public title string
---@field public text string
---@field public titleColor UnityEngine.Color
---@field public titleFontSize number
---@field public items string[]
---@field public icons string[]
---@field public values string[]
---@field public selectedIndex number
---@field public selectionController FairyGUI.Controller
---@field public value string
---@field public popupDirection FairyGUI.PopupDirection
local m = {}

---@return FairyGUI.GTextField
function m:GetTextField() end

---@virtual
---@param c FairyGUI.Controller
function m:HandleControllerChanged(c) end

---@virtual
function m:Dispose() end

---@virtual
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos number
function m:Setup_AfterAdd(buffer, beginPos) end

function m:UpdateDropdownList() end

FairyGUI.GComboBox = m
return m
