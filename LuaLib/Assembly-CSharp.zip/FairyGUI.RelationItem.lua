---@class FairyGUI.RelationItem : System.Object
---@field public target FairyGUI.GObject
---@field public isEmpty boolean
local m = {}

---@param relationType FairyGUI.RelationType
---@param usePercent boolean
function m:Add(relationType, usePercent) end

---@param relationType FairyGUI.RelationType
---@param usePercent boolean
function m:InternalAdd(relationType, usePercent) end

---@param relationType FairyGUI.RelationType
function m:Remove(relationType) end

---@param source FairyGUI.RelationItem
function m:CopyFrom(source) end

function m:Dispose() end

---@param dWidth number
---@param dHeight number
---@param applyPivot boolean
function m:ApplyOnSelfSizeChanged(dWidth, dHeight, applyPivot) end

FairyGUI.RelationItem = m
return m
