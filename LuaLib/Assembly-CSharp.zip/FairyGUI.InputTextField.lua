---@class FairyGUI.InputTextField : FairyGUI.RichTextField
---@field public onCopy fun(textField:FairyGUI.InputTextField, text:string) @static
---@field public onPaste fun(textField:FairyGUI.InputTextField) @static
---@field public onFocusIn FairyGUI.EventListener
---@field public onFocusOut FairyGUI.EventListener
---@field public onChanged FairyGUI.EventListener
---@field public onSubmit FairyGUI.EventListener
---@field public maxLength number
---@field public keyboardInput boolean
---@field public keyboardType number
---@field public editable boolean
---@field public hideInput boolean
---@field public text string
---@field public textFormat FairyGUI.TextFormat
---@field public restrict string
---@field public caretPosition number
---@field public promptText string
---@field public displayAsPassword boolean
local m = {}

---@param start number
---@param length number
function m:SetSelection(start, length) end

---@param value string
function m:ReplaceSelection(value) end

---@param value string
function m:ReplaceText(value) end

---@virtual
---@param context FairyGUI.UpdateContext
function m:Update(context) end

---@virtual
function m:Dispose() end

FairyGUI.InputTextField = m
return m
