---@class FairyGUI.CharState : System.Enum
---@field public init FairyGUI.CharState @static
---@field public middle FairyGUI.CharState @static
---@field public final FairyGUI.CharState @static
---@field public isolated FairyGUI.CharState @static
---@field public number FairyGUI.CharState @static
---@field public value__ number
local m = {}

FairyGUI.CharState = m
return m
