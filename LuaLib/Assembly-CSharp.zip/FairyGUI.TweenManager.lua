---@class FairyGUI.TweenManager : System.Object
local m = {}

FairyGUI.TweenManager = m
return m
