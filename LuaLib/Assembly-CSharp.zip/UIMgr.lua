---@class UIMgr : EventDispatcherNode
---@field public Instance UIMgr @static
local m = {}

---@param designResolutionX number
---@param designResolutionY number
function m:Init(designResolutionX, designResolutionY) end

---@param uiName string
---@return BaseUI
function m:GetWindow(uiName) end

---@return string[]
function m:GetAllOpenWindows() end

---@overload fun(uiName:string, type:System.Type, _createFun:fun():, param:any, hideWinds:string[], hideDotDel:boolean)
---@overload fun(uiName:string, type:System.Type, _createFun:fun():, param:any, hideWinds:string[])
---@overload fun(uiName:string, type:System.Type, _createFun:fun():, param:any)
---@overload fun(uiName:string, type:System.Type, _createFun:fun():)
---@overload fun(uiName:string, type:System.Type)
---@param uiName string
---@param type System.Type
---@param _createFun fun():
---@param param any
---@param hideWinds string[]
---@param hideDotDel boolean
---@param callback fun(obj:BaseUI)
function m:ShowWindow(uiName, type, _createFun, param, hideWinds, hideDotDel, callback) end

---@param uiName string
function m:CloseWindow(uiName) end

---@param uiName string
function m:DeleteWind(uiName) end

---@param uiName string
---@return boolean
function m:IsOpenWindow(uiName) end

---@overload fun()
---@param isDotDel boolean
function m:DeleteAllWindows(isDotDel) end

---@overload fun()
---@param isDotDel boolean
function m:HideAllWindows(isDotDel) end

---@virtual
function m:OnUpdate() end

UIMgr = m
return m
