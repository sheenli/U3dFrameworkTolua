---@class FairyGUI.ScrollType : System.Enum
---@field public Horizontal FairyGUI.ScrollType @static
---@field public Vertical FairyGUI.ScrollType @static
---@field public Both FairyGUI.ScrollType @static
---@field public value__ number
local m = {}

FairyGUI.ScrollType = m
return m
