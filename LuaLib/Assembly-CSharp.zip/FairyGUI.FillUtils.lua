---@class FairyGUI.FillUtils : System.Object
local m = {}

---@static
---@param origin FairyGUI.OriginHorizontal
---@param amount number
---@param vertRect UnityEngine.Rect
---@param uvRect UnityEngine.Rect
---@param verts UnityEngine.Vector3[]
---@param uv UnityEngine.Vector2[]
function m.FillHorizontal(origin, amount, vertRect, uvRect, verts, uv) end

---@static
---@param origin FairyGUI.OriginVertical
---@param amount number
---@param vertRect UnityEngine.Rect
---@param uvRect UnityEngine.Rect
---@param verts UnityEngine.Vector3[]
---@param uv UnityEngine.Vector2[]
function m.FillVertical(origin, amount, vertRect, uvRect, verts, uv) end

---@static
---@param origin FairyGUI.Origin90
---@param amount number
---@param clockwise boolean
---@param vertRect UnityEngine.Rect
---@param uvRect UnityEngine.Rect
---@param verts UnityEngine.Vector3[]
---@param uv UnityEngine.Vector2[]
function m.FillRadial90(origin, amount, clockwise, vertRect, uvRect, verts, uv) end

---@static
---@param origin FairyGUI.Origin180
---@param amount number
---@param clockwise boolean
---@param vertRect UnityEngine.Rect
---@param uvRect UnityEngine.Rect
---@param verts UnityEngine.Vector3[]
---@param uv UnityEngine.Vector2[]
function m.FillRadial180(origin, amount, clockwise, vertRect, uvRect, verts, uv) end

---@static
---@param origin FairyGUI.Origin360
---@param amount number
---@param clockwise boolean
---@param vertRect UnityEngine.Rect
---@param uvRect UnityEngine.Rect
---@param verts UnityEngine.Vector3[]
---@param uv UnityEngine.Vector2[]
function m.FillRadial360(origin, amount, clockwise, vertRect, uvRect, verts, uv) end

FairyGUI.FillUtils = m
return m
