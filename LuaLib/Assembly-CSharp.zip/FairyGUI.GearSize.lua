---@class FairyGUI.GearSize : FairyGUI.GearBase
local m = {}

---@virtual
function m:Apply() end

---@virtual
---@param tweener FairyGUI.GTweener
function m:OnTweenStart(tweener) end

---@virtual
---@param tweener FairyGUI.GTweener
function m:OnTweenUpdate(tweener) end

---@virtual
---@param tweener FairyGUI.GTweener
function m:OnTweenComplete(tweener) end

---@virtual
function m:UpdateState() end

---@virtual
---@param dx number
---@param dy number
function m:UpdateFromRelations(dx, dy) end

FairyGUI.GearSize = m
return m
