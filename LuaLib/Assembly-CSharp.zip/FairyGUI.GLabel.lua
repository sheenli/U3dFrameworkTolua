---@class FairyGUI.GLabel : FairyGUI.GComponent
---@field public icon string
---@field public title string
---@field public text string
---@field public editable boolean
---@field public titleColor UnityEngine.Color
---@field public titleFontSize number
---@field public color UnityEngine.Color
local m = {}

---@return FairyGUI.GTextField
function m:GetTextField() end

---@virtual
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos number
function m:Setup_AfterAdd(buffer, beginPos) end

FairyGUI.GLabel = m
return m
