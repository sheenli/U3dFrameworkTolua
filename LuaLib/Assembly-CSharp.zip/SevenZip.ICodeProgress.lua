---@class SevenZip.ICodeProgress : table
local m = {}

---@abstract
---@param inSize number
---@param outSize number
function m:SetProgress(inSize, outSize) end

SevenZip.ICodeProgress = m
return m
