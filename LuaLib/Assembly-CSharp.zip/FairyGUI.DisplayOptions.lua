---@class FairyGUI.DisplayOptions : System.Object
---@field public hideFlags UnityEngine.HideFlags @static
local m = {}

---@static
function m.SetEditModeHideFlags() end

FairyGUI.DisplayOptions = m
return m
