---@class FairyGUI.GSlider : FairyGUI.GComponent
---@field public changeOnClick boolean
---@field public canDrag boolean
---@field public onChanged FairyGUI.EventListener
---@field public onGripTouchEnd FairyGUI.EventListener
---@field public titleType FairyGUI.ProgressTitleType
---@field public max number
---@field public value number
local m = {}

---@virtual
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos number
function m:Setup_AfterAdd(buffer, beginPos) end

FairyGUI.GSlider = m
return m
