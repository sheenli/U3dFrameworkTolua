---@class FairyGUI.EaseManager.Bounce : System.Object
local m = {}

---@static
---@param time number
---@param duration number
---@return number
function m.EaseIn(time, duration) end

---@static
---@param time number
---@param duration number
---@return number
function m.EaseOut(time, duration) end

---@static
---@param time number
---@param duration number
---@return number
function m.EaseInOut(time, duration) end

FairyGUI.EaseManager.Bounce = m
return m
