---@class FairyGUI.MovieClip.Frame : System.Object
---@field public rect UnityEngine.Rect
---@field public addDelay number
---@field public uvRect UnityEngine.Rect
---@field public rotated boolean
local m = {}

FairyGUI.MovieClip.Frame = m
return m
