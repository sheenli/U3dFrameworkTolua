---@class SimplePool_1_UnityEngine_Object_ : System.Object
---@field public initCallback fun(obj:UnityEngine.Object)
---@field public returnCallback fun(obj:UnityEngine.Object)
---@field public createCallback fun(type:System.Type):
local m = {}

---@virtual
function m:Clear() end

---@virtual
---@return UnityEngine.Object
function m:Get() end

---@virtual
---@param obj UnityEngine.Object
function m:Pop(obj) end

SimplePool_1_UnityEngine_Object_ = m
return m
