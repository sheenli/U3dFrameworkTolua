---@class GetGPSFinishEvent.GPSLocationInfo : System.ValueType
---@field public longitude number
---@field public latitude number
local m = {}

GetGPSFinishEvent.GPSLocationInfo = m
return m
