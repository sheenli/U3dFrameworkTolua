---@class FairyGUI.TweenPropTypeUtils : System.Object
local m = {}

FairyGUI.TweenPropTypeUtils = m
return m
