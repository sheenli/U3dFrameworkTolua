---@class HotUpdateRessMgr.DecompressionOrDownInfo : System.Object
---@field public comparisonInfo ComparisonInfo
---@field public remoteVer VerInfo
---@field public localVer VerInfo
local m = {}

HotUpdateRessMgr.DecompressionOrDownInfo = m
return m
