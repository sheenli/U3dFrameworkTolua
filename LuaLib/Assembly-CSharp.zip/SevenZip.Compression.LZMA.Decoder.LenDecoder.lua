---@class SevenZip.Compression.LZMA.Decoder.LenDecoder : System.Object
local m = {}

---@param numPosStates number
function m:Create(numPosStates) end

function m:Init() end

---@param rangeDecoder SevenZip.Compression.RangeCoder.Decoder
---@param posState number
---@return number
function m:Decode(rangeDecoder, posState) end

SevenZip.Compression.LZMA.Decoder.LenDecoder = m
return m
