---@class SevenZip.CoderPropID : System.Enum
---@field public DefaultProp SevenZip.CoderPropID @static
---@field public DictionarySize SevenZip.CoderPropID @static
---@field public UsedMemorySize SevenZip.CoderPropID @static
---@field public Order SevenZip.CoderPropID @static
---@field public BlockSize SevenZip.CoderPropID @static
---@field public PosStateBits SevenZip.CoderPropID @static
---@field public LitContextBits SevenZip.CoderPropID @static
---@field public LitPosBits SevenZip.CoderPropID @static
---@field public NumFastBytes SevenZip.CoderPropID @static
---@field public MatchFinder SevenZip.CoderPropID @static
---@field public MatchFinderCycles SevenZip.CoderPropID @static
---@field public NumPasses SevenZip.CoderPropID @static
---@field public Algorithm SevenZip.CoderPropID @static
---@field public NumThreads SevenZip.CoderPropID @static
---@field public EndMarker SevenZip.CoderPropID @static
---@field public value__ number
local m = {}

SevenZip.CoderPropID = m
return m
