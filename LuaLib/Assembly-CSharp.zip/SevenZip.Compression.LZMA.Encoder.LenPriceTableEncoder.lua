---@class SevenZip.Compression.LZMA.Encoder.LenPriceTableEncoder : SevenZip.Compression.LZMA.Encoder.LenEncoder
local m = {}

---@param tableSize number
function m:SetTableSize(tableSize) end

---@param symbol number
---@param posState number
---@return number
function m:GetPrice(symbol, posState) end

---@param numPosStates number
function m:UpdateTables(numPosStates) end

---@param rangeEncoder SevenZip.Compression.RangeCoder.Encoder
---@param symbol number
---@param posState number
function m:Encode(rangeEncoder, symbol, posState) end

SevenZip.Compression.LZMA.Encoder.LenPriceTableEncoder = m
return m
