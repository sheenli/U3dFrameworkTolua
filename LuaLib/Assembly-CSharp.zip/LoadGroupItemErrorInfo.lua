---@class LoadGroupItemErrorInfo : System.ValueType
---@field public groupName string
---@field public itemName string
local m = {}

LoadGroupItemErrorInfo = m
return m
