---@class SceneBase : System.Object
---@field public eventMgr InterchangeableEventListenerMgr
---@field public isLoadingShowWait boolean
---@field public sceneTask AsynTask
---@field public parallelTask AsynTask
---@field public SceneName string
---@field public GroupName string
local m = {}

---@param task ITask
function m:AddTask(task) end

---@param task ITask
function m:AddParallelTask(task) end

---@param gropName string
function m:AddLoadGrop(gropName) end

function m:Loaded() end

---@param param any
function m:Enter(param) end

function m:OnFinished() end

function m:Leave() end

function m:ResStartTask() end

---@virtual
function m:OnDestroy() end

SceneBase = m
return m
