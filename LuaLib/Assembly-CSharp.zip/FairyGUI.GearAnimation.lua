---@class FairyGUI.GearAnimation : FairyGUI.GearBase
local m = {}

---@virtual
function m:Apply() end

---@virtual
function m:UpdateState() end

FairyGUI.GearAnimation = m
return m
