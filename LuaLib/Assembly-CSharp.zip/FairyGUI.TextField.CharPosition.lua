---@class FairyGUI.TextField.CharPosition : System.ValueType
---@field public charIndex number
---@field public lineIndex number
---@field public offsetX number
---@field public vertCount number
local m = {}

FairyGUI.TextField.CharPosition = m
return m
