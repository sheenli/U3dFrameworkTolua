---@class FairyGUI.RTLSupport : System.Object
local m = {}

---@static
---@param ch number
---@return boolean
function m.IsArabicLetter(ch) end

---@static
---@param text string
---@return boolean
function m.ContainsArabicLetters(text) end

---@static
---@param input string
---@return string
function m.Convert(input) end

FairyGUI.RTLSupport = m
return m
