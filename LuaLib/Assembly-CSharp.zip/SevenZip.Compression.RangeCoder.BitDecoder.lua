---@class SevenZip.Compression.RangeCoder.BitDecoder : System.ValueType
---@field public kNumBitModelTotalBits number @static
---@field public kBitModelTotal number @static
local m = {}

---@param numMoveBits number
---@param symbol number
function m:UpdateModel(numMoveBits, symbol) end

function m:Init() end

---@param rangeDecoder SevenZip.Compression.RangeCoder.Decoder
---@return number
function m:Decode(rangeDecoder) end

SevenZip.Compression.RangeCoder.BitDecoder = m
return m
