---@class SevenZip.Compression.LZMA.Base.State : System.ValueType
---@field public Index number
local m = {}

function m:Init() end

function m:UpdateChar() end

function m:UpdateMatch() end

function m:UpdateRep() end

function m:UpdateShortRep() end

---@return boolean
function m:IsCharState() end

SevenZip.Compression.LZMA.Base.State = m
return m
