---@class FairyGUI.GearTweenConfig : System.Object
---@field public tween boolean
---@field public easeType FairyGUI.EaseType
---@field public duration number
---@field public delay number
local m = {}

FairyGUI.GearTweenConfig = m
return m
