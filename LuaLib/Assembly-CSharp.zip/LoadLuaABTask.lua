---@class LoadLuaABTask : System.Object
---@field public ab UnityEngine.AssetBundle
---@field public abName string
local m = {}

LoadLuaABTask = m
return m
