---@class FairyGUI.BlurFilter : System.Object
---@field public blurSize number
---@field public target FairyGUI.DisplayObject
local m = {}

---@virtual
function m:Dispose() end

---@virtual
function m:Update() end

FairyGUI.BlurFilter = m
return m
