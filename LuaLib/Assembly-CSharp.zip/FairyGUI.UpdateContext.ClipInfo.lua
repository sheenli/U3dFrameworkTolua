---@class FairyGUI.UpdateContext.ClipInfo : System.ValueType
---@field public rect UnityEngine.Rect
---@field public clipBox UnityEngine.Vector4
---@field public soft boolean
---@field public softness UnityEngine.Vector4
---@field public clipId number
---@field public stencil boolean
---@field public reversedMask boolean
local m = {}

FairyGUI.UpdateContext.ClipInfo = m
return m
