---@class FairyGUI.ListItemRenderer : System.MulticastDelegate
local m = {}

---@virtual
---@param index number
---@param item FairyGUI.GObject
function m:Invoke(index, item) end

---@virtual
---@param index number
---@param item FairyGUI.GObject
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(index, item, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

FairyGUI.ListItemRenderer = m
return m
