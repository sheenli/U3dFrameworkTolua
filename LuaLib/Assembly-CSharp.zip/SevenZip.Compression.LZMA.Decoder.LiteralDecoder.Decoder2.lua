---@class SevenZip.Compression.LZMA.Decoder.LiteralDecoder.Decoder2 : System.ValueType
local m = {}

function m:Create() end

function m:Init() end

---@param rangeDecoder SevenZip.Compression.RangeCoder.Decoder
---@return number
function m:DecodeNormal(rangeDecoder) end

---@param rangeDecoder SevenZip.Compression.RangeCoder.Decoder
---@param matchByte number
---@return number
function m:DecodeWithMatchByte(rangeDecoder, matchByte) end

SevenZip.Compression.LZMA.Decoder.LiteralDecoder.Decoder2 = m
return m
