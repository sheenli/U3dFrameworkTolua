---@class FairyGUI.IUISource : table
---@field public fileName string
---@field public loaded boolean
local m = {}

---@abstract
---@param callback fun()
function m:Load(callback) end

FairyGUI.IUISource = m
return m
