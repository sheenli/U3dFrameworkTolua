---@class SevenZip.Compression.LZMA.Encoder : System.Object
local m = {}

---@return System.Int64, System.Int64, System.Boolean
function m:CodeOneBlock() end

---@virtual
---@param inStream System.IO.Stream
---@param outStream System.IO.Stream
---@param inSize number
---@param outSize number
---@param progress SevenZip.ICodeProgress
function m:Code(inStream, outStream, inSize, outSize, progress) end

---@virtual
---@param outStream System.IO.Stream
function m:WriteCoderProperties(outStream) end

---@virtual
---@param propIDs SevenZip.CoderPropID[]
---@param properties any[]
function m:SetCoderProperties(propIDs, properties) end

---@param trainSize number
function m:SetTrainSize(trainSize) end

SevenZip.Compression.LZMA.Encoder = m
return m
