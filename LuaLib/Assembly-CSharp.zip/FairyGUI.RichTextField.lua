---@class FairyGUI.RichTextField : FairyGUI.Container
---@field public htmlPageContext FairyGUI.Utils.IHtmlPageContext
---@field public htmlParseOptions FairyGUI.Utils.HtmlParseOptions
---@field public emojies table<number, FairyGUI.Emoji>
---@field public textField FairyGUI.TextField
---@field public text string
---@field public htmlText string
---@field public textFormat FairyGUI.TextFormat
---@field public htmlElementCount number
local m = {}

---@param name string
---@return FairyGUI.Utils.HtmlElement
function m:GetHtmlElement(name) end

---@param index number
---@return FairyGUI.Utils.HtmlElement
function m:GetHtmlElementAt(index) end

---@param index number
---@param show boolean
function m:ShowHtmlObject(index, show) end

---@virtual
function m:EnsureSizeCorrect() end

---@virtual
---@param context FairyGUI.UpdateContext
function m:Update(context) end

---@virtual
function m:Dispose() end

FairyGUI.RichTextField = m
return m
