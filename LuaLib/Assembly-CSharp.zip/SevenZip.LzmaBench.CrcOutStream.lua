---@class SevenZip.LzmaBench.CrcOutStream : System.IO.Stream
---@field public CRC SevenZip.CRC
---@field public CanRead boolean
---@field public CanSeek boolean
---@field public CanWrite boolean
---@field public Length number
---@field public Position number
local m = {}

function m:Init() end

---@return number
function m:GetDigest() end

---@virtual
function m:Flush() end

---@virtual
---@param offset number
---@param origin System.IO.SeekOrigin
---@return number
function m:Seek(offset, origin) end

---@virtual
---@param value number
function m:SetLength(value) end

---@virtual
---@param buffer string
---@param offset number
---@param count number
---@return number
function m:Read(buffer, offset, count) end

---@virtual
---@param b number
function m:WriteByte(b) end

---@virtual
---@param buffer string
---@param offset number
---@param count number
function m:Write(buffer, offset, count) end

SevenZip.LzmaBench.CrcOutStream = m
return m
