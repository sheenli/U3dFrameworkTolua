---@class FairyGUI.IEventDispatcher : table
local m = {}

---@overload fun(strType:string, callback:fun(context:FairyGUI.EventContext)) @abstract
---@abstract
---@param strType string
---@param callback fun()
function m:AddEventListener(strType, callback) end

---@overload fun(strType:string, callback:fun(context:FairyGUI.EventContext)) @abstract
---@abstract
---@param strType string
---@param callback fun()
function m:RemoveEventListener(strType, callback) end

---@abstract
---@param context FairyGUI.EventContext
---@return boolean
function m:DispatchEvent(context) end

FairyGUI.IEventDispatcher = m
return m
