---@class FairyGUI.ButtonMode : System.Enum
---@field public Common FairyGUI.ButtonMode @static
---@field public Check FairyGUI.ButtonMode @static
---@field public Radio FairyGUI.ButtonMode @static
---@field public value__ number
local m = {}

FairyGUI.ButtonMode = m
return m
