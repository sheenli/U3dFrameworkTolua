---@class GameMode : EventDispatcherNode
---@field public Instance GameMode @static
---@field public AuditMode boolean
local m = {}

---@param mode IMode
function m:AddMode(mode) end

function m:InitDtata() end

---@return number
function m:SendLoginMsgs() end

function m:ClearData() end

---@virtual
function m:OnUpdate() end

---@virtual
function m:OnDestroy() end

GameMode = m
return m
