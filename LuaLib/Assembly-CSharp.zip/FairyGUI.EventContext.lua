---@class FairyGUI.EventContext : System.Object
---@field public type string
---@field public data any
---@field public sender FairyGUI.EventDispatcher
---@field public initiator any
---@field public inputEvent FairyGUI.InputEvent
---@field public isDefaultPrevented boolean
local m = {}

function m:StopPropagation() end

function m:PreventDefault() end

function m:CaptureTouch() end

FairyGUI.EventContext = m
return m
