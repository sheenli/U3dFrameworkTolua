---@class DG.Tweening.DOTweenModuleUI.Utils : System.Object
local m = {}

---@static
---@param from UnityEngine.RectTransform
---@param to UnityEngine.RectTransform
---@return UnityEngine.Vector2
function m.SwitchToRectTransform(from, to) end

DG.Tweening.DOTweenModuleUI.Utils = m
return m
