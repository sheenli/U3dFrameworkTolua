---@class SevenZip.Compression.RangeCoder.Encoder : System.Object
---@field public kTopValue number @static
---@field public Low number
---@field public Range number
local m = {}

---@param stream System.IO.Stream
function m:SetStream(stream) end

function m:ReleaseStream() end

function m:Init() end

function m:FlushData() end

function m:FlushStream() end

function m:CloseStream() end

---@param start number
---@param size number
---@param total number
function m:Encode(start, size, total) end

function m:ShiftLow() end

---@param v number
---@param numTotalBits number
function m:EncodeDirectBits(v, numTotalBits) end

---@param size0 number
---@param numTotalBits number
---@param symbol number
function m:EncodeBit(size0, numTotalBits, symbol) end

---@return number
function m:GetProcessedSizeAdd() end

SevenZip.Compression.RangeCoder.Encoder = m
return m
