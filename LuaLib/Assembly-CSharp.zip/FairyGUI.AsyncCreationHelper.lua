---@class FairyGUI.AsyncCreationHelper : System.Object
local m = {}

---@static
---@param item FairyGUI.PackageItem
---@param callback fun(result:FairyGUI.GObject)
function m.CreateObject(item, callback) end

FairyGUI.AsyncCreationHelper = m
return m
