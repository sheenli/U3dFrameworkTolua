---@class FairyGUI.GearAnimationValue : System.Object
---@field public playing boolean
---@field public frame number
local m = {}

FairyGUI.GearAnimationValue = m
return m
