---@class FairyGUI.Origin360 : System.Enum
---@field public Top FairyGUI.Origin360 @static
---@field public Bottom FairyGUI.Origin360 @static
---@field public Left FairyGUI.Origin360 @static
---@field public Right FairyGUI.Origin360 @static
---@field public value__ number
local m = {}

FairyGUI.Origin360 = m
return m
