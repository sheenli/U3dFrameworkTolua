---@class FairyGUI.ControllerAction.ActionType : System.Enum
---@field public PlayTransition FairyGUI.ControllerAction.ActionType @static
---@field public ChangePage FairyGUI.ControllerAction.ActionType @static
---@field public value__ number
local m = {}

FairyGUI.ControllerAction.ActionType = m
return m
