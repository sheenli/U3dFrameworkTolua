---@class FairyGUI.NAudioClip : System.Object
---@field public destroyMethod FairyGUI.DestroyMethod
---@field public nativeClip UnityEngine.AudioClip
local m = {}

function m:Unload() end

---@param audioClip UnityEngine.AudioClip
function m:Reload(audioClip) end

FairyGUI.NAudioClip = m
return m
