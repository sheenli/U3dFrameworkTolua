---@class FairyGUI.ControllerAction : System.Object
---@field public fromPage string[]
---@field public toPage string[]
local m = {}

---@static
---@param type FairyGUI.ControllerAction.ActionType
---@return FairyGUI.ControllerAction
function m.CreateAction(type) end

---@param controller FairyGUI.Controller
---@param prevPage string
---@param curPage string
function m:Run(controller, prevPage, curPage) end

---@virtual
---@param buffer FairyGUI.Utils.ByteBuffer
function m:Setup(buffer) end

FairyGUI.ControllerAction = m
return m
