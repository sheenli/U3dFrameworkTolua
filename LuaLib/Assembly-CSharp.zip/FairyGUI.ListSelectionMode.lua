---@class FairyGUI.ListSelectionMode : System.Enum
---@field public Single FairyGUI.ListSelectionMode @static
---@field public Multiple FairyGUI.ListSelectionMode @static
---@field public Multiple_SingleClick FairyGUI.ListSelectionMode @static
---@field public None FairyGUI.ListSelectionMode @static
---@field public value__ number
local m = {}

FairyGUI.ListSelectionMode = m
return m
