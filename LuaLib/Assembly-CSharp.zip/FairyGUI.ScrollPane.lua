---@class FairyGUI.ScrollPane : FairyGUI.EventDispatcher
---@field public draggingPane FairyGUI.ScrollPane @static
---@field public onScroll FairyGUI.EventListener
---@field public onScrollEnd FairyGUI.EventListener
---@field public onPullDownRelease FairyGUI.EventListener
---@field public onPullUpRelease FairyGUI.EventListener
---@field public owner FairyGUI.GComponent
---@field public hzScrollBar FairyGUI.GScrollBar
---@field public vtScrollBar FairyGUI.GScrollBar
---@field public header FairyGUI.GComponent
---@field public footer FairyGUI.GComponent
---@field public bouncebackEffect boolean
---@field public touchEffect boolean
---@field public inertiaDisabled boolean
---@field public softnessOnTopOrLeftSide boolean
---@field public scrollStep number
---@field public snapToItem boolean
---@field public pageMode boolean
---@field public pageController FairyGUI.Controller
---@field public mouseWheelEnabled boolean
---@field public decelerationRate number
---@field public percX number
---@field public percY number
---@field public posX number
---@field public posY number
---@field public isBottomMost boolean
---@field public isRightMost boolean
---@field public currentPageX number
---@field public currentPageY number
---@field public scrollingPosX number
---@field public scrollingPosY number
---@field public contentWidth number
---@field public contentHeight number
---@field public viewWidth number
---@field public viewHeight number
local m = {}

---@param buffer FairyGUI.Utils.ByteBuffer
function m:Setup(buffer) end

function m:Dispose() end

---@param value number
---@param ani boolean
function m:SetPercX(value, ani) end

---@param value number
---@param ani boolean
function m:SetPercY(value, ani) end

---@param value number
---@param ani boolean
function m:SetPosX(value, ani) end

---@param value number
---@param ani boolean
function m:SetPosY(value, ani) end

---@param value number
---@param ani boolean
function m:SetCurrentPageX(value, ani) end

---@param value number
---@param ani boolean
function m:SetCurrentPageY(value, ani) end

---@overload fun(ani:boolean)
function m:ScrollTop() end

---@overload fun(ani:boolean)
function m:ScrollBottom() end

---@overload fun(ratio:number, ani:boolean)
function m:ScrollUp() end

---@overload fun(ratio:number, ani:boolean)
function m:ScrollDown() end

---@overload fun(ratio:number, ani:boolean)
function m:ScrollLeft() end

---@overload fun(ratio:number, ani:boolean)
function m:ScrollRight() end

---@overload fun(obj:FairyGUI.GObject, ani:boolean)
---@overload fun(obj:FairyGUI.GObject, ani:boolean, setFirst:boolean)
---@overload fun(rect:UnityEngine.Rect, ani:boolean, setFirst:boolean)
---@param obj FairyGUI.GObject
function m:ScrollToView(obj) end

---@param obj FairyGUI.GObject
---@return boolean
function m:IsChildInView(obj) end

function m:CancelDragging() end

---@param size number
function m:LockHeader(size) end

---@param size number
function m:LockFooter(size) end

FairyGUI.ScrollPane = m
return m
