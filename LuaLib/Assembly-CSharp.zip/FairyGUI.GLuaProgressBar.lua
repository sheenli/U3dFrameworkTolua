---@class FairyGUI.GLuaProgressBar : FairyGUI.GProgressBar
local m = {}

---@virtual
---@param xml FairyGUI.Utils.XML
function m:ConstructFromXML(xml) end

---@virtual
function m:Dispose() end

FairyGUI.GLuaProgressBar = m
return m
