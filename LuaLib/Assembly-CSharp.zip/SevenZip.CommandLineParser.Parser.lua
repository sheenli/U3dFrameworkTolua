---@class SevenZip.CommandLineParser.Parser : System.Object
---@field public NonSwitchStrings System.Collections.ArrayList
---@field public Item SevenZip.CommandLineParser.SwitchResult
local m = {}

---@param switchForms SevenZip.CommandLineParser.SwitchForm[]
---@param commandStrings string[]
function m:ParseStrings(switchForms, commandStrings) end

---@static
---@param commandForms SevenZip.CommandLineParser.CommandForm[]
---@param commandString string
---@return number, System.String
function m.ParseCommand(commandForms, commandString) end

SevenZip.CommandLineParser.Parser = m
return m
