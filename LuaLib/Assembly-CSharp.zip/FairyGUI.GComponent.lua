---@class FairyGUI.GComponent : FairyGUI.GObject
---@field public rootContainer FairyGUI.Container
---@field public container FairyGUI.Container
---@field public scrollPane FairyGUI.ScrollPane
---@field public onDrop FairyGUI.EventListener
---@field public fairyBatching boolean
---@field public opaque boolean
---@field public margin FairyGUI.Margin
---@field public childrenRenderOrder FairyGUI.ChildrenRenderOrder
---@field public apexIndex number
---@field public numChildren number
---@field public Controllers FairyGUI.Controller[]
---@field public clipSoftness UnityEngine.Vector2
---@field public mask FairyGUI.DisplayObject
---@field public reversedMask boolean
---@field public baseUserData string
---@field public viewWidth number
---@field public viewHeight number
local m = {}

---@virtual
function m:Dispose() end

---@param childChanged boolean
function m:InvalidateBatchingState(childChanged) end

---@param child FairyGUI.GObject
---@return FairyGUI.GObject
function m:AddChild(child) end

---@virtual
---@param child FairyGUI.GObject
---@param index number
---@return FairyGUI.GObject
function m:AddChildAt(child, index) end

---@overload fun(child:FairyGUI.GObject, dispose:boolean):
---@param child FairyGUI.GObject
---@return FairyGUI.GObject
function m:RemoveChild(child) end

---@overload fun(index:number, dispose:boolean): @virtual
---@param index number
---@return FairyGUI.GObject
function m:RemoveChildAt(index) end

---@overload fun(beginIndex:number, endIndex:number, dispose:boolean)
function m:RemoveChildren() end

---@param index number
---@return FairyGUI.GObject
function m:GetChildAt(index) end

---@param name string
---@return FairyGUI.GObject
function m:GetChild(name) end

---@param name string
---@return FairyGUI.GObject
function m:GetVisibleChild(name) end

---@param group FairyGUI.GGroup
---@param name string
---@return FairyGUI.GObject
function m:GetChildInGroup(group, name) end

---@return FairyGUI.GObject[]
function m:GetChildren() end

---@param child FairyGUI.GObject
---@return number
function m:GetChildIndex(child) end

---@param child FairyGUI.GObject
---@param index number
function m:SetChildIndex(child, index) end

---@param child FairyGUI.GObject
---@param index number
---@return number
function m:SetChildIndexBefore(child, index) end

---@param child1 FairyGUI.GObject
---@param child2 FairyGUI.GObject
function m:SwapChildren(child1, child2) end

---@param index1 number
---@param index2 number
function m:SwapChildrenAt(index1, index2) end

---@param obj FairyGUI.GObject
---@return boolean
function m:IsAncestorOf(obj) end

---@param controller FairyGUI.Controller
function m:AddController(controller) end

---@param index number
---@return FairyGUI.Controller
function m:GetControllerAt(index) end

---@param name string
---@return FairyGUI.Controller
function m:GetController(name) end

---@param c FairyGUI.Controller
function m:RemoveController(c) end

---@param index number
---@return FairyGUI.Transition
function m:GetTransitionAt(index) end

---@param name string
---@return FairyGUI.Transition
function m:GetTransition(name) end

---@param child FairyGUI.GObject
---@return boolean
function m:IsChildInView(child) end

---@virtual
---@return number
function m:GetFirstChildInView() end

---@virtual
---@param c FairyGUI.Controller
function m:HandleControllerChanged(c) end

function m:SetBoundsChangedFlag() end

function m:EnsureBoundsCorrect() end

---@virtual
function m:ConstructFromResource() end

---@virtual
---@param xml FairyGUI.Utils.XML
function m:ConstructFromXML(xml) end

---@virtual
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos number
function m:Setup_AfterAdd(buffer, beginPos) end

FairyGUI.GComponent = m
return m
