---@class FairyGUI.EMRenderTarget : table
---@field public EM_sortingOrder number
local m = {}

---@abstract
function m:EM_BeforeUpdate() end

---@abstract
---@param context FairyGUI.UpdateContext
function m:EM_Update(context) end

---@abstract
function m:EM_Reload() end

FairyGUI.EMRenderTarget = m
return m
