---@class FairyGUI.GTextField : FairyGUI.GObject
---@field public text string
---@field public templateVars System.Collections.Generic.Dictionary_2_System_String_System_String_
---@field public textFormat FairyGUI.TextFormat
---@field public color UnityEngine.Color
---@field public align FairyGUI.AlignType
---@field public verticalAlign FairyGUI.VertAlignType
---@field public singleLine boolean
---@field public stroke number
---@field public strokeColor UnityEngine.Color
---@field public shadowOffset UnityEngine.Vector2
---@field public UBBEnabled boolean
---@field public autoSize FairyGUI.AutoSizeType
---@field public textWidth number
---@field public textHeight number
local m = {}

---@param name string
---@param value string
---@return FairyGUI.GTextField
function m:SetVar(name, value) end

function m:FlushVars() end

---@virtual
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos number
function m:Setup_BeforeAdd(buffer, beginPos) end

---@virtual
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos number
function m:Setup_AfterAdd(buffer, beginPos) end

FairyGUI.GTextField = m
return m
