---@class DG.Tweening.DOTweenCYInstruction.WaitForCompletion : UnityEngine.CustomYieldInstruction
---@field public keepWaiting boolean
local m = {}

DG.Tweening.DOTweenCYInstruction.WaitForCompletion = m
return m
