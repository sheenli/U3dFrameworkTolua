---@class IMode : table
---@field public IsLoginDataOk boolean
local m = {}

---@abstract
function m:OnInitData() end

---@abstract
function m:OnLogin() end

---@abstract
function m:OnClear() end

---@abstract
function m:OnDestroy() end

IMode = m
return m
