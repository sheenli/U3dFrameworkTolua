---@class LuaInterface.nil : System.ValueType
local m = {}

LuaInterface.nil = m
return m
