---@class FairyGUI.EaseManager : System.Object
local m = {}

FairyGUI.EaseManager = m
return m
