---@class EventDispatcherNode.EventInfo : System.Object
---@field public eventType string
---@field public priority number
---@field public listener fun(data:EventData)
---@field public dispatchOnce boolean
local m = {}

EventDispatcherNode.EventInfo = m
return m
