---@class FairyGUI.GLoader : FairyGUI.GObject
---@field public showErrorSign boolean
---@field public url string
---@field public icon string
---@field public align FairyGUI.AlignType
---@field public verticalAlign FairyGUI.VertAlignType
---@field public fill FairyGUI.FillType
---@field public shrinkOnly boolean
---@field public autoSize boolean
---@field public playing boolean
---@field public frame number
---@field public timeScale number
---@field public ignoreEngineTimeScale boolean
---@field public material UnityEngine.Material
---@field public shader string
---@field public color UnityEngine.Color
---@field public fillMethod FairyGUI.FillMethod
---@field public fillOrigin number
---@field public fillClockwise boolean
---@field public fillAmount number
---@field public image FairyGUI.Image
---@field public movieClip FairyGUI.MovieClip
---@field public component FairyGUI.GComponent
---@field public texture FairyGUI.NTexture
---@field public filter FairyGUI.IFilter
---@field public blendMode FairyGUI.BlendMode
local m = {}

---@virtual
function m:Dispose() end

---@virtual
---@param time number
function m:Advance(time) end

---@virtual
---@param buffer FairyGUI.Utils.ByteBuffer
---@param beginPos number
function m:Setup_BeforeAdd(buffer, beginPos) end

FairyGUI.GLoader = m
return m
