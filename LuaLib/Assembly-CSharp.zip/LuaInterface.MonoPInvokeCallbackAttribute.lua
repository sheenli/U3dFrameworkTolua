---@class LuaInterface.MonoPInvokeCallbackAttribute : System.Attribute
local m = {}

LuaInterface.MonoPInvokeCallbackAttribute = m
return m
