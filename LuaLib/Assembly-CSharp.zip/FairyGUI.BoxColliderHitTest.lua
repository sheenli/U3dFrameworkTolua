---@class FairyGUI.BoxColliderHitTest : FairyGUI.ColliderHitTest
local m = {}

---@virtual
---@param x number
---@param y number
---@param width number
---@param height number
function m:SetArea(x, y, width, height) end

FairyGUI.BoxColliderHitTest = m
return m
