---@class SevenZip.Compression.LZMA.Base : System.Object
---@field public kNumRepDistances number @static
---@field public kNumStates number @static
---@field public kNumPosSlotBits number @static
---@field public kDicLogSizeMin number @static
---@field public kNumLenToPosStatesBits number @static
---@field public kNumLenToPosStates number @static
---@field public kMatchMinLen number @static
---@field public kNumAlignBits number @static
---@field public kAlignTableSize number @static
---@field public kAlignMask number @static
---@field public kStartPosModelIndex number @static
---@field public kEndPosModelIndex number @static
---@field public kNumPosModels number @static
---@field public kNumFullDistances number @static
---@field public kNumLitPosStatesBitsEncodingMax number @static
---@field public kNumLitContextBitsMax number @static
---@field public kNumPosStatesBitsMax number @static
---@field public kNumPosStatesMax number @static
---@field public kNumPosStatesBitsEncodingMax number @static
---@field public kNumPosStatesEncodingMax number @static
---@field public kNumLowLenBits number @static
---@field public kNumMidLenBits number @static
---@field public kNumHighLenBits number @static
---@field public kNumLowLenSymbols number @static
---@field public kNumMidLenSymbols number @static
---@field public kNumLenSymbols number @static
---@field public kMatchMaxLen number @static
local m = {}

---@static
---@param len number
---@return number
function m.GetLenToPosState(len) end

SevenZip.Compression.LZMA.Base = m
return m
