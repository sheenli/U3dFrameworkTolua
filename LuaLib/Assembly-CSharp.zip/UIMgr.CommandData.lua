---@class UIMgr.CommandData : System.Object
---@field public cmdType UIMgr.CommandType
---@field public uiName string
---@field public param any
---@field public createFun fun():
---@field public uinames string[]
---@field public callback fun(obj:BaseUI)
---@field public isCallBack boolean
local m = {}

---@static
---@param _uiName string
---@param _createFun fun():
---@param _param any
---@param callback fun(obj:BaseUI)
---@return UIMgr.CommandData
function m.CreateShow(_uiName, _createFun, _param, callback) end

---@static
---@param _uiName string
---@return UIMgr.CommandData
function m.CreateHide(_uiName) end

---@static
---@param _uiName string
---@return UIMgr.CommandData
function m.CreateDelete(_uiName) end

---@static
---@param _uiName string
---@param _createFun fun():
---@param _param any
---@param callback fun(obj:BaseUI)
---@return UIMgr.CommandData
function m.CreateCreate(_uiName, _createFun, _param, callback) end

---@static
---@param _list string[]
---@return UIMgr.CommandData
function m.CreateHideList(_list) end

UIMgr.CommandData = m
return m
