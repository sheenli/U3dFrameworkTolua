---@class FairyGUI.AutoSizeType : System.Enum
---@field public None FairyGUI.AutoSizeType @static
---@field public Both FairyGUI.AutoSizeType @static
---@field public Height FairyGUI.AutoSizeType @static
---@field public Shrink FairyGUI.AutoSizeType @static
---@field public value__ number
local m = {}

FairyGUI.AutoSizeType = m
return m
