---@class FairyGUI.BitmapFont.BMGlyph : System.Object
---@field public offsetX number
---@field public offsetY number
---@field public width number
---@field public height number
---@field public advance number
---@field public lineHeight number
---@field public uv UnityEngine.Vector2[]
---@field public channel number
local m = {}

FairyGUI.BitmapFont.BMGlyph = m
return m
