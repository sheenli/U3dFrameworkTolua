---@class SevenZip.CommandLineParser.SwitchType : System.Enum
---@field public Simple SevenZip.CommandLineParser.SwitchType @static
---@field public PostMinus SevenZip.CommandLineParser.SwitchType @static
---@field public LimitedPostString SevenZip.CommandLineParser.SwitchType @static
---@field public UnLimitedPostString SevenZip.CommandLineParser.SwitchType @static
---@field public PostChar SevenZip.CommandLineParser.SwitchType @static
---@field public value__ number
local m = {}

SevenZip.CommandLineParser.SwitchType = m
return m
