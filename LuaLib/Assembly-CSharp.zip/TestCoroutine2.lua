---@class TestCoroutine2 : LuaClient
local m = {}

TestCoroutine2 = m
return m
