---@class FairyGUI.NTexture : System.Object
---@field public Empty FairyGUI.NTexture @static
---@field public uvRect UnityEngine.Rect
---@field public rotated boolean
---@field public refCount number
---@field public lastActive number
---@field public destroyMethod FairyGUI.DestroyMethod
---@field public width number
---@field public height number
---@field public root FairyGUI.NTexture
---@field public disposed boolean
---@field public nativeTexture UnityEngine.Texture
---@field public alphaTexture UnityEngine.Texture
local m = {}

---@static
function m.DisposeEmpty() end

---@param shaderName string
---@param keywords string[]
---@return FairyGUI.MaterialManager
function m:GetMaterialManager(shaderName, keywords) end

---@param manager FairyGUI.MaterialManager
function m:DestroyMaterialManager(manager) end

---@overload fun(destroyMaterials:boolean)
function m:Unload() end

---@param nativeTexture UnityEngine.Texture
---@param alphaTexture UnityEngine.Texture
function m:Reload(nativeTexture, alphaTexture) end

function m:Dispose() end

FairyGUI.NTexture = m
return m
