---@class FairyGUI.InputTextField.PasteHandler : System.MulticastDelegate
local m = {}

---@virtual
---@param textField FairyGUI.InputTextField
function m:Invoke(textField) end

---@virtual
---@param textField FairyGUI.InputTextField
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(textField, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

FairyGUI.InputTextField.PasteHandler = m
return m
