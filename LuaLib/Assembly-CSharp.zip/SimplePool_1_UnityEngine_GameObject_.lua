---@class SimplePool_1_UnityEngine_GameObject_ : System.Object
---@field public initCallback fun(obj:UnityEngine.GameObject)
---@field public returnCallback fun(obj:UnityEngine.GameObject)
---@field public createCallback fun(type:System.Type):
local m = {}

---@virtual
function m:Clear() end

---@virtual
---@return UnityEngine.GameObject
function m:Get() end

---@virtual
---@param obj UnityEngine.GameObject
function m:Pop(obj) end

SimplePool_1_UnityEngine_GameObject_ = m
return m
