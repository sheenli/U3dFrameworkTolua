---@class FairyGUI.PixelHitTestData : System.Object
---@field public pixelWidth number
---@field public scale number
---@field public pixels string
---@field public pixelsLength number
---@field public pixelsOffset number
local m = {}

---@param ba FairyGUI.Utils.ByteBuffer
function m:Load(ba) end

FairyGUI.PixelHitTestData = m
return m
