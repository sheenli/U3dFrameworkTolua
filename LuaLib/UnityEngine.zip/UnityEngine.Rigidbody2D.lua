---@class UnityEngine.Rigidbody2D : UnityEngine.Component
---@field public position UnityEngine.Vector2
---@field public rotation number
---@field public velocity UnityEngine.Vector2
---@field public angularVelocity number
---@field public useAutoMass boolean
---@field public mass number
---@field public sharedMaterial UnityEngine.PhysicsMaterial2D
---@field public centerOfMass UnityEngine.Vector2
---@field public worldCenterOfMass UnityEngine.Vector2
---@field public inertia number
---@field public drag number
---@field public angularDrag number
---@field public gravityScale number
---@field public bodyType UnityEngine.RigidbodyType2D
---@field public useFullKinematicContacts boolean
---@field public isKinematic boolean
---@field public fixedAngle boolean
---@field public freezeRotation boolean
---@field public constraints UnityEngine.RigidbodyConstraints2D
---@field public simulated boolean
---@field public interpolation UnityEngine.RigidbodyInterpolation2D
---@field public sleepMode UnityEngine.RigidbodySleepMode2D
---@field public collisionDetectionMode UnityEngine.CollisionDetectionMode2D
---@field public attachedColliderCount number
local m = {}

---@param position UnityEngine.Vector2
function m:MovePosition(position) end

---@param angle number
function m:MoveRotation(angle) end

---@return boolean
function m:IsSleeping() end

---@return boolean
function m:IsAwake() end

function m:Sleep() end

function m:WakeUp() end

---@param results UnityEngine.Collider2D[]
---@return number
function m:GetAttachedColliders(results) end

---@overload fun(collider:UnityEngine.Collider2D, contactFilter:UnityEngine.ContactFilter2D):
---@overload fun(contactFilter:UnityEngine.ContactFilter2D):
---@param collider UnityEngine.Collider2D
---@return boolean
function m:IsTouching(collider) end

---@overload fun():
---@param layerMask number
---@return boolean
function m:IsTouchingLayers(layerMask) end

---@param point UnityEngine.Vector2
---@return boolean
function m:OverlapPoint(point) end

---@param contactFilter UnityEngine.ContactFilter2D
---@param results UnityEngine.Collider2D[]
---@return number
function m:OverlapCollider(contactFilter, results) end

---@overload fun(direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[]):
---@overload fun(direction:UnityEngine.Vector2, contactFilter:UnityEngine.ContactFilter2D, results:UnityEngine.RaycastHit2D[]):
---@overload fun(direction:UnityEngine.Vector2, contactFilter:UnityEngine.ContactFilter2D, results:UnityEngine.RaycastHit2D[], distance:number):
---@param direction UnityEngine.Vector2
---@param results UnityEngine.RaycastHit2D[]
---@param distance number
---@return number
function m:Cast(direction, results, distance) end

---@param collider UnityEngine.Collider2D
---@return UnityEngine.ColliderDistance2D
function m:Distance(collider) end

---@overload fun(force:UnityEngine.Vector2)
---@param force UnityEngine.Vector2
---@param mode UnityEngine.ForceMode2D
function m:AddForce(force, mode) end

---@overload fun(relativeForce:UnityEngine.Vector2)
---@param relativeForce UnityEngine.Vector2
---@param mode UnityEngine.ForceMode2D
function m:AddRelativeForce(relativeForce, mode) end

---@overload fun(force:UnityEngine.Vector2, position:UnityEngine.Vector2)
---@param force UnityEngine.Vector2
---@param position UnityEngine.Vector2
---@param mode UnityEngine.ForceMode2D
function m:AddForceAtPosition(force, position, mode) end

---@overload fun(torque:number)
---@param torque number
---@param mode UnityEngine.ForceMode2D
function m:AddTorque(torque, mode) end

---@param point UnityEngine.Vector2
---@return UnityEngine.Vector2
function m:GetPoint(point) end

---@param relativePoint UnityEngine.Vector2
---@return UnityEngine.Vector2
function m:GetRelativePoint(relativePoint) end

---@param vector UnityEngine.Vector2
---@return UnityEngine.Vector2
function m:GetVector(vector) end

---@param relativeVector UnityEngine.Vector2
---@return UnityEngine.Vector2
function m:GetRelativeVector(relativeVector) end

---@param point UnityEngine.Vector2
---@return UnityEngine.Vector2
function m:GetPointVelocity(point) end

---@param relativePoint UnityEngine.Vector2
---@return UnityEngine.Vector2
function m:GetRelativePointVelocity(relativePoint) end

---@overload fun(contactFilter:UnityEngine.ContactFilter2D, contacts:UnityEngine.ContactPoint2D[]):
---@overload fun(colliders:UnityEngine.Collider2D[]):
---@overload fun(contactFilter:UnityEngine.ContactFilter2D, colliders:UnityEngine.Collider2D[]):
---@param contacts UnityEngine.ContactPoint2D[]
---@return number
function m:GetContacts(contacts) end

---@overload fun(endValue:UnityEngine.Vector2, duration:number): @extension
---@extension
---@param endValue UnityEngine.Vector2
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOMove(endValue, duration, snapping) end

---@overload fun(endValue:number, duration:number): @extension
---@extension
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOMoveX(endValue, duration, snapping) end

---@overload fun(endValue:number, duration:number): @extension
---@extension
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOMoveY(endValue, duration, snapping) end

---@extension
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DORotate(endValue, duration) end

---@overload fun(endValue:UnityEngine.Vector2, jumpPower:number, numJumps:number, duration:number): @extension
---@extension
---@param endValue UnityEngine.Vector2
---@param jumpPower number
---@param numJumps number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Sequence
function m.DOJump(endValue, jumpPower, numJumps, duration, snapping) end

UnityEngine.Rigidbody2D = m
return m
