---@class UnityEngine.RPC : System.Attribute
local m = {}

UnityEngine.RPC = m
return m
