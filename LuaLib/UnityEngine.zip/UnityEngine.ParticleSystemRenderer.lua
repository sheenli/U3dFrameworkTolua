---@class UnityEngine.ParticleSystemRenderer : UnityEngine.Renderer
---@field public renderMode UnityEngine.ParticleSystemRenderMode
---@field public lengthScale number
---@field public velocityScale number
---@field public cameraVelocityScale number
---@field public normalDirection number
---@field public alignment UnityEngine.ParticleSystemRenderSpace
---@field public pivot UnityEngine.Vector3
---@field public sortMode UnityEngine.ParticleSystemSortMode
---@field public sortingFudge number
---@field public minParticleSize number
---@field public maxParticleSize number
---@field public mesh UnityEngine.Mesh
---@field public meshCount number
---@field public trailMaterial UnityEngine.Material
---@field public activeVertexStreamsCount number
local m = {}

---@param meshes UnityEngine.Mesh[]
---@return number
function m:GetMeshes(meshes) end

---@overload fun(meshes:UnityEngine.Mesh[], size:number)
---@param meshes UnityEngine.Mesh[]
function m:SetMeshes(meshes) end

---@param streams UnityEngine.ParticleSystemVertexStream[]
function m:SetActiveVertexStreams(streams) end

---@param streams UnityEngine.ParticleSystemVertexStream[]
function m:GetActiveVertexStreams(streams) end

---@param streams UnityEngine.ParticleSystemVertexStreams
function m:EnableVertexStreams(streams) end

---@param streams UnityEngine.ParticleSystemVertexStreams
function m:DisableVertexStreams(streams) end

---@param streams UnityEngine.ParticleSystemVertexStreams
---@return boolean
function m:AreVertexStreamsEnabled(streams) end

---@param streams UnityEngine.ParticleSystemVertexStreams
---@return UnityEngine.ParticleSystemVertexStreams
function m:GetEnabledVertexStreams(streams) end

UnityEngine.ParticleSystemRenderer = m
return m
