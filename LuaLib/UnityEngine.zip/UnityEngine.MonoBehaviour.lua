---@class UnityEngine.MonoBehaviour : UnityEngine.Behaviour
---@field public useGUILayout boolean
---@field public runInEditMode boolean
local m = {}

---@param methodName string
---@param time number
function m:Invoke(methodName, time) end

---@param methodName string
---@param time number
---@param repeatRate number
function m:InvokeRepeating(methodName, time, repeatRate) end

---@overload fun(methodName:string)
function m:CancelInvoke() end

---@overload fun():
---@param methodName string
---@return boolean
function m:IsInvoking(methodName) end

---@overload fun(methodName:string, value:any):
---@overload fun(methodName:string):
---@param routine System.Collections.IEnumerator
---@return UnityEngine.Coroutine
function m:StartCoroutine(routine) end

---@param routine System.Collections.IEnumerator
---@return UnityEngine.Coroutine
function m:StartCoroutine_Auto(routine) end

---@overload fun(routine:System.Collections.IEnumerator)
---@overload fun(routine:UnityEngine.Coroutine)
---@param methodName string
function m:StopCoroutine(methodName) end

function m:StopAllCoroutines() end

---@static
---@param message any
function m.print(message) end

UnityEngine.MonoBehaviour = m
return m
