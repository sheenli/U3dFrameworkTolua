---@class UnityEngine.WheelHit : System.ValueType
---@field public collider UnityEngine.Collider
---@field public point UnityEngine.Vector3
---@field public normal UnityEngine.Vector3
---@field public forwardDir UnityEngine.Vector3
---@field public sidewaysDir UnityEngine.Vector3
---@field public force number
---@field public forwardSlip number
---@field public sidewaysSlip number
local m = {}

UnityEngine.WheelHit = m
return m
