---@class UnityEngine.ParticleSystemStopBehavior : System.Enum
---@field public StopEmittingAndClear UnityEngine.ParticleSystemStopBehavior @static
---@field public StopEmitting UnityEngine.ParticleSystemStopBehavior @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemStopBehavior = m
return m
