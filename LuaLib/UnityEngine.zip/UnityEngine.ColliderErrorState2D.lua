---@class UnityEngine.ColliderErrorState2D : System.Enum
---@field public None UnityEngine.ColliderErrorState2D @static
---@field public NoShapes UnityEngine.ColliderErrorState2D @static
---@field public RemovedShapes UnityEngine.ColliderErrorState2D @static
---@field public value__ number
local m = {}

UnityEngine.ColliderErrorState2D = m
return m
