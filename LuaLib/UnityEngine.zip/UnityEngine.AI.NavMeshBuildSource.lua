---@class UnityEngine.AI.NavMeshBuildSource : System.ValueType
---@field public transform UnityEngine.Matrix4x4
---@field public size UnityEngine.Vector3
---@field public shape UnityEngine.AI.NavMeshBuildSourceShape
---@field public area number
---@field public sourceObject UnityEngine.Object
---@field public component UnityEngine.Component
local m = {}

UnityEngine.AI.NavMeshBuildSource = m
return m
