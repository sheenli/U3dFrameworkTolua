---@class UnityEngine.iOS.Device : System.Object
---@field public generation UnityEngine.iOS.DeviceGeneration @static
---@field public systemVersion string @static
---@field public vendorIdentifier string @static
---@field public advertisingIdentifier string @static
---@field public advertisingTrackingEnabled boolean @static
local m = {}

---@static
---@param path string
function m.SetNoBackupFlag(path) end

---@static
---@param path string
function m.ResetNoBackupFlag(path) end

UnityEngine.iOS.Device = m
return m
