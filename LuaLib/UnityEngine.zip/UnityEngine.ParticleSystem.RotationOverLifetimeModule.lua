---@class UnityEngine.ParticleSystem.RotationOverLifetimeModule : System.ValueType
---@field public enabled boolean
---@field public x UnityEngine.ParticleSystem.MinMaxCurve
---@field public xMultiplier number
---@field public y UnityEngine.ParticleSystem.MinMaxCurve
---@field public yMultiplier number
---@field public z UnityEngine.ParticleSystem.MinMaxCurve
---@field public zMultiplier number
---@field public separateAxes boolean
local m = {}

UnityEngine.ParticleSystem.RotationOverLifetimeModule = m
return m
