---@class UnityEngine.AI.NavMeshBuilder : System.Object
local m = {}

---@overload fun(root:UnityEngine.Transform, includedLayerMask:number, geometry:UnityEngine.AI.NavMeshCollectGeometry, defaultArea:number, markups:UnityEngine.AI.NavMeshBuildMarkup[], results:UnityEngine.AI.NavMeshBuildSource[]) @static
---@static
---@param includedWorldBounds UnityEngine.Bounds
---@param includedLayerMask number
---@param geometry UnityEngine.AI.NavMeshCollectGeometry
---@param defaultArea number
---@param markups UnityEngine.AI.NavMeshBuildMarkup[]
---@param results UnityEngine.AI.NavMeshBuildSource[]
function m.CollectSources(includedWorldBounds, includedLayerMask, geometry, defaultArea, markups, results) end

---@static
---@param buildSettings UnityEngine.AI.NavMeshBuildSettings
---@param sources UnityEngine.AI.NavMeshBuildSource[]
---@param localBounds UnityEngine.Bounds
---@param position UnityEngine.Vector3
---@param rotation UnityEngine.Quaternion
---@return UnityEngine.AI.NavMeshData
function m.BuildNavMeshData(buildSettings, sources, localBounds, position, rotation) end

---@static
---@param data UnityEngine.AI.NavMeshData
---@param buildSettings UnityEngine.AI.NavMeshBuildSettings
---@param sources UnityEngine.AI.NavMeshBuildSource[]
---@param localBounds UnityEngine.Bounds
---@return boolean
function m.UpdateNavMeshData(data, buildSettings, sources, localBounds) end

---@static
---@param data UnityEngine.AI.NavMeshData
---@param buildSettings UnityEngine.AI.NavMeshBuildSettings
---@param sources UnityEngine.AI.NavMeshBuildSource[]
---@param localBounds UnityEngine.Bounds
---@return UnityEngine.AsyncOperation
function m.UpdateNavMeshDataAsync(data, buildSettings, sources, localBounds) end

---@static
---@param data UnityEngine.AI.NavMeshData
function m.Cancel(data) end

UnityEngine.AI.NavMeshBuilder = m
return m
