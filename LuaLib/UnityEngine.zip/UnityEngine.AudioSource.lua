---@class UnityEngine.AudioSource : UnityEngine.Behaviour
---@field public panLevel number
---@field public pan number
---@field public volume number
---@field public pitch number
---@field public time number
---@field public timeSamples number
---@field public clip UnityEngine.AudioClip
---@field public outputAudioMixerGroup UnityEngine.Audio.AudioMixerGroup
---@field public isPlaying boolean
---@field public isVirtual boolean
---@field public loop boolean
---@field public ignoreListenerVolume boolean
---@field public playOnAwake boolean
---@field public ignoreListenerPause boolean
---@field public velocityUpdateMode UnityEngine.AudioVelocityUpdateMode
---@field public panStereo number
---@field public spatialBlend number
---@field public spatialize boolean
---@field public spatializePostEffects boolean
---@field public reverbZoneMix number
---@field public bypassEffects boolean
---@field public bypassListenerEffects boolean
---@field public bypassReverbZones boolean
---@field public dopplerLevel number
---@field public spread number
---@field public priority number
---@field public mute boolean
---@field public minDistance number
---@field public maxDistance number
---@field public rolloffMode UnityEngine.AudioRolloffMode
---@field public minVolume number
---@field public maxVolume number
---@field public rolloffFactor number
local m = {}

---@overload fun()
---@param delay number
function m:Play(delay) end

---@param delay number
function m:PlayDelayed(delay) end

---@param time number
function m:PlayScheduled(time) end

---@param time number
function m:SetScheduledStartTime(time) end

---@param time number
function m:SetScheduledEndTime(time) end

function m:Stop() end

function m:Pause() end

function m:UnPause() end

---@overload fun(clip:UnityEngine.AudioClip)
---@param clip UnityEngine.AudioClip
---@param volumeScale number
function m:PlayOneShot(clip, volumeScale) end

---@overload fun(clip:UnityEngine.AudioClip, position:UnityEngine.Vector3, volume:number) @static
---@static
---@param clip UnityEngine.AudioClip
---@param position UnityEngine.Vector3
function m.PlayClipAtPoint(clip, position) end

---@param type UnityEngine.AudioSourceCurveType
---@param curve UnityEngine.AnimationCurve
function m:SetCustomCurve(type, curve) end

---@param type UnityEngine.AudioSourceCurveType
---@return UnityEngine.AnimationCurve
function m:GetCustomCurve(type) end

---@overload fun(samples:number[], channel:number)
---@param numSamples number
---@param channel number
---@return number[]
function m:GetOutputData(numSamples, channel) end

---@overload fun(samples:number[], channel:number, window:UnityEngine.FFTWindow)
---@param numSamples number
---@param channel number
---@param window UnityEngine.FFTWindow
---@return number[]
function m:GetSpectrumData(numSamples, channel, window) end

---@param index number
---@param value number
---@return boolean
function m:SetSpatializerFloat(index, value) end

---@param index number
---@return boolean, System.Single
function m:GetSpatializerFloat(index) end

---@extension
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOFade(endValue, duration) end

---@extension
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOPitch(endValue, duration) end

UnityEngine.AudioSource = m
return m
