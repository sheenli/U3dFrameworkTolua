---@class UnityEngine.TextureCompressionQuality : System.Enum
---@field public Fast UnityEngine.TextureCompressionQuality @static
---@field public Normal UnityEngine.TextureCompressionQuality @static
---@field public Best UnityEngine.TextureCompressionQuality @static
---@field public value__ number
local m = {}

UnityEngine.TextureCompressionQuality = m
return m
