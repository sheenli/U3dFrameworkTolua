---@class UnityEngine.ProceduralLoadingBehavior : System.Enum
---@field public DoNothing UnityEngine.ProceduralLoadingBehavior @static
---@field public Generate UnityEngine.ProceduralLoadingBehavior @static
---@field public BakeAndKeep UnityEngine.ProceduralLoadingBehavior @static
---@field public BakeAndDiscard UnityEngine.ProceduralLoadingBehavior @static
---@field public Cache UnityEngine.ProceduralLoadingBehavior @static
---@field public DoNothingAndCache UnityEngine.ProceduralLoadingBehavior @static
---@field public value__ number
local m = {}

UnityEngine.ProceduralLoadingBehavior = m
return m
