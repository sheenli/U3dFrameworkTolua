---@class UnityEngine.ParticleSystemSubEmitterType : System.Enum
---@field public Birth UnityEngine.ParticleSystemSubEmitterType @static
---@field public Collision UnityEngine.ParticleSystemSubEmitterType @static
---@field public Death UnityEngine.ParticleSystemSubEmitterType @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemSubEmitterType = m
return m
