---@class UnityEngine.Experimental.Rendering.DrawRendererSettings : System.ValueType
---@field public sorting UnityEngine.Experimental.Rendering.DrawRendererSortSettings
---@field public shaderPassName UnityEngine.Experimental.Rendering.ShaderPassName
---@field public inputFilter UnityEngine.Experimental.Rendering.InputFilter
---@field public rendererConfiguration UnityEngine.Experimental.Rendering.RendererConfiguration
---@field public flags UnityEngine.Experimental.Rendering.DrawRendererFlags
---@field public cullResults UnityEngine.Experimental.Rendering.CullResults
local m = {}

UnityEngine.Experimental.Rendering.DrawRendererSettings = m
return m
