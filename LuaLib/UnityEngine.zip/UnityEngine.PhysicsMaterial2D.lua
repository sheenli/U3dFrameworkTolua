---@class UnityEngine.PhysicsMaterial2D : UnityEngine.Object
---@field public bounciness number
---@field public friction number
local m = {}

UnityEngine.PhysicsMaterial2D = m
return m
