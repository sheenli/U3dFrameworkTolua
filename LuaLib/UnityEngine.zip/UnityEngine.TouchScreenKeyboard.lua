---@class UnityEngine.TouchScreenKeyboard : System.Object
---@field public isSupported boolean @static
---@field public hideInput boolean @static
---@field public area UnityEngine.Rect @static
---@field public visible boolean @static
---@field public text string
---@field public active boolean
---@field public done boolean
---@field public wasCanceled boolean
---@field public canGetSelection boolean
---@field public selection UnityEngine.RangeInt
---@field public targetDisplay number
local m = {}

---@overload fun(text:string, keyboardType:UnityEngine.TouchScreenKeyboardType, autocorrection:boolean, multiline:boolean, secure:boolean): @static
---@overload fun(text:string, keyboardType:UnityEngine.TouchScreenKeyboardType, autocorrection:boolean, multiline:boolean): @static
---@overload fun(text:string, keyboardType:UnityEngine.TouchScreenKeyboardType, autocorrection:boolean): @static
---@overload fun(text:string, keyboardType:UnityEngine.TouchScreenKeyboardType): @static
---@overload fun(text:string): @static
---@overload fun(text:string, keyboardType:UnityEngine.TouchScreenKeyboardType, autocorrection:boolean, multiline:boolean, secure:boolean, alert:boolean, textPlaceholder:string): @static
---@static
---@param text string
---@param keyboardType UnityEngine.TouchScreenKeyboardType
---@param autocorrection boolean
---@param multiline boolean
---@param secure boolean
---@param alert boolean
---@return UnityEngine.TouchScreenKeyboard
function m.Open(text, keyboardType, autocorrection, multiline, secure, alert) end

UnityEngine.TouchScreenKeyboard = m
return m
