---@class UnityEngine.RectTransform : UnityEngine.Transform
---@field public rect UnityEngine.Rect
---@field public anchorMin UnityEngine.Vector2
---@field public anchorMax UnityEngine.Vector2
---@field public anchoredPosition3D UnityEngine.Vector3
---@field public anchoredPosition UnityEngine.Vector2
---@field public sizeDelta UnityEngine.Vector2
---@field public pivot UnityEngine.Vector2
---@field public offsetMin UnityEngine.Vector2
---@field public offsetMax UnityEngine.Vector2
local m = {}

---@static
---@param value fun(driven:UnityEngine.RectTransform)
function m.add_reapplyDrivenProperties(value) end

---@static
---@param value fun(driven:UnityEngine.RectTransform)
function m.remove_reapplyDrivenProperties(value) end

---@param fourCornersArray UnityEngine.Vector3[]
function m:GetLocalCorners(fourCornersArray) end

---@param fourCornersArray UnityEngine.Vector3[]
function m:GetWorldCorners(fourCornersArray) end

---@param edge UnityEngine.RectTransform.Edge
---@param inset number
---@param size number
function m:SetInsetAndSizeFromParentEdge(edge, inset, size) end

---@param axis UnityEngine.RectTransform.Axis
---@param size number
function m:SetSizeWithCurrentAnchors(axis, size) end

---@overload fun(endValue:UnityEngine.Vector2, duration:number): @extension
---@extension
---@param endValue UnityEngine.Vector2
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOAnchorPos(endValue, duration, snapping) end

---@overload fun(endValue:number, duration:number): @extension
---@extension
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOAnchorPosX(endValue, duration, snapping) end

---@overload fun(endValue:number, duration:number): @extension
---@extension
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOAnchorPosY(endValue, duration, snapping) end

---@overload fun(endValue:UnityEngine.Vector3, duration:number): @extension
---@extension
---@param endValue UnityEngine.Vector3
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOAnchorPos3D(endValue, duration, snapping) end

---@overload fun(endValue:number, duration:number): @extension
---@extension
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOAnchorPos3DX(endValue, duration, snapping) end

---@overload fun(endValue:number, duration:number): @extension
---@extension
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOAnchorPos3DY(endValue, duration, snapping) end

---@overload fun(endValue:number, duration:number): @extension
---@extension
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOAnchorPos3DZ(endValue, duration, snapping) end

---@overload fun(endValue:UnityEngine.Vector2, duration:number): @extension
---@extension
---@param endValue UnityEngine.Vector2
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOAnchorMax(endValue, duration, snapping) end

---@overload fun(endValue:UnityEngine.Vector2, duration:number): @extension
---@extension
---@param endValue UnityEngine.Vector2
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOAnchorMin(endValue, duration, snapping) end

---@extension
---@param endValue UnityEngine.Vector2
---@param duration number
---@return DG.Tweening.Tweener
function m.DOPivot(endValue, duration) end

---@extension
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOPivotX(endValue, duration) end

---@extension
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOPivotY(endValue, duration) end

---@overload fun(endValue:UnityEngine.Vector2, duration:number): @extension
---@extension
---@param endValue UnityEngine.Vector2
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOSizeDelta(endValue, duration, snapping) end

---@overload fun(punch:UnityEngine.Vector2, duration:number, vibrato:number, elasticity:number): @extension
---@overload fun(punch:UnityEngine.Vector2, duration:number, vibrato:number): @extension
---@overload fun(punch:UnityEngine.Vector2, duration:number): @extension
---@extension
---@param punch UnityEngine.Vector2
---@param duration number
---@param vibrato number
---@param elasticity number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOPunchAnchorPos(punch, duration, vibrato, elasticity, snapping) end

---@overload fun(duration:number, strength:number, vibrato:number, randomness:number, snapping:boolean): @extension
---@overload fun(duration:number, strength:number, vibrato:number, randomness:number): @extension
---@overload fun(duration:number, strength:number, vibrato:number): @extension
---@overload fun(duration:number, strength:number): @extension
---@overload fun(duration:number): @extension
---@overload fun(duration:number, strength:UnityEngine.Vector2, vibrato:number, randomness:number, snapping:boolean, fadeOut:boolean): @extension
---@overload fun(duration:number, strength:UnityEngine.Vector2, vibrato:number, randomness:number, snapping:boolean): @extension
---@overload fun(duration:number, strength:UnityEngine.Vector2, vibrato:number, randomness:number): @extension
---@overload fun(duration:number, strength:UnityEngine.Vector2, vibrato:number): @extension
---@overload fun(duration:number, strength:UnityEngine.Vector2): @extension
---@extension
---@param duration number
---@param strength number
---@param vibrato number
---@param randomness number
---@param snapping boolean
---@param fadeOut boolean
---@return DG.Tweening.Tweener
function m.DOShakeAnchorPos(duration, strength, vibrato, randomness, snapping, fadeOut) end

---@overload fun(endValue:UnityEngine.Vector2, jumpPower:number, numJumps:number, duration:number): @extension
---@extension
---@param endValue UnityEngine.Vector2
---@param jumpPower number
---@param numJumps number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Sequence
function m.DOJumpAnchorPos(endValue, jumpPower, numJumps, duration, snapping) end

UnityEngine.RectTransform = m
return m
