---@class UnityEngine.DisableBatchingType : System.Enum
---@field public False UnityEngine.DisableBatchingType @static
---@field public True UnityEngine.DisableBatchingType @static
---@field public WhenLODFading UnityEngine.DisableBatchingType @static
---@field public value__ number
local m = {}

UnityEngine.DisableBatchingType = m
return m
