---@class UnityEngine.ForceMode : System.Enum
---@field public Force UnityEngine.ForceMode @static
---@field public Acceleration UnityEngine.ForceMode @static
---@field public Impulse UnityEngine.ForceMode @static
---@field public VelocityChange UnityEngine.ForceMode @static
---@field public value__ number
local m = {}

UnityEngine.ForceMode = m
return m
