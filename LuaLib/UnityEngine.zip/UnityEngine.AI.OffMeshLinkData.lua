---@class UnityEngine.AI.OffMeshLinkData : System.ValueType
---@field public valid boolean
---@field public activated boolean
---@field public linkType UnityEngine.AI.OffMeshLinkType
---@field public startPos UnityEngine.Vector3
---@field public endPos UnityEngine.Vector3
---@field public offMeshLink UnityEngine.AI.OffMeshLink
local m = {}

UnityEngine.AI.OffMeshLinkData = m
return m
