---@class UnityEngine.ConnectionTesterStatus : System.Enum
---@field public Error UnityEngine.ConnectionTesterStatus @static
---@field public Undetermined UnityEngine.ConnectionTesterStatus @static
---@field public PrivateIPNoNATPunchthrough UnityEngine.ConnectionTesterStatus @static
---@field public PrivateIPHasNATPunchThrough UnityEngine.ConnectionTesterStatus @static
---@field public PublicIPIsConnectable UnityEngine.ConnectionTesterStatus @static
---@field public PublicIPPortBlocked UnityEngine.ConnectionTesterStatus @static
---@field public PublicIPNoServerStarted UnityEngine.ConnectionTesterStatus @static
---@field public LimitedNATPunchthroughPortRestricted UnityEngine.ConnectionTesterStatus @static
---@field public LimitedNATPunchthroughSymmetric UnityEngine.ConnectionTesterStatus @static
---@field public NATpunchthroughFullCone UnityEngine.ConnectionTesterStatus @static
---@field public NATpunchthroughAddressRestrictedCone UnityEngine.ConnectionTesterStatus @static
---@field public value__ number
local m = {}

UnityEngine.ConnectionTesterStatus = m
return m
