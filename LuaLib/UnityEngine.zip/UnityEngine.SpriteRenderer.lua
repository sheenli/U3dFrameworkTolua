---@class UnityEngine.SpriteRenderer : UnityEngine.Renderer
---@field public sprite UnityEngine.Sprite
---@field public drawMode UnityEngine.SpriteDrawMode
---@field public size UnityEngine.Vector2
---@field public adaptiveModeThreshold number
---@field public tileMode UnityEngine.SpriteTileMode
---@field public color UnityEngine.Color
---@field public flipX boolean
---@field public flipY boolean
local m = {}

---@extension
---@param endValue UnityEngine.Color
---@param duration number
---@return DG.Tweening.Tweener
function m.DOColor(endValue, duration) end

---@extension
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOFade(endValue, duration) end

---@extension
---@param gradient UnityEngine.Gradient
---@param duration number
---@return DG.Tweening.Sequence
function m.DOGradientColor(gradient, duration) end

---@extension
---@param endValue UnityEngine.Color
---@param duration number
---@return DG.Tweening.Tweener
function m.DOBlendableColor(endValue, duration) end

UnityEngine.SpriteRenderer = m
return m
