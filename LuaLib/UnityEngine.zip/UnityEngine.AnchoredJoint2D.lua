---@class UnityEngine.AnchoredJoint2D : UnityEngine.Joint2D
---@field public anchor UnityEngine.Vector2
---@field public connectedAnchor UnityEngine.Vector2
---@field public autoConfigureConnectedAnchor boolean
local m = {}

UnityEngine.AnchoredJoint2D = m
return m
