---@class UnityEngine.ConfigurableJointMotion : System.Enum
---@field public Locked UnityEngine.ConfigurableJointMotion @static
---@field public Limited UnityEngine.ConfigurableJointMotion @static
---@field public Free UnityEngine.ConfigurableJointMotion @static
---@field public value__ number
local m = {}

UnityEngine.ConfigurableJointMotion = m
return m
