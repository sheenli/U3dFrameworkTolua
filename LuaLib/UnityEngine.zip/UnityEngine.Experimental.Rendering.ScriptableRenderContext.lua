---@class UnityEngine.Experimental.Rendering.ScriptableRenderContext : System.ValueType
local m = {}

function m:Submit() end

---@param settings UnityEngine.Experimental.Rendering.DrawRendererSettings
---@return UnityEngine.Experimental.Rendering.DrawRendererSettings
function m:DrawRenderers(settings) end

---@param settings UnityEngine.Experimental.Rendering.DrawShadowsSettings
---@return UnityEngine.Experimental.Rendering.DrawShadowsSettings
function m:DrawShadows(settings) end

---@param commandBuffer UnityEngine.Rendering.CommandBuffer
function m:ExecuteCommandBuffer(commandBuffer) end

---@param camera UnityEngine.Camera
function m:SetupCameraProperties(camera) end

---@param camera UnityEngine.Camera
function m:DrawSkybox(camera) end

UnityEngine.Experimental.Rendering.ScriptableRenderContext = m
return m
