---@class UnityEngine.Camera : UnityEngine.Behaviour
---@field public onPreCull fun(cam:UnityEngine.Camera) @static
---@field public onPreRender fun(cam:UnityEngine.Camera) @static
---@field public onPostRender fun(cam:UnityEngine.Camera) @static
---@field public main UnityEngine.Camera @static
---@field public current UnityEngine.Camera @static
---@field public allCameras UnityEngine.Camera[] @static
---@field public allCamerasCount number @static
---@field public mainCamera UnityEngine.Camera @static
---@field public fov number
---@field public near number
---@field public far number
---@field public fieldOfView number
---@field public nearClipPlane number
---@field public farClipPlane number
---@field public renderingPath UnityEngine.RenderingPath
---@field public actualRenderingPath UnityEngine.RenderingPath
---@field public allowHDR boolean
---@field public hdr boolean
---@field public forceIntoRenderTexture boolean
---@field public allowMSAA boolean
---@field public orthographicSize number
---@field public orthographic boolean
---@field public opaqueSortMode UnityEngine.Rendering.OpaqueSortMode
---@field public transparencySortMode UnityEngine.TransparencySortMode
---@field public transparencySortAxis UnityEngine.Vector3
---@field public depth number
---@field public aspect number
---@field public cullingMask number
---@field public eventMask number
---@field public backgroundColor UnityEngine.Color
---@field public rect UnityEngine.Rect
---@field public pixelRect UnityEngine.Rect
---@field public targetTexture UnityEngine.RenderTexture
---@field public activeTexture UnityEngine.RenderTexture
---@field public pixelWidth number
---@field public pixelHeight number
---@field public cameraToWorldMatrix UnityEngine.Matrix4x4
---@field public worldToCameraMatrix UnityEngine.Matrix4x4
---@field public projectionMatrix UnityEngine.Matrix4x4
---@field public nonJitteredProjectionMatrix UnityEngine.Matrix4x4
---@field public useJitteredProjectionMatrixForTransparentRendering boolean
---@field public velocity UnityEngine.Vector3
---@field public clearFlags UnityEngine.CameraClearFlags
---@field public stereoEnabled boolean
---@field public stereoSeparation number
---@field public stereoConvergence number
---@field public cameraType UnityEngine.CameraType
---@field public stereoMirrorMode boolean
---@field public stereoTargetEye UnityEngine.StereoTargetEyeMask
---@field public stereoActiveEye UnityEngine.Camera.MonoOrStereoscopicEye
---@field public targetDisplay number
---@field public useOcclusionCulling boolean
---@field public cullingMatrix UnityEngine.Matrix4x4
---@field public layerCullDistances number[]
---@field public layerCullSpherical boolean
---@field public depthTextureMode UnityEngine.DepthTextureMode
---@field public clearStencilAfterLightingPass boolean
---@field public commandBufferCount number
---@field public isOrthoGraphic boolean
local m = {}

---@overload fun(colorBuffer:UnityEngine.RenderBuffer[], depthBuffer:UnityEngine.RenderBuffer)
---@param colorBuffer UnityEngine.RenderBuffer
---@param depthBuffer UnityEngine.RenderBuffer
function m:SetTargetBuffers(colorBuffer, depthBuffer) end

function m:ResetWorldToCameraMatrix() end

function m:ResetProjectionMatrix() end

function m:ResetAspect() end

function m:ResetFieldOfView() end

---@return UnityEngine.Matrix4x4[]
function m:GetStereoViewMatrices() end

---@param eye UnityEngine.Camera.StereoscopicEye
---@return UnityEngine.Matrix4x4
function m:GetStereoViewMatrix(eye) end

---@param leftMatrix UnityEngine.Matrix4x4
---@param rightMatrix UnityEngine.Matrix4x4
function m:SetStereoViewMatrices(leftMatrix, rightMatrix) end

---@param eye UnityEngine.Camera.StereoscopicEye
---@param matrix UnityEngine.Matrix4x4
function m:SetStereoViewMatrix(eye, matrix) end

function m:ResetStereoViewMatrices() end

---@return UnityEngine.Matrix4x4[]
function m:GetStereoProjectionMatrices() end

---@param eye UnityEngine.Camera.StereoscopicEye
---@return UnityEngine.Matrix4x4
function m:GetStereoProjectionMatrix(eye) end

---@param eye UnityEngine.Camera.StereoscopicEye
---@param matrix UnityEngine.Matrix4x4
function m:SetStereoProjectionMatrix(eye, matrix) end

---@param leftMatrix UnityEngine.Matrix4x4
---@param rightMatrix UnityEngine.Matrix4x4
function m:SetStereoProjectionMatrices(leftMatrix, rightMatrix) end

---@param viewport UnityEngine.Rect
---@param z number
---@param eye UnityEngine.Camera.MonoOrStereoscopicEye
---@param outCorners UnityEngine.Vector3[]
function m:CalculateFrustumCorners(viewport, z, eye, outCorners) end

function m:ResetStereoProjectionMatrices() end

function m:ResetTransparencySortSettings() end

---@param position UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:WorldToScreenPoint(position) end

---@param position UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:WorldToViewportPoint(position) end

---@param position UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:ViewportToWorldPoint(position) end

---@param position UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:ScreenToWorldPoint(position) end

---@param position UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:ScreenToViewportPoint(position) end

---@param position UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:ViewportToScreenPoint(position) end

---@param position UnityEngine.Vector3
---@return UnityEngine.Ray
function m:ViewportPointToRay(position) end

---@param position UnityEngine.Vector3
---@return UnityEngine.Ray
function m:ScreenPointToRay(position) end

---@static
---@param cameras UnityEngine.Camera[]
---@return number
function m.GetAllCameras(cameras) end

function m:Render() end

---@param shader UnityEngine.Shader
---@param replacementTag string
function m:RenderWithShader(shader, replacementTag) end

---@param shader UnityEngine.Shader
---@param replacementTag string
function m:SetReplacementShader(shader, replacementTag) end

function m:ResetReplacementShader() end

function m:ResetCullingMatrix() end

function m:RenderDontRestore() end

---@static
---@param cur UnityEngine.Camera
function m.SetupCurrent(cur) end

---@overload fun(cubemap:UnityEngine.Cubemap, faceMask:number):
---@overload fun(cubemap:UnityEngine.RenderTexture):
---@overload fun(cubemap:UnityEngine.RenderTexture, faceMask:number):
---@param cubemap UnityEngine.Cubemap
---@return boolean
function m:RenderToCubemap(cubemap) end

---@param other UnityEngine.Camera
function m:CopyFrom(other) end

---@param evt UnityEngine.Rendering.CameraEvent
---@param buffer UnityEngine.Rendering.CommandBuffer
function m:AddCommandBuffer(evt, buffer) end

---@param evt UnityEngine.Rendering.CameraEvent
---@param buffer UnityEngine.Rendering.CommandBuffer
function m:RemoveCommandBuffer(evt, buffer) end

---@param evt UnityEngine.Rendering.CameraEvent
function m:RemoveCommandBuffers(evt) end

function m:RemoveAllCommandBuffers() end

---@param evt UnityEngine.Rendering.CameraEvent
---@return UnityEngine.Rendering.CommandBuffer[]
function m:GetCommandBuffers(evt) end

---@param clipPlane UnityEngine.Vector4
---@return UnityEngine.Matrix4x4
function m:CalculateObliqueMatrix(clipPlane) end

---@return number
function m:GetScreenWidth() end

---@return number
function m:GetScreenHeight() end

function m:DoClear() end

UnityEngine.Camera = m
return m
