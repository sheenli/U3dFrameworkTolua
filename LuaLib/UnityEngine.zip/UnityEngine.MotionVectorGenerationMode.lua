---@class UnityEngine.MotionVectorGenerationMode : System.Enum
---@field public Camera UnityEngine.MotionVectorGenerationMode @static
---@field public Object UnityEngine.MotionVectorGenerationMode @static
---@field public ForceNoMotion UnityEngine.MotionVectorGenerationMode @static
---@field public value__ number
local m = {}

UnityEngine.MotionVectorGenerationMode = m
return m
