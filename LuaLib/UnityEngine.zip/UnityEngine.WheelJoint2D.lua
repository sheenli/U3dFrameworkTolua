---@class UnityEngine.WheelJoint2D : UnityEngine.AnchoredJoint2D
---@field public suspension UnityEngine.JointSuspension2D
---@field public useMotor boolean
---@field public motor UnityEngine.JointMotor2D
---@field public jointTranslation number
---@field public jointLinearSpeed number
---@field public jointSpeed number
---@field public jointAngle number
local m = {}

---@param timeStep number
---@return number
function m:GetMotorTorque(timeStep) end

UnityEngine.WheelJoint2D = m
return m
