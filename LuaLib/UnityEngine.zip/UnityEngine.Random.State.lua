---@class UnityEngine.Random.State : System.ValueType
local m = {}

UnityEngine.Random.State = m
return m
