---@class UnityEngine.Physics2D : System.Object
---@field public IgnoreRaycastLayer number @static
---@field public DefaultRaycastLayers number @static
---@field public AllLayers number @static
---@field public raycastsHitTriggers boolean @static
---@field public raycastsStartInColliders boolean @static
---@field public deleteStopsCallbacks boolean @static
---@field public minPenetrationForPenalty number @static
---@field public velocityIterations number @static
---@field public positionIterations number @static
---@field public gravity UnityEngine.Vector2 @static
---@field public queriesHitTriggers boolean @static
---@field public queriesStartInColliders boolean @static
---@field public changeStopsCallbacks boolean @static
---@field public callbacksOnDisable boolean @static
---@field public velocityThreshold number @static
---@field public maxLinearCorrection number @static
---@field public maxAngularCorrection number @static
---@field public maxTranslationSpeed number @static
---@field public maxRotationSpeed number @static
---@field public defaultContactOffset number @static
---@field public baumgarteScale number @static
---@field public baumgarteTOIScale number @static
---@field public timeToSleep number @static
---@field public linearSleepTolerance number @static
---@field public angularSleepTolerance number @static
---@field public alwaysShowColliders boolean @static
---@field public showColliderSleep boolean @static
---@field public showColliderContacts boolean @static
---@field public showColliderAABB boolean @static
---@field public contactArrowScale number @static
---@field public colliderAwakeColor UnityEngine.Color @static
---@field public colliderAsleepColor UnityEngine.Color @static
---@field public colliderContactColor UnityEngine.Color @static
---@field public colliderAABBColor UnityEngine.Color @static
local m = {}

---@overload fun(collider1:UnityEngine.Collider2D, collider2:UnityEngine.Collider2D) @static
---@static
---@param collider1 UnityEngine.Collider2D
---@param collider2 UnityEngine.Collider2D
---@param ignore boolean
function m.IgnoreCollision(collider1, collider2, ignore) end

---@static
---@param collider1 UnityEngine.Collider2D
---@param collider2 UnityEngine.Collider2D
---@return boolean
function m.GetIgnoreCollision(collider1, collider2) end

---@overload fun(layer1:number, layer2:number) @static
---@static
---@param layer1 number
---@param layer2 number
---@param ignore boolean
function m.IgnoreLayerCollision(layer1, layer2, ignore) end

---@static
---@param layer1 number
---@param layer2 number
---@return boolean
function m.GetIgnoreLayerCollision(layer1, layer2) end

---@static
---@param layer number
---@param layerMask number
function m.SetLayerCollisionMask(layer, layerMask) end

---@static
---@param layer number
---@return number
function m.GetLayerCollisionMask(layer) end

---@overload fun(collider1:UnityEngine.Collider2D, collider2:UnityEngine.Collider2D, contactFilter:UnityEngine.ContactFilter2D): @static
---@overload fun(collider:UnityEngine.Collider2D, contactFilter:UnityEngine.ContactFilter2D): @static
---@static
---@param collider1 UnityEngine.Collider2D
---@param collider2 UnityEngine.Collider2D
---@return boolean
function m.IsTouching(collider1, collider2) end

---@overload fun(collider:UnityEngine.Collider2D): @static
---@static
---@param collider UnityEngine.Collider2D
---@param layerMask number
---@return boolean
function m.IsTouchingLayers(collider, layerMask) end

---@static
---@param colliderA UnityEngine.Collider2D
---@param colliderB UnityEngine.Collider2D
---@return UnityEngine.ColliderDistance2D
function m.Distance(colliderA, colliderB) end

---@overload fun(start:UnityEngine.Vector2, _end:UnityEngine.Vector2, layerMask:number): @static
---@overload fun(start:UnityEngine.Vector2, _end:UnityEngine.Vector2): @static
---@overload fun(start:UnityEngine.Vector2, _end:UnityEngine.Vector2, layerMask:number, minDepth:number, maxDepth:number): @static
---@overload fun(start:UnityEngine.Vector2, _end:UnityEngine.Vector2, contactFilter:UnityEngine.ContactFilter2D, results:UnityEngine.RaycastHit2D[]): @static
---@static
---@param start UnityEngine.Vector2
---@param _end UnityEngine.Vector2
---@param layerMask number
---@param minDepth number
---@return UnityEngine.RaycastHit2D
function m.Linecast(start, _end, layerMask, minDepth) end

---@overload fun(start:UnityEngine.Vector2, _end:UnityEngine.Vector2, layerMask:number): @static
---@overload fun(start:UnityEngine.Vector2, _end:UnityEngine.Vector2): @static
---@overload fun(start:UnityEngine.Vector2, _end:UnityEngine.Vector2, layerMask:number, minDepth:number, maxDepth:number): @static
---@static
---@param start UnityEngine.Vector2
---@param _end UnityEngine.Vector2
---@param layerMask number
---@param minDepth number
---@return UnityEngine.RaycastHit2D[]
function m.LinecastAll(start, _end, layerMask, minDepth) end

---@overload fun(start:UnityEngine.Vector2, _end:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], layerMask:number): @static
---@overload fun(start:UnityEngine.Vector2, _end:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[]): @static
---@overload fun(start:UnityEngine.Vector2, _end:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], layerMask:number, minDepth:number, maxDepth:number): @static
---@static
---@param start UnityEngine.Vector2
---@param _end UnityEngine.Vector2
---@param results UnityEngine.RaycastHit2D[]
---@param layerMask number
---@param minDepth number
---@return number
function m.LinecastNonAlloc(start, _end, results, layerMask, minDepth) end

---@overload fun(origin:UnityEngine.Vector2, direction:UnityEngine.Vector2, distance:number, layerMask:number): @static
---@overload fun(origin:UnityEngine.Vector2, direction:UnityEngine.Vector2, distance:number): @static
---@overload fun(origin:UnityEngine.Vector2, direction:UnityEngine.Vector2): @static
---@overload fun(origin:UnityEngine.Vector2, direction:UnityEngine.Vector2, distance:number, layerMask:number, minDepth:number, maxDepth:number): @static
---@overload fun(origin:UnityEngine.Vector2, direction:UnityEngine.Vector2, contactFilter:UnityEngine.ContactFilter2D, results:UnityEngine.RaycastHit2D[]): @static
---@overload fun(origin:UnityEngine.Vector2, direction:UnityEngine.Vector2, contactFilter:UnityEngine.ContactFilter2D, results:UnityEngine.RaycastHit2D[], distance:number): @static
---@static
---@param origin UnityEngine.Vector2
---@param direction UnityEngine.Vector2
---@param distance number
---@param layerMask number
---@param minDepth number
---@return UnityEngine.RaycastHit2D
function m.Raycast(origin, direction, distance, layerMask, minDepth) end

---@overload fun(origin:UnityEngine.Vector2, direction:UnityEngine.Vector2, distance:number, layerMask:number): @static
---@overload fun(origin:UnityEngine.Vector2, direction:UnityEngine.Vector2, distance:number): @static
---@overload fun(origin:UnityEngine.Vector2, direction:UnityEngine.Vector2): @static
---@overload fun(origin:UnityEngine.Vector2, direction:UnityEngine.Vector2, distance:number, layerMask:number, minDepth:number, maxDepth:number): @static
---@static
---@param origin UnityEngine.Vector2
---@param direction UnityEngine.Vector2
---@param distance number
---@param layerMask number
---@param minDepth number
---@return UnityEngine.RaycastHit2D[]
function m.RaycastAll(origin, direction, distance, layerMask, minDepth) end

---@overload fun(origin:UnityEngine.Vector2, direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number, layerMask:number): @static
---@overload fun(origin:UnityEngine.Vector2, direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number): @static
---@overload fun(origin:UnityEngine.Vector2, direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[]): @static
---@overload fun(origin:UnityEngine.Vector2, direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number, layerMask:number, minDepth:number, maxDepth:number): @static
---@static
---@param origin UnityEngine.Vector2
---@param direction UnityEngine.Vector2
---@param results UnityEngine.RaycastHit2D[]
---@param distance number
---@param layerMask number
---@param minDepth number
---@return number
function m.RaycastNonAlloc(origin, direction, results, distance, layerMask, minDepth) end

---@overload fun(origin:UnityEngine.Vector2, radius:number, direction:UnityEngine.Vector2, distance:number, layerMask:number): @static
---@overload fun(origin:UnityEngine.Vector2, radius:number, direction:UnityEngine.Vector2, distance:number): @static
---@overload fun(origin:UnityEngine.Vector2, radius:number, direction:UnityEngine.Vector2): @static
---@overload fun(origin:UnityEngine.Vector2, radius:number, direction:UnityEngine.Vector2, distance:number, layerMask:number, minDepth:number, maxDepth:number): @static
---@overload fun(origin:UnityEngine.Vector2, radius:number, direction:UnityEngine.Vector2, contactFilter:UnityEngine.ContactFilter2D, results:UnityEngine.RaycastHit2D[]): @static
---@overload fun(origin:UnityEngine.Vector2, radius:number, direction:UnityEngine.Vector2, contactFilter:UnityEngine.ContactFilter2D, results:UnityEngine.RaycastHit2D[], distance:number): @static
---@static
---@param origin UnityEngine.Vector2
---@param radius number
---@param direction UnityEngine.Vector2
---@param distance number
---@param layerMask number
---@param minDepth number
---@return UnityEngine.RaycastHit2D
function m.CircleCast(origin, radius, direction, distance, layerMask, minDepth) end

---@overload fun(origin:UnityEngine.Vector2, radius:number, direction:UnityEngine.Vector2, distance:number, layerMask:number): @static
---@overload fun(origin:UnityEngine.Vector2, radius:number, direction:UnityEngine.Vector2, distance:number): @static
---@overload fun(origin:UnityEngine.Vector2, radius:number, direction:UnityEngine.Vector2): @static
---@overload fun(origin:UnityEngine.Vector2, radius:number, direction:UnityEngine.Vector2, distance:number, layerMask:number, minDepth:number, maxDepth:number): @static
---@static
---@param origin UnityEngine.Vector2
---@param radius number
---@param direction UnityEngine.Vector2
---@param distance number
---@param layerMask number
---@param minDepth number
---@return UnityEngine.RaycastHit2D[]
function m.CircleCastAll(origin, radius, direction, distance, layerMask, minDepth) end

---@overload fun(origin:UnityEngine.Vector2, radius:number, direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number, layerMask:number): @static
---@overload fun(origin:UnityEngine.Vector2, radius:number, direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number): @static
---@overload fun(origin:UnityEngine.Vector2, radius:number, direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[]): @static
---@overload fun(origin:UnityEngine.Vector2, radius:number, direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number, layerMask:number, minDepth:number, maxDepth:number): @static
---@static
---@param origin UnityEngine.Vector2
---@param radius number
---@param direction UnityEngine.Vector2
---@param results UnityEngine.RaycastHit2D[]
---@param distance number
---@param layerMask number
---@param minDepth number
---@return number
function m.CircleCastNonAlloc(origin, radius, direction, results, distance, layerMask, minDepth) end

---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, direction:UnityEngine.Vector2, distance:number, layerMask:number): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, direction:UnityEngine.Vector2, distance:number): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, direction:UnityEngine.Vector2): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, direction:UnityEngine.Vector2, distance:number, layerMask:number, minDepth:number, maxDepth:number): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, direction:UnityEngine.Vector2, contactFilter:UnityEngine.ContactFilter2D, results:UnityEngine.RaycastHit2D[]): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, direction:UnityEngine.Vector2, contactFilter:UnityEngine.ContactFilter2D, results:UnityEngine.RaycastHit2D[], distance:number): @static
---@static
---@param origin UnityEngine.Vector2
---@param size UnityEngine.Vector2
---@param angle number
---@param direction UnityEngine.Vector2
---@param distance number
---@param layerMask number
---@param minDepth number
---@return UnityEngine.RaycastHit2D
function m.BoxCast(origin, size, angle, direction, distance, layerMask, minDepth) end

---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, direction:UnityEngine.Vector2, distance:number, layerMask:number): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, direction:UnityEngine.Vector2, distance:number): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, direction:UnityEngine.Vector2): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, direction:UnityEngine.Vector2, distance:number, layerMask:number, minDepth:number, maxDepth:number): @static
---@static
---@param origin UnityEngine.Vector2
---@param size UnityEngine.Vector2
---@param angle number
---@param direction UnityEngine.Vector2
---@param distance number
---@param layerMask number
---@param minDepth number
---@return UnityEngine.RaycastHit2D[]
function m.BoxCastAll(origin, size, angle, direction, distance, layerMask, minDepth) end

---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number, layerMask:number): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[]): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number, layerMask:number, minDepth:number, maxDepth:number): @static
---@static
---@param origin UnityEngine.Vector2
---@param size UnityEngine.Vector2
---@param angle number
---@param direction UnityEngine.Vector2
---@param results UnityEngine.RaycastHit2D[]
---@param distance number
---@param layerMask number
---@param minDepth number
---@return number
function m.BoxCastNonAlloc(origin, size, angle, direction, results, distance, layerMask, minDepth) end

---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, capsuleDirection:UnityEngine.CapsuleDirection2D, angle:number, direction:UnityEngine.Vector2, distance:number, layerMask:number): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, capsuleDirection:UnityEngine.CapsuleDirection2D, angle:number, direction:UnityEngine.Vector2, distance:number): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, capsuleDirection:UnityEngine.CapsuleDirection2D, angle:number, direction:UnityEngine.Vector2): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, capsuleDirection:UnityEngine.CapsuleDirection2D, angle:number, direction:UnityEngine.Vector2, distance:number, layerMask:number, minDepth:number, maxDepth:number): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, capsuleDirection:UnityEngine.CapsuleDirection2D, angle:number, direction:UnityEngine.Vector2, contactFilter:UnityEngine.ContactFilter2D, results:UnityEngine.RaycastHit2D[]): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, capsuleDirection:UnityEngine.CapsuleDirection2D, angle:number, direction:UnityEngine.Vector2, contactFilter:UnityEngine.ContactFilter2D, results:UnityEngine.RaycastHit2D[], distance:number): @static
---@static
---@param origin UnityEngine.Vector2
---@param size UnityEngine.Vector2
---@param capsuleDirection UnityEngine.CapsuleDirection2D
---@param angle number
---@param direction UnityEngine.Vector2
---@param distance number
---@param layerMask number
---@param minDepth number
---@return UnityEngine.RaycastHit2D
function m.CapsuleCast(origin, size, capsuleDirection, angle, direction, distance, layerMask, minDepth) end

---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, capsuleDirection:UnityEngine.CapsuleDirection2D, angle:number, direction:UnityEngine.Vector2, distance:number, layerMask:number): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, capsuleDirection:UnityEngine.CapsuleDirection2D, angle:number, direction:UnityEngine.Vector2, distance:number): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, capsuleDirection:UnityEngine.CapsuleDirection2D, angle:number, direction:UnityEngine.Vector2): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, capsuleDirection:UnityEngine.CapsuleDirection2D, angle:number, direction:UnityEngine.Vector2, distance:number, layerMask:number, minDepth:number, maxDepth:number): @static
---@static
---@param origin UnityEngine.Vector2
---@param size UnityEngine.Vector2
---@param capsuleDirection UnityEngine.CapsuleDirection2D
---@param angle number
---@param direction UnityEngine.Vector2
---@param distance number
---@param layerMask number
---@param minDepth number
---@return UnityEngine.RaycastHit2D[]
function m.CapsuleCastAll(origin, size, capsuleDirection, angle, direction, distance, layerMask, minDepth) end

---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, capsuleDirection:UnityEngine.CapsuleDirection2D, angle:number, direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number, layerMask:number): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, capsuleDirection:UnityEngine.CapsuleDirection2D, angle:number, direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, capsuleDirection:UnityEngine.CapsuleDirection2D, angle:number, direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[]): @static
---@overload fun(origin:UnityEngine.Vector2, size:UnityEngine.Vector2, capsuleDirection:UnityEngine.CapsuleDirection2D, angle:number, direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number, layerMask:number, minDepth:number, maxDepth:number): @static
---@static
---@param origin UnityEngine.Vector2
---@param size UnityEngine.Vector2
---@param capsuleDirection UnityEngine.CapsuleDirection2D
---@param angle number
---@param direction UnityEngine.Vector2
---@param results UnityEngine.RaycastHit2D[]
---@param distance number
---@param layerMask number
---@param minDepth number
---@return number
function m.CapsuleCastNonAlloc(origin, size, capsuleDirection, angle, direction, results, distance, layerMask, minDepth) end

---@overload fun(ray:UnityEngine.Ray): @static
---@overload fun(ray:UnityEngine.Ray, distance:number, layerMask:number): @static
---@static
---@param ray UnityEngine.Ray
---@param distance number
---@return UnityEngine.RaycastHit2D
function m.GetRayIntersection(ray, distance) end

---@overload fun(ray:UnityEngine.Ray, distance:number): @static
---@overload fun(ray:UnityEngine.Ray): @static
---@static
---@param ray UnityEngine.Ray
---@param distance number
---@param layerMask number
---@return UnityEngine.RaycastHit2D[]
function m.GetRayIntersectionAll(ray, distance, layerMask) end

---@overload fun(ray:UnityEngine.Ray, results:UnityEngine.RaycastHit2D[], distance:number): @static
---@overload fun(ray:UnityEngine.Ray, results:UnityEngine.RaycastHit2D[]): @static
---@static
---@param ray UnityEngine.Ray
---@param results UnityEngine.RaycastHit2D[]
---@param distance number
---@param layerMask number
---@return number
function m.GetRayIntersectionNonAlloc(ray, results, distance, layerMask) end

---@overload fun(point:UnityEngine.Vector2, layerMask:number): @static
---@overload fun(point:UnityEngine.Vector2): @static
---@overload fun(point:UnityEngine.Vector2, layerMask:number, minDepth:number, maxDepth:number): @static
---@overload fun(point:UnityEngine.Vector2, contactFilter:UnityEngine.ContactFilter2D, results:UnityEngine.Collider2D[]): @static
---@static
---@param point UnityEngine.Vector2
---@param layerMask number
---@param minDepth number
---@return UnityEngine.Collider2D
function m.OverlapPoint(point, layerMask, minDepth) end

---@overload fun(point:UnityEngine.Vector2, layerMask:number): @static
---@overload fun(point:UnityEngine.Vector2): @static
---@overload fun(point:UnityEngine.Vector2, layerMask:number, minDepth:number, maxDepth:number): @static
---@static
---@param point UnityEngine.Vector2
---@param layerMask number
---@param minDepth number
---@return UnityEngine.Collider2D[]
function m.OverlapPointAll(point, layerMask, minDepth) end

---@overload fun(point:UnityEngine.Vector2, results:UnityEngine.Collider2D[], layerMask:number): @static
---@overload fun(point:UnityEngine.Vector2, results:UnityEngine.Collider2D[]): @static
---@overload fun(point:UnityEngine.Vector2, results:UnityEngine.Collider2D[], layerMask:number, minDepth:number, maxDepth:number): @static
---@static
---@param point UnityEngine.Vector2
---@param results UnityEngine.Collider2D[]
---@param layerMask number
---@param minDepth number
---@return number
function m.OverlapPointNonAlloc(point, results, layerMask, minDepth) end

---@overload fun(point:UnityEngine.Vector2, radius:number, layerMask:number): @static
---@overload fun(point:UnityEngine.Vector2, radius:number): @static
---@overload fun(point:UnityEngine.Vector2, radius:number, layerMask:number, minDepth:number, maxDepth:number): @static
---@overload fun(point:UnityEngine.Vector2, radius:number, contactFilter:UnityEngine.ContactFilter2D, results:UnityEngine.Collider2D[]): @static
---@static
---@param point UnityEngine.Vector2
---@param radius number
---@param layerMask number
---@param minDepth number
---@return UnityEngine.Collider2D
function m.OverlapCircle(point, radius, layerMask, minDepth) end

---@overload fun(point:UnityEngine.Vector2, radius:number, layerMask:number): @static
---@overload fun(point:UnityEngine.Vector2, radius:number): @static
---@overload fun(point:UnityEngine.Vector2, radius:number, layerMask:number, minDepth:number, maxDepth:number): @static
---@static
---@param point UnityEngine.Vector2
---@param radius number
---@param layerMask number
---@param minDepth number
---@return UnityEngine.Collider2D[]
function m.OverlapCircleAll(point, radius, layerMask, minDepth) end

---@overload fun(point:UnityEngine.Vector2, radius:number, results:UnityEngine.Collider2D[], layerMask:number): @static
---@overload fun(point:UnityEngine.Vector2, radius:number, results:UnityEngine.Collider2D[]): @static
---@overload fun(point:UnityEngine.Vector2, radius:number, results:UnityEngine.Collider2D[], layerMask:number, minDepth:number, maxDepth:number): @static
---@static
---@param point UnityEngine.Vector2
---@param radius number
---@param results UnityEngine.Collider2D[]
---@param layerMask number
---@param minDepth number
---@return number
function m.OverlapCircleNonAlloc(point, radius, results, layerMask, minDepth) end

---@overload fun(point:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, layerMask:number): @static
---@overload fun(point:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number): @static
---@overload fun(point:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, layerMask:number, minDepth:number, maxDepth:number): @static
---@overload fun(point:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, contactFilter:UnityEngine.ContactFilter2D, results:UnityEngine.Collider2D[]): @static
---@static
---@param point UnityEngine.Vector2
---@param size UnityEngine.Vector2
---@param angle number
---@param layerMask number
---@param minDepth number
---@return UnityEngine.Collider2D
function m.OverlapBox(point, size, angle, layerMask, minDepth) end

---@overload fun(point:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, layerMask:number): @static
---@overload fun(point:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number): @static
---@overload fun(point:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, layerMask:number, minDepth:number, maxDepth:number): @static
---@static
---@param point UnityEngine.Vector2
---@param size UnityEngine.Vector2
---@param angle number
---@param layerMask number
---@param minDepth number
---@return UnityEngine.Collider2D[]
function m.OverlapBoxAll(point, size, angle, layerMask, minDepth) end

---@overload fun(point:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, results:UnityEngine.Collider2D[], layerMask:number): @static
---@overload fun(point:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, results:UnityEngine.Collider2D[]): @static
---@overload fun(point:UnityEngine.Vector2, size:UnityEngine.Vector2, angle:number, results:UnityEngine.Collider2D[], layerMask:number, minDepth:number, maxDepth:number): @static
---@static
---@param point UnityEngine.Vector2
---@param size UnityEngine.Vector2
---@param angle number
---@param results UnityEngine.Collider2D[]
---@param layerMask number
---@param minDepth number
---@return number
function m.OverlapBoxNonAlloc(point, size, angle, results, layerMask, minDepth) end

---@overload fun(pointA:UnityEngine.Vector2, pointB:UnityEngine.Vector2, layerMask:number): @static
---@overload fun(pointA:UnityEngine.Vector2, pointB:UnityEngine.Vector2): @static
---@overload fun(pointA:UnityEngine.Vector2, pointB:UnityEngine.Vector2, layerMask:number, minDepth:number, maxDepth:number): @static
---@overload fun(pointA:UnityEngine.Vector2, pointB:UnityEngine.Vector2, contactFilter:UnityEngine.ContactFilter2D, results:UnityEngine.Collider2D[]): @static
---@static
---@param pointA UnityEngine.Vector2
---@param pointB UnityEngine.Vector2
---@param layerMask number
---@param minDepth number
---@return UnityEngine.Collider2D
function m.OverlapArea(pointA, pointB, layerMask, minDepth) end

---@overload fun(pointA:UnityEngine.Vector2, pointB:UnityEngine.Vector2, layerMask:number): @static
---@overload fun(pointA:UnityEngine.Vector2, pointB:UnityEngine.Vector2): @static
---@overload fun(pointA:UnityEngine.Vector2, pointB:UnityEngine.Vector2, layerMask:number, minDepth:number, maxDepth:number): @static
---@static
---@param pointA UnityEngine.Vector2
---@param pointB UnityEngine.Vector2
---@param layerMask number
---@param minDepth number
---@return UnityEngine.Collider2D[]
function m.OverlapAreaAll(pointA, pointB, layerMask, minDepth) end

---@overload fun(pointA:UnityEngine.Vector2, pointB:UnityEngine.Vector2, results:UnityEngine.Collider2D[], layerMask:number): @static
---@overload fun(pointA:UnityEngine.Vector2, pointB:UnityEngine.Vector2, results:UnityEngine.Collider2D[]): @static
---@overload fun(pointA:UnityEngine.Vector2, pointB:UnityEngine.Vector2, results:UnityEngine.Collider2D[], layerMask:number, minDepth:number, maxDepth:number): @static
---@static
---@param pointA UnityEngine.Vector2
---@param pointB UnityEngine.Vector2
---@param results UnityEngine.Collider2D[]
---@param layerMask number
---@param minDepth number
---@return number
function m.OverlapAreaNonAlloc(pointA, pointB, results, layerMask, minDepth) end

---@overload fun(point:UnityEngine.Vector2, size:UnityEngine.Vector2, direction:UnityEngine.CapsuleDirection2D, angle:number, layerMask:number): @static
---@overload fun(point:UnityEngine.Vector2, size:UnityEngine.Vector2, direction:UnityEngine.CapsuleDirection2D, angle:number): @static
---@overload fun(point:UnityEngine.Vector2, size:UnityEngine.Vector2, direction:UnityEngine.CapsuleDirection2D, angle:number, layerMask:number, minDepth:number, maxDepth:number): @static
---@overload fun(point:UnityEngine.Vector2, size:UnityEngine.Vector2, direction:UnityEngine.CapsuleDirection2D, angle:number, contactFilter:UnityEngine.ContactFilter2D, results:UnityEngine.Collider2D[]): @static
---@static
---@param point UnityEngine.Vector2
---@param size UnityEngine.Vector2
---@param direction UnityEngine.CapsuleDirection2D
---@param angle number
---@param layerMask number
---@param minDepth number
---@return UnityEngine.Collider2D
function m.OverlapCapsule(point, size, direction, angle, layerMask, minDepth) end

---@overload fun(point:UnityEngine.Vector2, size:UnityEngine.Vector2, direction:UnityEngine.CapsuleDirection2D, angle:number, layerMask:number): @static
---@overload fun(point:UnityEngine.Vector2, size:UnityEngine.Vector2, direction:UnityEngine.CapsuleDirection2D, angle:number): @static
---@overload fun(point:UnityEngine.Vector2, size:UnityEngine.Vector2, direction:UnityEngine.CapsuleDirection2D, angle:number, layerMask:number, minDepth:number, maxDepth:number): @static
---@static
---@param point UnityEngine.Vector2
---@param size UnityEngine.Vector2
---@param direction UnityEngine.CapsuleDirection2D
---@param angle number
---@param layerMask number
---@param minDepth number
---@return UnityEngine.Collider2D[]
function m.OverlapCapsuleAll(point, size, direction, angle, layerMask, minDepth) end

---@overload fun(point:UnityEngine.Vector2, size:UnityEngine.Vector2, direction:UnityEngine.CapsuleDirection2D, angle:number, results:UnityEngine.Collider2D[], layerMask:number): @static
---@overload fun(point:UnityEngine.Vector2, size:UnityEngine.Vector2, direction:UnityEngine.CapsuleDirection2D, angle:number, results:UnityEngine.Collider2D[]): @static
---@overload fun(point:UnityEngine.Vector2, size:UnityEngine.Vector2, direction:UnityEngine.CapsuleDirection2D, angle:number, results:UnityEngine.Collider2D[], layerMask:number, minDepth:number, maxDepth:number): @static
---@static
---@param point UnityEngine.Vector2
---@param size UnityEngine.Vector2
---@param direction UnityEngine.CapsuleDirection2D
---@param angle number
---@param results UnityEngine.Collider2D[]
---@param layerMask number
---@param minDepth number
---@return number
function m.OverlapCapsuleNonAlloc(point, size, direction, angle, results, layerMask, minDepth) end

---@static
---@param collider UnityEngine.Collider2D
---@param contactFilter UnityEngine.ContactFilter2D
---@param results UnityEngine.Collider2D[]
---@return number
function m.OverlapCollider(collider, contactFilter, results) end

---@overload fun(collider:UnityEngine.Collider2D, contactFilter:UnityEngine.ContactFilter2D, contacts:UnityEngine.ContactPoint2D[]): @static
---@overload fun(collider:UnityEngine.Collider2D, colliders:UnityEngine.Collider2D[]): @static
---@overload fun(collider:UnityEngine.Collider2D, contactFilter:UnityEngine.ContactFilter2D, colliders:UnityEngine.Collider2D[]): @static
---@overload fun(rigidbody:UnityEngine.Rigidbody2D, contacts:UnityEngine.ContactPoint2D[]): @static
---@overload fun(rigidbody:UnityEngine.Rigidbody2D, contactFilter:UnityEngine.ContactFilter2D, contacts:UnityEngine.ContactPoint2D[]): @static
---@overload fun(rigidbody:UnityEngine.Rigidbody2D, colliders:UnityEngine.Collider2D[]): @static
---@overload fun(rigidbody:UnityEngine.Rigidbody2D, contactFilter:UnityEngine.ContactFilter2D, colliders:UnityEngine.Collider2D[]): @static
---@static
---@param collider UnityEngine.Collider2D
---@param contacts UnityEngine.ContactPoint2D[]
---@return number
function m.GetContacts(collider, contacts) end

UnityEngine.Physics2D = m
return m
