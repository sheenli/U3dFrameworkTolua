---@class System.NumberFormatter : System.Object
---@field public CurrentCulture System.Globalization.CultureInfo
local m = {}

---@overload fun(format:string, value:number, fp:System.IFormatProvider): @static
---@overload fun(format:string, value:number, fp:System.IFormatProvider): @static
---@overload fun(format:string, value:number, fp:System.IFormatProvider): @static
---@overload fun(format:string, value:number, fp:System.IFormatProvider): @static
---@overload fun(format:string, value:number, fp:System.IFormatProvider): @static
---@overload fun(format:string, value:number, fp:System.IFormatProvider): @static
---@overload fun(format:string, value:number, fp:System.IFormatProvider): @static
---@overload fun(format:string, value:number, fp:System.IFormatProvider): @static
---@overload fun(format:string, value:number, fp:System.IFormatProvider): @static
---@overload fun(format:string, value:System.Decimal, fp:System.IFormatProvider): @static
---@overload fun(value:number, fp:System.IFormatProvider): @static
---@overload fun(value:number, fp:System.IFormatProvider): @static
---@overload fun(value:number, fp:System.IFormatProvider): @static
---@overload fun(value:number, fp:System.IFormatProvider): @static
---@overload fun(value:number, fp:System.IFormatProvider): @static
---@overload fun(value:number, fp:System.IFormatProvider): @static
---@static
---@param format string
---@param value number
---@param fp System.IFormatProvider
---@return string
function m.NumberToString(format, value, fp) end

---@param precision number
---@param nfi System.Globalization.NumberFormatInfo
---@return string
function m:FormatCurrency(precision, nfi) end

---@param precision number
---@param nfi System.Globalization.NumberFormatInfo
---@return string
function m:FormatFixedPoint(precision, nfi) end

---@param precision number
---@param nfi System.Globalization.NumberFormatInfo
---@return string
function m:FormatNumber(precision, nfi) end

---@param precision number
---@param nfi System.Globalization.NumberFormatInfo
---@return string
function m:FormatPercent(precision, nfi) end

---@param precision number
---@param nfi System.Globalization.NumberFormatInfo
---@return string
function m:FormatExponential(precision, nfi) end

---@param format string
---@param nfi System.Globalization.NumberFormatInfo
---@return string
function m:FormatCustom(format, nfi) end

System.NumberFormatter = m
return m
