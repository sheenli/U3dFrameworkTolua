---@class System.ConsoleColor : System.Enum
---@field public Black System.ConsoleColor @static
---@field public DarkBlue System.ConsoleColor @static
---@field public DarkGreen System.ConsoleColor @static
---@field public DarkCyan System.ConsoleColor @static
---@field public DarkRed System.ConsoleColor @static
---@field public DarkMagenta System.ConsoleColor @static
---@field public DarkYellow System.ConsoleColor @static
---@field public Gray System.ConsoleColor @static
---@field public DarkGray System.ConsoleColor @static
---@field public Blue System.ConsoleColor @static
---@field public Green System.ConsoleColor @static
---@field public Cyan System.ConsoleColor @static
---@field public Red System.ConsoleColor @static
---@field public Magenta System.ConsoleColor @static
---@field public Yellow System.ConsoleColor @static
---@field public White System.ConsoleColor @static
---@field public value__ number
local m = {}

System.ConsoleColor = m
return m
