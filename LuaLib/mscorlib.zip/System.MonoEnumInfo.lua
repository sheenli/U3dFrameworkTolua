---@class System.MonoEnumInfo : System.ValueType
local m = {}

System.MonoEnumInfo = m
return m
