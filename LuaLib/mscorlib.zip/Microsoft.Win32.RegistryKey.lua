---@class Microsoft.Win32.RegistryKey : System.MarshalByRefObject
---@field public Name string
---@field public SubKeyCount number
---@field public ValueCount number
local m = {}

function m:Flush() end

function m:Close() end

---@overload fun(name:string, value:any, valueKind:Microsoft.Win32.RegistryValueKind)
---@param name string
---@param value any
function m:SetValue(name, value) end

---@overload fun(name:string, writable:boolean):
---@overload fun(name:string, permissionCheck:Microsoft.Win32.RegistryKeyPermissionCheck):
---@overload fun(name:string, permissionCheck:Microsoft.Win32.RegistryKeyPermissionCheck, rights:System.Security.AccessControl.RegistryRights):
---@param name string
---@return Microsoft.Win32.RegistryKey
function m:OpenSubKey(name) end

---@overload fun(name:string, defaultValue:any):
---@overload fun(name:string, defaultValue:any, options:Microsoft.Win32.RegistryValueOptions):
---@param name string
---@return any
function m:GetValue(name) end

---@param name string
---@return Microsoft.Win32.RegistryValueKind
function m:GetValueKind(name) end

---@overload fun(subkey:string, permissionCheck:Microsoft.Win32.RegistryKeyPermissionCheck):
---@overload fun(subkey:string, permissionCheck:Microsoft.Win32.RegistryKeyPermissionCheck, registrySecurity:System.Security.AccessControl.RegistrySecurity):
---@param subkey string
---@return Microsoft.Win32.RegistryKey
function m:CreateSubKey(subkey) end

---@overload fun(subkey:string, throwOnMissingSubKey:boolean)
---@param subkey string
function m:DeleteSubKey(subkey) end

---@param subkey string
function m:DeleteSubKeyTree(subkey) end

---@overload fun(name:string, throwOnMissingValue:boolean)
---@param name string
function m:DeleteValue(name) end

---@overload fun(includeSections:System.Security.AccessControl.AccessControlSections):
---@return System.Security.AccessControl.RegistrySecurity
function m:GetAccessControl() end

---@return string[]
function m:GetSubKeyNames() end

---@return string[]
function m:GetValueNames() end

---@static
---@param hKey Microsoft.Win32.RegistryHive
---@param machineName string
---@return Microsoft.Win32.RegistryKey
function m.OpenRemoteBaseKey(hKey, machineName) end

---@param registrySecurity System.Security.AccessControl.RegistrySecurity
function m:SetAccessControl(registrySecurity) end

---@virtual
---@return string
function m:ToString() end

Microsoft.Win32.RegistryKey = m
return m
