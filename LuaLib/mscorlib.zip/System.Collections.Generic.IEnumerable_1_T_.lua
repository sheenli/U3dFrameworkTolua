---@class System.Collections.Generic.IEnumerable_1_T_ : table
local m = {}

---@abstract
---@return System.Collections.Generic.IEnumerator_1_T_
function m:GetEnumerator() end

System.Collections.Generic.IEnumerable_1_T_ = m
return m
