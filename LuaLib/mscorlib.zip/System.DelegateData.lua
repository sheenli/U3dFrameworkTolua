---@class System.DelegateData : System.Object
---@field public target_type System.Type
---@field public method_name string
local m = {}

System.DelegateData = m
return m
