---@class System.MidpointRounding : System.Enum
---@field public ToEven System.MidpointRounding @static
---@field public AwayFromZero System.MidpointRounding @static
---@field public value__ number
local m = {}

System.MidpointRounding = m
return m
