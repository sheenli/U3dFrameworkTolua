---@class System.Environment.SpecialFolder : System.Enum
---@field public MyDocuments System.Environment.SpecialFolder @static
---@field public Desktop System.Environment.SpecialFolder @static
---@field public MyComputer System.Environment.SpecialFolder @static
---@field public Programs System.Environment.SpecialFolder @static
---@field public Personal System.Environment.SpecialFolder @static
---@field public Favorites System.Environment.SpecialFolder @static
---@field public Startup System.Environment.SpecialFolder @static
---@field public Recent System.Environment.SpecialFolder @static
---@field public SendTo System.Environment.SpecialFolder @static
---@field public StartMenu System.Environment.SpecialFolder @static
---@field public MyMusic System.Environment.SpecialFolder @static
---@field public DesktopDirectory System.Environment.SpecialFolder @static
---@field public Templates System.Environment.SpecialFolder @static
---@field public ApplicationData System.Environment.SpecialFolder @static
---@field public LocalApplicationData System.Environment.SpecialFolder @static
---@field public InternetCache System.Environment.SpecialFolder @static
---@field public Cookies System.Environment.SpecialFolder @static
---@field public History System.Environment.SpecialFolder @static
---@field public CommonApplicationData System.Environment.SpecialFolder @static
---@field public System System.Environment.SpecialFolder @static
---@field public ProgramFiles System.Environment.SpecialFolder @static
---@field public MyPictures System.Environment.SpecialFolder @static
---@field public CommonProgramFiles System.Environment.SpecialFolder @static
---@field public value__ number
local m = {}

System.Environment.SpecialFolder = m
return m
