---@class System.Diagnostics.DebuggerDisplayAttribute : System.Attribute
---@field public Value string
---@field public Target System.Type
---@field public TargetTypeName string
---@field public Type string
---@field public Name string
local m = {}

System.Diagnostics.DebuggerDisplayAttribute = m
return m
