---@class System.Runtime.InteropServices.GuidAttribute : System.Attribute
---@field public Value string
local m = {}

System.Runtime.InteropServices.GuidAttribute = m
return m
