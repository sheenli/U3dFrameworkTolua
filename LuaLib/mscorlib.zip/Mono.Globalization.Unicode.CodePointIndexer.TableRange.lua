---@class Mono.Globalization.Unicode.CodePointIndexer.TableRange : System.ValueType
---@field public Start number
---@field public End number
---@field public Count number
---@field public IndexStart number
---@field public IndexEnd number
local m = {}

Mono.Globalization.Unicode.CodePointIndexer.TableRange = m
return m
