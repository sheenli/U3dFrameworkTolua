---@class System.MTAThreadAttribute : System.Attribute
local m = {}

System.MTAThreadAttribute = m
return m
