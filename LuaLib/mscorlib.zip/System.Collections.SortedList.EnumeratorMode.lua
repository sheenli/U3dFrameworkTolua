---@class System.Collections.SortedList.EnumeratorMode : System.Enum
---@field public KEY_MODE System.Collections.SortedList.EnumeratorMode @static
---@field public VALUE_MODE System.Collections.SortedList.EnumeratorMode @static
---@field public ENTRY_MODE System.Collections.SortedList.EnumeratorMode @static
---@field public value__ number
local m = {}

System.Collections.SortedList.EnumeratorMode = m
return m
