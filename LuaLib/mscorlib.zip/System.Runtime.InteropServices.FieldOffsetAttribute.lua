---@class System.Runtime.InteropServices.FieldOffsetAttribute : System.Attribute
---@field public Value number
local m = {}

System.Runtime.InteropServices.FieldOffsetAttribute = m
return m
