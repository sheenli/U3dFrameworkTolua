---@class Microsoft.Win32.RegistryHive : System.Enum
---@field public ClassesRoot Microsoft.Win32.RegistryHive @static
---@field public CurrentConfig Microsoft.Win32.RegistryHive @static
---@field public CurrentUser Microsoft.Win32.RegistryHive @static
---@field public DynData Microsoft.Win32.RegistryHive @static
---@field public LocalMachine Microsoft.Win32.RegistryHive @static
---@field public PerformanceData Microsoft.Win32.RegistryHive @static
---@field public Users Microsoft.Win32.RegistryHive @static
---@field public value__ number
local m = {}

Microsoft.Win32.RegistryHive = m
return m
