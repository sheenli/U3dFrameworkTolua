---@class System.Type : System.Reflection.MemberInfo
---@field public Delimiter number @static
---@field public EmptyTypes System.Type[] @static
---@field public FilterAttribute fun(m:System.Reflection.MemberInfo, filterCriteria:any): @static
---@field public FilterName fun(m:System.Reflection.MemberInfo, filterCriteria:any): @static
---@field public FilterNameIgnoreCase fun(m:System.Reflection.MemberInfo, filterCriteria:any): @static
---@field public Missing any @static
---@field public DefaultBinder System.Reflection.Binder @static
---@field public Assembly System.Reflection.Assembly
---@field public AssemblyQualifiedName string
---@field public Attributes System.Reflection.TypeAttributes
---@field public BaseType System.Type
---@field public DeclaringType System.Type
---@field public FullName string
---@field public GUID System.Guid
---@field public HasElementType boolean
---@field public IsAbstract boolean
---@field public IsAnsiClass boolean
---@field public IsArray boolean
---@field public IsAutoClass boolean
---@field public IsAutoLayout boolean
---@field public IsByRef boolean
---@field public IsClass boolean
---@field public IsCOMObject boolean
---@field public IsContextful boolean
---@field public IsEnum boolean
---@field public IsExplicitLayout boolean
---@field public IsImport boolean
---@field public IsInterface boolean
---@field public IsLayoutSequential boolean
---@field public IsMarshalByRef boolean
---@field public IsNestedAssembly boolean
---@field public IsNestedFamANDAssem boolean
---@field public IsNestedFamily boolean
---@field public IsNestedFamORAssem boolean
---@field public IsNestedPrivate boolean
---@field public IsNestedPublic boolean
---@field public IsNotPublic boolean
---@field public IsPointer boolean
---@field public IsPrimitive boolean
---@field public IsPublic boolean
---@field public IsSealed boolean
---@field public IsSerializable boolean
---@field public IsSpecialName boolean
---@field public IsUnicodeClass boolean
---@field public IsValueType boolean
---@field public MemberType System.Reflection.MemberTypes
---@field public Module System.Reflection.Module
---@field public Namespace string
---@field public ReflectedType System.Type
---@field public TypeHandle System.RuntimeTypeHandle
---@field public TypeInitializer System.Reflection.ConstructorInfo
---@field public UnderlyingSystemType System.Type
---@field public ContainsGenericParameters boolean
---@field public IsGenericTypeDefinition boolean
---@field public IsGenericType boolean
---@field public IsGenericParameter boolean
---@field public IsNested boolean
---@field public IsVisible boolean
---@field public GenericParameterPosition number
---@field public GenericParameterAttributes System.Reflection.GenericParameterAttributes
---@field public DeclaringMethod System.Reflection.MethodBase
---@field public StructLayoutAttribute System.Runtime.InteropServices.StructLayoutAttribute
local m = {}

---@overload fun(o:System.Type): @virtual
---@virtual
---@param o any
---@return boolean
function m:Equals(o) end

---@overload fun(typeName:string, throwOnError:boolean): @static
---@overload fun(typeName:string, throwOnError:boolean, ignoreCase:boolean): @static
---@overload fun(): @virtual
---@static
---@param typeName string
---@return System.Type
function m.GetType(typeName) end

---@static
---@param args any[]
---@return System.Type[]
function m.GetTypeArray(args) end

---@static
---@param type System.Type
---@return System.TypeCode
function m.GetTypeCode(type) end

---@overload fun(clsid:System.Guid, throwOnError:boolean): @static
---@overload fun(clsid:System.Guid, server:string): @static
---@overload fun(clsid:System.Guid, server:string, throwOnError:boolean): @static
---@static
---@param clsid System.Guid
---@return System.Type
function m.GetTypeFromCLSID(clsid) end

---@static
---@param handle System.RuntimeTypeHandle
---@return System.Type
function m.GetTypeFromHandle(handle) end

---@overload fun(progID:string, throwOnError:boolean): @static
---@overload fun(progID:string, server:string): @static
---@overload fun(progID:string, server:string, throwOnError:boolean): @static
---@static
---@param progID string
---@return System.Type
function m.GetTypeFromProgID(progID) end

---@static
---@param o any
---@return System.RuntimeTypeHandle
function m.GetTypeHandle(o) end

---@virtual
---@param c System.Type
---@return boolean
function m:IsSubclassOf(c) end

---@virtual
---@param filter fun(m:System.Type, filterCriteria:any):
---@param filterCriteria any
---@return System.Type[]
function m:FindInterfaces(filter, filterCriteria) end

---@overload fun(name:string, ignoreCase:boolean): @abstract
---@virtual
---@param name string
---@return System.Type
function m:GetInterface(name) end

---@virtual
---@param interfaceType System.Type
---@return System.Reflection.InterfaceMapping
function m:GetInterfaceMap(interfaceType) end

---@abstract
---@return System.Type[]
function m:GetInterfaces() end

---@virtual
---@param c System.Type
---@return boolean
function m:IsAssignableFrom(c) end

---@virtual
---@param o any
---@return boolean
function m:IsInstanceOfType(o) end

---@virtual
---@return number
function m:GetArrayRank() end

---@abstract
---@return System.Type
function m:GetElementType() end

---@overload fun(name:string, bindingAttr:System.Reflection.BindingFlags): @abstract
---@virtual
---@param name string
---@return System.Reflection.EventInfo
function m:GetEvent(name) end

---@overload fun(bindingAttr:System.Reflection.BindingFlags): @abstract
---@virtual
---@return System.Reflection.EventInfo[]
function m:GetEvents() end

---@overload fun(name:string, bindingAttr:System.Reflection.BindingFlags): @abstract
---@virtual
---@param name string
---@return System.Reflection.FieldInfo
function m:GetField(name) end

---@overload fun(bindingAttr:System.Reflection.BindingFlags): @abstract
---@virtual
---@return System.Reflection.FieldInfo[]
function m:GetFields() end

---@virtual
---@return number
function m:GetHashCode() end

---@overload fun(name:string, bindingAttr:System.Reflection.BindingFlags): @virtual
---@overload fun(name:string, type:System.Reflection.MemberTypes, bindingAttr:System.Reflection.BindingFlags): @virtual
---@virtual
---@param name string
---@return System.Reflection.MemberInfo[]
function m:GetMember(name) end

---@overload fun(bindingAttr:System.Reflection.BindingFlags): @abstract
---@virtual
---@return System.Reflection.MemberInfo[]
function m:GetMembers() end

---@overload fun(name:string, bindingAttr:System.Reflection.BindingFlags): @virtual
---@overload fun(name:string, types:System.Type[]): @virtual
---@overload fun(name:string, types:System.Type[], modifiers:System.Reflection.ParameterModifier[]): @virtual
---@overload fun(name:string, bindingAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, types:System.Type[], modifiers:System.Reflection.ParameterModifier[]): @virtual
---@overload fun(name:string, bindingAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, callConvention:System.Reflection.CallingConventions, types:System.Type[], modifiers:System.Reflection.ParameterModifier[]): @virtual
---@virtual
---@param name string
---@return System.Reflection.MethodInfo
function m:GetMethod(name) end

---@overload fun(bindingAttr:System.Reflection.BindingFlags): @abstract
---@virtual
---@return System.Reflection.MethodInfo[]
function m:GetMethods() end

---@overload fun(name:string, bindingAttr:System.Reflection.BindingFlags): @abstract
---@virtual
---@param name string
---@return System.Type
function m:GetNestedType(name) end

---@overload fun(bindingAttr:System.Reflection.BindingFlags): @abstract
---@virtual
---@return System.Type[]
function m:GetNestedTypes() end

---@overload fun(bindingAttr:System.Reflection.BindingFlags): @abstract
---@virtual
---@return System.Reflection.PropertyInfo[]
function m:GetProperties() end

---@overload fun(name:string, bindingAttr:System.Reflection.BindingFlags): @virtual
---@overload fun(name:string, returnType:System.Type): @virtual
---@overload fun(name:string, types:System.Type[]): @virtual
---@overload fun(name:string, returnType:System.Type, types:System.Type[]): @virtual
---@overload fun(name:string, returnType:System.Type, types:System.Type[], modifiers:System.Reflection.ParameterModifier[]): @virtual
---@overload fun(name:string, bindingAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, returnType:System.Type, types:System.Type[], modifiers:System.Reflection.ParameterModifier[]): @virtual
---@virtual
---@param name string
---@return System.Reflection.PropertyInfo
function m:GetProperty(name) end

---@overload fun(bindingAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, types:System.Type[], modifiers:System.Reflection.ParameterModifier[]): @virtual
---@overload fun(bindingAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, callConvention:System.Reflection.CallingConventions, types:System.Type[], modifiers:System.Reflection.ParameterModifier[]): @virtual
---@virtual
---@param types System.Type[]
---@return System.Reflection.ConstructorInfo
function m:GetConstructor(types) end

---@overload fun(bindingAttr:System.Reflection.BindingFlags): @abstract
---@virtual
---@return System.Reflection.ConstructorInfo[]
function m:GetConstructors() end

---@virtual
---@return System.Reflection.MemberInfo[]
function m:GetDefaultMembers() end

---@virtual
---@param memberType System.Reflection.MemberTypes
---@param bindingAttr System.Reflection.BindingFlags
---@param filter fun(m:System.Reflection.MemberInfo, filterCriteria:any):
---@param filterCriteria any
---@return System.Reflection.MemberInfo[]
function m:FindMembers(memberType, bindingAttr, filter, filterCriteria) end

---@overload fun(name:string, invokeAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, target:any, args:any[], culture:System.Globalization.CultureInfo): @virtual
---@overload fun(name:string, invokeAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, target:any, args:any[], modifiers:System.Reflection.ParameterModifier[], culture:System.Globalization.CultureInfo, namedParameters:string[]): @abstract
---@virtual
---@param name string
---@param invokeAttr System.Reflection.BindingFlags
---@param binder System.Reflection.Binder
---@param target any
---@param args any[]
---@return any
function m:InvokeMember(name, invokeAttr, binder, target, args) end

---@virtual
---@return string
function m:ToString() end

---@virtual
---@return System.Type[]
function m:GetGenericArguments() end

---@virtual
---@return System.Type
function m:GetGenericTypeDefinition() end

---@overload fun(): @virtual
---@virtual
---@param ... System.Type|System.Type[]
---@return System.Type
function m:MakeGenericType(...) end

---@virtual
---@return System.Type[]
function m:GetGenericParameterConstraints() end

---@overload fun(rank:number): @virtual
---@virtual
---@return System.Type
function m:MakeArrayType() end

---@virtual
---@return System.Type
function m:MakeByRefType() end

---@virtual
---@return System.Type
function m:MakePointerType() end

---@static
---@param typeName string
---@param throwIfNotFound boolean
---@param ignoreCase boolean
---@return System.Type
function m.ReflectionOnlyGetType(typeName, throwIfNotFound, ignoreCase) end

System.Type = m
return m
