---@class System.Collections.Hashtable.EnumeratorMode : System.Enum
---@field public KEY_MODE System.Collections.Hashtable.EnumeratorMode @static
---@field public VALUE_MODE System.Collections.Hashtable.EnumeratorMode @static
---@field public ENTRY_MODE System.Collections.Hashtable.EnumeratorMode @static
---@field public value__ number
local m = {}

System.Collections.Hashtable.EnumeratorMode = m
return m
