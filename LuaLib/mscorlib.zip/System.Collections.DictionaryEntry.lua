---@class System.Collections.DictionaryEntry : System.ValueType
---@field public Key any
---@field public Value any
local m = {}

System.Collections.DictionaryEntry = m
return m
