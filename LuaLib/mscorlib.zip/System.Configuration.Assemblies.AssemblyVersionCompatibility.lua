---@class System.Configuration.Assemblies.AssemblyVersionCompatibility : System.Enum
---@field public SameMachine System.Configuration.Assemblies.AssemblyVersionCompatibility @static
---@field public SameProcess System.Configuration.Assemblies.AssemblyVersionCompatibility @static
---@field public SameDomain System.Configuration.Assemblies.AssemblyVersionCompatibility @static
---@field public value__ number
local m = {}

System.Configuration.Assemblies.AssemblyVersionCompatibility = m
return m
