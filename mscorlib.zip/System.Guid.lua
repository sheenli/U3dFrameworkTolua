---@class System.Guid : System.ValueType
---@field public Empty System.Guid @static
local m = {}

---@overload fun(value:System.Guid):number @virtual
---@virtual
---@param value any
---@return number
function m:CompareTo(value) end

---@overload fun(g:System.Guid):boolean @virtual
---@virtual
---@param o any
---@return boolean
function m:Equals(o) end

---@virtual
---@return number
function m:GetHashCode() end

---@static
---@return System.Guid
function m.NewGuid() end

---@return string
function m:ToByteArray() end

---@overload fun(format:string):string
---@overload fun(format:string, provider:System.IFormatProvider):string @virtual
---@virtual
---@return string
function m:ToString() end

---@static
---@param a System.Guid
---@param b System.Guid
---@return boolean
function m.op_Equality(a, b) end

---@static
---@param a System.Guid
---@param b System.Guid
---@return boolean
function m.op_Inequality(a, b) end

System.Guid = m
return m
