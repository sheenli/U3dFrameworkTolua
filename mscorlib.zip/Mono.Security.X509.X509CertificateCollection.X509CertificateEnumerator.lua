---@class Mono.Security.X509.X509CertificateCollection.X509CertificateEnumerator : System.Object
---@field public Current Mono.Security.X509.X509Certificate
local m = {}

---@virtual
---@return boolean
function m:MoveNext() end

---@virtual
function m:Reset() end

Mono.Security.X509.X509CertificateCollection.X509CertificateEnumerator = m
return m
