---@class System.AppDomain.Loader : System.Object
local m = {}

function m:Load() end

System.AppDomain.Loader = m
return m
