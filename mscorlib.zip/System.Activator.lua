---@class System.Activator : System.Object
local m = {}

---@overload fun(assemblyName:string, typeName:string, hashValue:string, hashAlgorithm:System.Configuration.Assemblies.AssemblyHashAlgorithm):System.Runtime.Remoting.ObjectHandle @static
---@static
---@param assemblyName string
---@param typeName string
---@return System.Runtime.Remoting.ObjectHandle
function m.CreateComInstanceFrom(assemblyName, typeName) end

---@overload fun(assemblyFile:string, typeName:string, activationAttributes:any[]):System.Runtime.Remoting.ObjectHandle @static
---@overload fun(assemblyFile:string, typeName:string, ignoreCase:boolean, bindingAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, args:any[], culture:System.Globalization.CultureInfo, activationAttributes:any[], securityInfo:System.Security.Policy.Evidence):System.Runtime.Remoting.ObjectHandle @static
---@overload fun(domain:System.AppDomain, assemblyFile:string, typeName:string):System.Runtime.Remoting.ObjectHandle @static
---@overload fun(domain:System.AppDomain, assemblyFile:string, typeName:string, ignoreCase:boolean, bindingAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, args:any[], culture:System.Globalization.CultureInfo, activationAttributes:any[], securityAttributes:System.Security.Policy.Evidence):System.Runtime.Remoting.ObjectHandle @static
---@static
---@param assemblyFile string
---@param typeName string
---@return System.Runtime.Remoting.ObjectHandle
function m.CreateInstanceFrom(assemblyFile, typeName) end

---@overload fun(assemblyName:string, typeName:string, activationAttributes:any[]):System.Runtime.Remoting.ObjectHandle @static
---@overload fun(assemblyName:string, typeName:string, ignoreCase:boolean, bindingAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, args:any[], culture:System.Globalization.CultureInfo, activationAttributes:any[], securityInfo:System.Security.Policy.Evidence):System.Runtime.Remoting.ObjectHandle @static
---@overload fun(activationContext:System.ActivationContext):System.Runtime.Remoting.ObjectHandle @static
---@overload fun(activationContext:System.ActivationContext, activationCustomData:string[]):System.Runtime.Remoting.ObjectHandle @static
---@overload fun(domain:System.AppDomain, assemblyName:string, typeName:string):System.Runtime.Remoting.ObjectHandle @static
---@overload fun(domain:System.AppDomain, assemblyName:string, typeName:string, ignoreCase:boolean, bindingAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, args:any[], culture:System.Globalization.CultureInfo, activationAttributes:any[], securityAttributes:System.Security.Policy.Evidence):System.Runtime.Remoting.ObjectHandle @static
---@overload fun():any @static
---@overload fun(type:System.Type):any @static
---@overload fun(type:System.Type, args:any[]|any):any @static
---@overload fun(type:System.Type):any @static
---@overload fun(type:System.Type, args:any[], activationAttributes:any[]):any @static
---@overload fun(type:System.Type, bindingAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, args:any[], culture:System.Globalization.CultureInfo):any @static
---@overload fun(type:System.Type, bindingAttr:System.Reflection.BindingFlags, binder:System.Reflection.Binder, args:any[], culture:System.Globalization.CultureInfo, activationAttributes:any[]):any @static
---@overload fun(type:System.Type, nonPublic:boolean):any @static
---@static
---@param assemblyName string
---@param typeName string
---@return System.Runtime.Remoting.ObjectHandle
function m.CreateInstance(assemblyName, typeName) end

---@overload fun(type:System.Type, url:string, state:any):any @static
---@static
---@param type System.Type
---@param url string
---@return any
function m.GetObject(type, url) end

System.Activator = m
return m
