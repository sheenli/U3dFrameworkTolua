---@class System.MonoExtensionAttribute : System.MonoTODOAttribute
local m = {}

System.MonoExtensionAttribute = m
return m
