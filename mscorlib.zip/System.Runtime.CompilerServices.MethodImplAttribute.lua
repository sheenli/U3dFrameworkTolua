---@class System.Runtime.CompilerServices.MethodImplAttribute : System.Attribute
---@field public MethodCodeType System.Runtime.CompilerServices.MethodCodeType
---@field public Value System.Runtime.CompilerServices.MethodImplOptions
local m = {}

System.Runtime.CompilerServices.MethodImplAttribute = m
return m
