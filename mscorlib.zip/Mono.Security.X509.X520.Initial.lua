---@class Mono.Security.X509.X520.Initial : Mono.Security.X509.X520.AttributeTypeAndValue
local m = {}

Mono.Security.X509.X520.Initial = m
return m
