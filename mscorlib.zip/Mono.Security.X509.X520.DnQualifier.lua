---@class Mono.Security.X509.X520.DnQualifier : Mono.Security.X509.X520.AttributeTypeAndValue
local m = {}

Mono.Security.X509.X520.DnQualifier = m
return m
