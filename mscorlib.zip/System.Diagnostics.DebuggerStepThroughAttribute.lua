---@class System.Diagnostics.DebuggerStepThroughAttribute : System.Attribute
local m = {}

System.Diagnostics.DebuggerStepThroughAttribute = m
return m
