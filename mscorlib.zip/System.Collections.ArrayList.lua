---@class System.Collections.ArrayList : System.Object
---@field public Item any
---@field public Count number
---@field public Capacity number
---@field public IsFixedSize boolean
---@field public IsReadOnly boolean
---@field public IsSynchronized boolean
---@field public SyncRoot any
local m = {}

---@virtual
---@param value any
---@return number
function m:Add(value) end

---@virtual
function m:Clear() end

---@virtual
---@param item any
---@return boolean
function m:Contains(item) end

---@overload fun(value:any, startIndex:number):number @virtual
---@overload fun(value:any, startIndex:number, count:number):number @virtual
---@virtual
---@param value any
---@return number
function m:IndexOf(value) end

---@overload fun(value:any, startIndex:number):number @virtual
---@overload fun(value:any, startIndex:number, count:number):number @virtual
---@virtual
---@param value any
---@return number
function m:LastIndexOf(value) end

---@virtual
---@param index number
---@param value any
function m:Insert(index, value) end

---@virtual
---@param index number
---@param c System.Collections.ICollection
function m:InsertRange(index, c) end

---@virtual
---@param obj any
function m:Remove(obj) end

---@virtual
---@param index number
function m:RemoveAt(index) end

---@virtual
---@param index number
---@param count number
function m:RemoveRange(index, count) end

---@overload fun(index:number, count:number) @virtual
---@virtual
function m:Reverse() end

---@overload fun(array:System.Array, arrayIndex:number) @virtual
---@overload fun(index:number, array:System.Array, arrayIndex:number, count:number) @virtual
---@virtual
---@param array System.Array
function m:CopyTo(array) end

---@overload fun(index:number, count:number):System.Collections.IEnumerator @virtual
---@virtual
---@return System.Collections.IEnumerator
function m:GetEnumerator() end

---@virtual
---@param c System.Collections.ICollection
function m:AddRange(c) end

---@overload fun(value:any, comparer:System.Collections.IComparer):number @virtual
---@overload fun(index:number, count:number, value:any, comparer:System.Collections.IComparer):number @virtual
---@virtual
---@param value any
---@return number
function m:BinarySearch(value) end

---@virtual
---@param index number
---@param count number
---@return System.Collections.ArrayList
function m:GetRange(index, count) end

---@virtual
---@param index number
---@param c System.Collections.ICollection
function m:SetRange(index, c) end

---@virtual
function m:TrimToSize() end

---@overload fun(comparer:System.Collections.IComparer) @virtual
---@overload fun(index:number, count:number, comparer:System.Collections.IComparer) @virtual
---@virtual
function m:Sort() end

---@overload fun(type:System.Type):System.Array @virtual
---@virtual
---@return any[]
function m:ToArray() end

---@virtual
---@return any
function m:Clone() end

---@static
---@param list System.Collections.IList
---@return System.Collections.ArrayList
function m.Adapter(list) end

---@overload fun(list:System.Collections.IList):System.Collections.IList @static
---@static
---@param list System.Collections.ArrayList
---@return System.Collections.ArrayList
function m.Synchronized(list) end

---@overload fun(list:System.Collections.IList):System.Collections.IList @static
---@static
---@param list System.Collections.ArrayList
---@return System.Collections.ArrayList
function m.ReadOnly(list) end

---@overload fun(list:System.Collections.IList):System.Collections.IList @static
---@static
---@param list System.Collections.ArrayList
---@return System.Collections.ArrayList
function m.FixedSize(list) end

---@static
---@param value any
---@param count number
---@return System.Collections.ArrayList
function m.Repeat(value, count) end

System.Collections.ArrayList = m
return m
