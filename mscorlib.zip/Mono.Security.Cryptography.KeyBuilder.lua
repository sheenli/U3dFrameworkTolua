---@class Mono.Security.Cryptography.KeyBuilder : System.Object
local m = {}

---@static
---@param size number
---@return string
function m.Key(size) end

---@static
---@param size number
---@return string
function m.IV(size) end

Mono.Security.Cryptography.KeyBuilder = m
return m
