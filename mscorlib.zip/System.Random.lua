---@class System.Random : System.Object
local m = {}

---@overload fun(maxValue:number):number @virtual
---@overload fun(minValue:number, maxValue:number):number @virtual
---@virtual
---@return number
function m:Next() end

---@virtual
---@param buffer string
function m:NextBytes(buffer) end

---@virtual
---@return number
function m:NextDouble() end

System.Random = m
return m
