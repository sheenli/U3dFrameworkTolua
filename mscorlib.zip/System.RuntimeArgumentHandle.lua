---@class System.RuntimeArgumentHandle : System.ValueType
local m = {}

System.RuntimeArgumentHandle = m
return m
