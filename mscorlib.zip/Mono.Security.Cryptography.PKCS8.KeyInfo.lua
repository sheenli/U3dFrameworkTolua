---@class Mono.Security.Cryptography.PKCS8.KeyInfo : System.Enum
---@field public PrivateKey Mono.Security.Cryptography.PKCS8.KeyInfo @static
---@field public EncryptedPrivateKey Mono.Security.Cryptography.PKCS8.KeyInfo @static
---@field public Unknown Mono.Security.Cryptography.PKCS8.KeyInfo @static
---@field public value__ number
local m = {}

Mono.Security.Cryptography.PKCS8.KeyInfo = m
return m
