---@class System.Collections.Hashtable.HashKeys : System.Object
---@field public Count number
---@field public IsSynchronized boolean
---@field public SyncRoot any
local m = {}

---@virtual
---@param array System.Array
---@param arrayIndex number
function m:CopyTo(array, arrayIndex) end

---@virtual
---@return System.Collections.IEnumerator
function m:GetEnumerator() end

System.Collections.Hashtable.HashKeys = m
return m
