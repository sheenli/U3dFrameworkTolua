---@class System.ResolveEventArgs : System.EventArgs
---@field public Name string
local m = {}

System.ResolveEventArgs = m
return m
