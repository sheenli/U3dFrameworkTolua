---@class System.Boolean : System.ValueType
---@field public FalseString string @static
---@field public TrueString string @static
local m = {}

---@overload fun(value:boolean):number @virtual
---@virtual
---@param obj any
---@return number
function m:CompareTo(obj) end

---@overload fun(obj:boolean):boolean @virtual
---@virtual
---@param obj any
---@return boolean
function m:Equals(obj) end

---@virtual
---@return number
function m:GetHashCode() end

---@static
---@param value string
---@return boolean
function m.Parse(value) end

---@static
---@param value string
---@return boolean, System.Boolean
function m.TryParse(value) end

---@overload fun(provider:System.IFormatProvider):string @virtual
---@virtual
---@return string
function m:ToString() end

---@virtual
---@return System.TypeCode
function m:GetTypeCode() end

---@overload fun(message:string) @extension
---@extension
function m.MustBeTrue() end

---@overload fun(message:string) @extension
---@extension
function m.MustBeFalse() end

System.Boolean = m
return m
