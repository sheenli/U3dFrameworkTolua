---@class DelegateFactory.System_Comparison_TaskBase_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 TaskBase
---@param param1 TaskBase
---@return number
function m:Call(param0, param1) end

---@param param0 TaskBase
---@param param1 TaskBase
---@return number
function m:CallWithSelf(param0, param1) end

DelegateFactory.System_Comparison_TaskBase_Event = m
return m
