---@class FairyGUI_GObjectPoolWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_GObjectPoolWrap = m
return m
