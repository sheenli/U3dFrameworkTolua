---@class ComUtilWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

ComUtilWrap = m
return m
