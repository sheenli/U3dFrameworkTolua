---@class ServerResponseEvent : EventData_1_GameServerMsg_
local m = {}

ServerResponseEvent = m
return m
