---@class FairyGUI_GRichTextFieldWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_GRichTextFieldWrap = m
return m
