---@class FairyGUI_ControllerWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_ControllerWrap = m
return m
