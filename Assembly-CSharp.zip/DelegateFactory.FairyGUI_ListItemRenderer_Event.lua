---@class DelegateFactory.FairyGUI_ListItemRenderer_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 number
---@param param1 FairyGUI.GObject
function m:Call(param0, param1) end

---@param param0 number
---@param param1 FairyGUI.GObject
function m:CallWithSelf(param0, param1) end

DelegateFactory.FairyGUI_ListItemRenderer_Event = m
return m
