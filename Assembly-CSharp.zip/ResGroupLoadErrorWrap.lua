---@class ResGroupLoadErrorWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

ResGroupLoadErrorWrap = m
return m
