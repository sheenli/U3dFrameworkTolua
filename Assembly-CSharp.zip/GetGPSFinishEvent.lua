---@class GetGPSFinishEvent : EventData_1_GetGPSFinishEvent_GPSLocationInfo_
---@field public evenId string @static
local m = {}

GetGPSFinishEvent = m
return m
