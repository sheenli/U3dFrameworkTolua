---@class LocationAddressResultDataWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

LocationAddressResultDataWrap = m
return m
