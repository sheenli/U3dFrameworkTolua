---@class LuaInterface.LuaFunction.FuncData : System.ValueType
---@field public oldTop number
---@field public stackPos number
local m = {}

LuaInterface.LuaFunction.FuncData = m
return m
