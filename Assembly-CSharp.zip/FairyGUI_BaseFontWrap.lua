---@class FairyGUI_BaseFontWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_BaseFontWrap = m
return m
