---@class LogicNode.NodePack : System.ValueType
---@field public logicNode LogicNode
---@field public addOrRemove boolean
local m = {}

LogicNode.NodePack = m
return m
