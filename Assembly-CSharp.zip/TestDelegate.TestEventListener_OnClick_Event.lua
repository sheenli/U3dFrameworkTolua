---@class TestDelegate.TestEventListener_OnClick_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 UnityEngine.GameObject
function m:Call(param0) end

TestDelegate.TestEventListener_OnClick_Event = m
return m
