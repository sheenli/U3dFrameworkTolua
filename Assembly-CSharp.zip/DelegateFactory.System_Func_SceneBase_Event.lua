---@class DelegateFactory.System_Func_SceneBase_Event : LuaInterface.LuaDelegate
local m = {}

---@return SceneBase
function m:Call() end

---@return SceneBase
function m:CallWithSelf() end

DelegateFactory.System_Func_SceneBase_Event = m
return m
