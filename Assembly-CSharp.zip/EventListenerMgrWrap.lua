---@class EventListenerMgrWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

EventListenerMgrWrap = m
return m
