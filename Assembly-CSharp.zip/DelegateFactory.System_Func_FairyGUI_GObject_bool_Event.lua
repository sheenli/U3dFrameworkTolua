---@class DelegateFactory.System_Func_FairyGUI_GObject_bool_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 FairyGUI.GObject
---@return boolean
function m:Call(param0) end

---@param param0 FairyGUI.GObject
---@return boolean
function m:CallWithSelf(param0) end

DelegateFactory.System_Func_FairyGUI_GObject_bool_Event = m
return m
