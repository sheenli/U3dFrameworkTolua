---@class FairyGUI_GMovieClipWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_GMovieClipWrap = m
return m
