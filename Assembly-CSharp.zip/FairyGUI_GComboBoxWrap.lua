---@class FairyGUI_GComboBoxWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_GComboBoxWrap = m
return m
