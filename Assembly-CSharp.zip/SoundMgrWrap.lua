---@class SoundMgrWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

SoundMgrWrap = m
return m
