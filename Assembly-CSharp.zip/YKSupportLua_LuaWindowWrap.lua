---@class YKSupportLua_LuaWindowWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

YKSupportLua_LuaWindowWrap = m
return m
