---@class FairyGUI_GTextInputWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_GTextInputWrap = m
return m
