---@class ResMgrWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

ResMgrWrap = m
return m
