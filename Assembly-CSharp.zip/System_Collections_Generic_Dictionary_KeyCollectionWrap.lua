---@class System_Collections_Generic_Dictionary_KeyCollectionWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

System_Collections_Generic_Dictionary_KeyCollectionWrap = m
return m
