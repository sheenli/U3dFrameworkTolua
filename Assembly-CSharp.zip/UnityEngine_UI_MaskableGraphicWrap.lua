---@class UnityEngine_UI_MaskableGraphicWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_UI_MaskableGraphicWrap = m
return m
