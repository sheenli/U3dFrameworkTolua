---@class DG.Tweening.DOTweenCYInstruction.WaitForStart : UnityEngine.CustomYieldInstruction
---@field public keepWaiting boolean
local m = {}

DG.Tweening.DOTweenCYInstruction.WaitForStart = m
return m
