---@class EventData_1_GetGPSFinishEvent_GPSLocationInfo_ : EventData
local m = {}

EventData_1_GetGPSFinishEvent_GPSLocationInfo_ = m
return m
