---@class LuaInterface_LuaFieldWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

LuaInterface_LuaFieldWrap = m
return m
