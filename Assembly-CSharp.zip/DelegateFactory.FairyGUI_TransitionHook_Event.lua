---@class DelegateFactory.FairyGUI_TransitionHook_Event : LuaInterface.LuaDelegate
local m = {}

function m:Call() end

function m:CallWithSelf() end

DelegateFactory.FairyGUI_TransitionHook_Event = m
return m
