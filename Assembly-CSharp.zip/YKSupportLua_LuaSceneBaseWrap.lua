---@class YKSupportLua_LuaSceneBaseWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

YKSupportLua_LuaSceneBaseWrap = m
return m
