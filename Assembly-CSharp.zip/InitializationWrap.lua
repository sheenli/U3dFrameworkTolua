---@class InitializationWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

InitializationWrap = m
return m
