---@class System_Collections_Generic_List_UnityEngine_TransformWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

System_Collections_Generic_List_UnityEngine_TransformWrap = m
return m
