---@class DelegateFactory.System_Comparison_UnityEngine_GameObject_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 UnityEngine.GameObject
---@param param1 UnityEngine.GameObject
---@return number
function m:Call(param0, param1) end

---@param param0 UnityEngine.GameObject
---@param param1 UnityEngine.GameObject
---@return number
function m:CallWithSelf(param0, param1) end

DelegateFactory.System_Comparison_UnityEngine_GameObject_Event = m
return m
