---@class EventDispatcherNode.ListenerPack : System.ValueType
---@field public eventKey string
---@field public listener EventDispatcherNode.EventInfo
---@field public addOrRemove boolean
local m = {}

EventDispatcherNode.ListenerPack = m
return m
