---@class DG_Tweening_Core_ABSSequentiableWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

DG_Tweening_Core_ABSSequentiableWrap = m
return m
