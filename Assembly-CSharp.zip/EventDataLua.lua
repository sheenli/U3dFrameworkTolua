---@class EventDataLua : EventData
---@field public obj any
---@field public value any
local m = {}

EventDataLua = m
return m
