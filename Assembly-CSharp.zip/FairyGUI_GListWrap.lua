---@class FairyGUI_GListWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_GListWrap = m
return m
