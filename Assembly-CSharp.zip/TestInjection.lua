---@class TestInjection : UnityEngine.MonoBehaviour
local m = {}

TestInjection = m
return m
