---@class FairyGUI_EventListenerWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_EventListenerWrap = m
return m
