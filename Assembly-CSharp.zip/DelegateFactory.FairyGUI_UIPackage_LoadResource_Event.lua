---@class DelegateFactory.FairyGUI_UIPackage_LoadResource_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 string
---@param param1 string
---@param param2 System.Type
---@return any
function m:Call(param0, param1, param2) end

---@param param0 string
---@param param1 string
---@param param2 System.Type
---@return any
function m:CallWithSelf(param0, param1, param2) end

DelegateFactory.FairyGUI_UIPackage_LoadResource_Event = m
return m
