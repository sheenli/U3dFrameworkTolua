---@class LuaInterface.LuaObjectPool.PoolNode : System.Object
---@field public index number
---@field public obj any
local m = {}

LuaInterface.LuaObjectPool.PoolNode = m
return m
