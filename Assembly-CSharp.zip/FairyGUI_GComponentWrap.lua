---@class FairyGUI_GComponentWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_GComponentWrap = m
return m
