---@class SimplePool_1.CreateCallbackDelegate_T_ : System.MulticastDelegate
local m = {}

---@virtual
---@param type System.Type
---@return any
function m:Invoke(type) end

---@virtual
---@param type System.Type
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(type, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return any
function m:EndInvoke(result) end

SimplePool_1.CreateCallbackDelegate_T_ = m
return m
