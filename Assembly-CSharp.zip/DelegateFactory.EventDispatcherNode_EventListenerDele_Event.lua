---@class DelegateFactory.EventDispatcherNode_EventListenerDele_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 EventData
function m:Call(param0) end

---@param param0 EventData
function m:CallWithSelf(param0) end

DelegateFactory.EventDispatcherNode_EventListenerDele_Event = m
return m
