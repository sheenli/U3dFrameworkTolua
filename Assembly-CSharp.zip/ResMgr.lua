---@class ResMgr : EventDispatcherNode
---@field public Intstance ResMgr @static
local m = {}

function m:Awake() end

---@param assetName string
---@return UnityEngine.Object
function m:GetAsset(assetName) end

---@param abName string
---@return number
function m:GetABRefCount(abName) end

---@param assetName string
---@param callBack fun(obj:UnityEngine.Object)
function m:GetAssetAsync(assetName, callBack) end

---@overload fun(assteName:string)
---@overload fun(assteName:string, callBaclk:(fun(obj:UnityEngine.Object)))
---@overload fun(assteName:string)
---@overload fun(assetName:string, type:System.Type, callBaclk:(fun(obj:UnityEngine.Object)))
---@overload fun(assetName:string, type:System.Type)
---@param assteName string
---@param callBaclk fun(obj:UnityEngine.Object)
function m:LoadAsset(assteName, callBaclk) end

---@param ab UnityEngine.AssetBundle
---@param assteName string
---@param type System.Type
---@param callBack fun(obj:UnityEngine.Object)
---@return System.Collections.IEnumerator
function m:LoadAssetAsync(ab, assteName, type, callBack) end

---@param audioClip UnityEngine.AudioClip
---@param callBack fun()
---@return System.Collections.IEnumerator
function m:PrLoadAudioClip(audioClip, callBack) end

---@overload fun(abName:string)
---@param abName string
---@param callBack fun()
function m:LoadAll(abName, callBack) end

---@overload fun(groupName:string)
---@overload fun(groupData:ResGroupCfg, groupName:string, callback:(fun()))
---@overload fun(groupData:ResGroupCfg, groupName:string)
---@param groupName string
---@param callback fun()
function m:LoadGroup(groupName, callback) end

function m:LogAll() end

function m:PushRes() end

---@overload fun(assetName:string)
---@param assetName string
---@param immediate boolean
function m:UnLoadAsset(assetName, immediate) end

---@overload fun()
---@param forced boolean
function m:UnLoadAll(forced) end

---@return System.Collections.IEnumerator
function m:GC() end

function m:TryAddFairyGuiRes() end

---@overload fun(assetName:string)
---@overload fun()
---@param assetName string
---@param all boolean
function m:TryUnLoadFariryGUIRes(assetName, all) end

function m:Init() end

---@param assetName string
---@return string
function m:FindAssetPath(assetName) end

ResMgr = m
return m
