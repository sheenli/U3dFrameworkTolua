---@class FairyGUI_GImageWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_GImageWrap = m
return m
