---@class DelegateFactory.UnityEngine_Events_UnityAction_UnityEngine_SceneManagement_Scene_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 UnityEngine.SceneManagement.Scene
function m:Call(param0) end

---@param param0 UnityEngine.SceneManagement.Scene
function m:CallWithSelf(param0) end

DelegateFactory.UnityEngine_Events_UnityAction_UnityEngine_SceneManagement_Scene_Event = m
return m
