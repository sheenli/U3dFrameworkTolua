---@class FairyGUI_DragDropComMangerWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_DragDropComMangerWrap = m
return m
