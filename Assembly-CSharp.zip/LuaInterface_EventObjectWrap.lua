---@class LuaInterface_EventObjectWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

LuaInterface_EventObjectWrap = m
return m
