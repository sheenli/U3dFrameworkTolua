---@class DelegateFactory.FairyGUI_NGraphics_MeshModifier_Event : LuaInterface.LuaDelegate
local m = {}

function m:Call() end

function m:CallWithSelf() end

DelegateFactory.FairyGUI_NGraphics_MeshModifier_Event = m
return m
