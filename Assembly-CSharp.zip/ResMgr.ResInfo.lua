---@class ResMgr.ResInfo : ResInfoData
---@field public asset UnityEngine.Object
local m = {}

ResMgr.ResInfo = m
return m
