---@class StateMachineWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

StateMachineWrap = m
return m
