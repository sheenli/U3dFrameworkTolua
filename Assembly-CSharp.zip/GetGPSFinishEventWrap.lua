---@class GetGPSFinishEventWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

GetGPSFinishEventWrap = m
return m
