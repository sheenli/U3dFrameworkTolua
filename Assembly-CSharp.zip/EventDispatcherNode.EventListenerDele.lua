---@class EventDispatcherNode.EventListenerDele : System.MulticastDelegate
local m = {}

---@virtual
---@param data EventData
function m:Invoke(data) end

---@virtual
---@param data EventData
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(data, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

EventDispatcherNode.EventListenerDele = m
return m
