---@class SimplePoolObject : SimplePool_1_UnityEngine_Object_
local m = {}

---@virtual
function m:Clear() end

---@virtual
---@return UnityEngine.Object
function m:Get() end

---@virtual
---@param obj UnityEngine.Object
function m:Pop(obj) end

SimplePoolObject = m
return m
