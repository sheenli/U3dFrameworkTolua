---@class TestUTF8 : LuaClient
local m = {}

TestUTF8 = m
return m
