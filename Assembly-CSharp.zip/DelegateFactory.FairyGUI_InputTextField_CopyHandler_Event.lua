---@class DelegateFactory.FairyGUI_InputTextField_CopyHandler_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 FairyGUI.InputTextField
---@param param1 string
function m:Call(param0, param1) end

---@param param0 FairyGUI.InputTextField
---@param param1 string
function m:CallWithSelf(param0, param1) end

DelegateFactory.FairyGUI_InputTextField_CopyHandler_Event = m
return m
