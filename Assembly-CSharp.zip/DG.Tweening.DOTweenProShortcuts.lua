---@class DG.Tweening.DOTweenProShortcuts : System.Object
local m = {}

---@overload fun(target:UnityEngine.Transform, duration:number, axis:System.Nullable_1_UnityEngine_Vector3_, mode:DG.Tweening.SpiralMode, speed:number, frequency:number, depth:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, axis:System.Nullable_1_UnityEngine_Vector3_, mode:DG.Tweening.SpiralMode, speed:number, frequency:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, axis:System.Nullable_1_UnityEngine_Vector3_, mode:DG.Tweening.SpiralMode, speed:number):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, axis:System.Nullable_1_UnityEngine_Vector3_, mode:DG.Tweening.SpiralMode):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number, axis:System.Nullable_1_UnityEngine_Vector3_):DG.Tweening.Tweener @static
---@overload fun(target:UnityEngine.Transform, duration:number):DG.Tweening.Tweener @static
---@static
---@param target UnityEngine.Transform
---@param duration number
---@param axis System.Nullable_1_UnityEngine_Vector3_
---@param mode DG.Tweening.SpiralMode
---@param speed number
---@param frequency number
---@param depth number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOSpiral(target, duration, axis, mode, speed, frequency, depth, snapping) end

DG.Tweening.DOTweenProShortcuts = m
return m
