---@class DelegateFactory.FairyGUI_EventCallback0_Event : LuaInterface.LuaDelegate
local m = {}

function m:Call() end

function m:CallWithSelf() end

DelegateFactory.FairyGUI_EventCallback0_Event = m
return m
