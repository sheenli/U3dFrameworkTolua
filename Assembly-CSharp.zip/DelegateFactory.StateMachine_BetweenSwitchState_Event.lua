---@class DelegateFactory.StateMachine_BetweenSwitchState_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 IState
---@param param1 IState
---@param param2 any
---@param param3 any
function m:Call(param0, param1, param2, param3) end

---@param param0 IState
---@param param1 IState
---@param param2 any
---@param param3 any
function m:CallWithSelf(param0, param1, param2, param3) end

DelegateFactory.StateMachine_BetweenSwitchState_Event = m
return m
