---@class DelegateFactory.FairyGUI_ListItemProvider_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 number
---@return string
function m:Call(param0) end

---@param param0 number
---@return string
function m:CallWithSelf(param0) end

DelegateFactory.FairyGUI_ListItemProvider_Event = m
return m
