---@class UnityEngine_UI_GraphicWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_UI_GraphicWrap = m
return m
