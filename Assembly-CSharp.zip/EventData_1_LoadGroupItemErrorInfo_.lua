---@class EventData_1_LoadGroupItemErrorInfo_ : EventData
local m = {}

EventData_1_LoadGroupItemErrorInfo_ = m
return m
