---@class DelegateFactory.FairyGUI_PlayCompleteCallback_Event : LuaInterface.LuaDelegate
local m = {}

function m:Call() end

function m:CallWithSelf() end

DelegateFactory.FairyGUI_PlayCompleteCallback_Event = m
return m
