---@class FairyGUI_RelationTypeWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_RelationTypeWrap = m
return m
