---@class FairyGUI_CaptureCameraWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_CaptureCameraWrap = m
return m
