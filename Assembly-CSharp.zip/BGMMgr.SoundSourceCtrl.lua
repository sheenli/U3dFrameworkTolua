---@class BGMMgr.SoundSourceCtrl : System.Object
---@field public audioSoure UnityEngine.AudioSource
---@field public status BGMMgr.SoundSourceCtrl.BGMSourceStatus
---@field public updateTimeAccum number
---@field public curMusicName string
---@field public index number
local m = {}

---@param clip UnityEngine.AudioClip
function m:InitFadeIn(clip) end

function m:InitFadeOut() end

function m:Release() end

BGMMgr.SoundSourceCtrl = m
return m
