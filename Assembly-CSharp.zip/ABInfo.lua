---@class ABInfo : System.Object
---@field public fileName string
---@field public sha1 string
---@field public length number
---@field public assets string[]
local m = {}

---@virtual
---@return string
function m:ToString() end

---@param remotely ABInfo
---@return boolean
function m:IsSame(remotely) end

ABInfo = m
return m
