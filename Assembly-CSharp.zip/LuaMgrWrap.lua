---@class LuaMgrWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

LuaMgrWrap = m
return m
