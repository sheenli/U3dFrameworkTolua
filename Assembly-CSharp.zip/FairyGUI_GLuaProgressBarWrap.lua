---@class FairyGUI_GLuaProgressBarWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_GLuaProgressBarWrap = m
return m
