---@class ILogic : table
---@field public IsValid boolean
---@field public Parent LogicNode
local m = {}

---@abstract
function m:OnUpdate() end

---@abstract
function m:OnLateUpdate() end

---@abstract
function m:OnFixedUpdate() end

---@abstract
function m:OnApplicationQuit() end

---@abstract
---@param pauseStatus boolean
function m:OnApplicationPause(pauseStatus) end

---@abstract
function m:OnDestroy() end

---@abstract
function m:OnEnable() end

---@abstract
function m:OnDisable() end

ILogic = m
return m
