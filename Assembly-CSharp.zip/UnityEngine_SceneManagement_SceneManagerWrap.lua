---@class UnityEngine_SceneManagement_SceneManagerWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_SceneManagement_SceneManagerWrap = m
return m
