---@class FairyGUI_InputEventWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_InputEventWrap = m
return m
