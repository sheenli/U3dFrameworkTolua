---@class EventData_GetGPSFinishEvent_GPSLocationInfoWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

EventData_GetGPSFinishEvent_GPSLocationInfoWrap = m
return m
