---@class ResGroupLoadError : EventData_1_System_String_
---@field public eventName string @static
local m = {}

ResGroupLoadError = m
return m
