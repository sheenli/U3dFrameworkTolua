---@class DelegateFactory : System.Object
---@field public dict table<System.Type, fun(func:LuaInterface.LuaFunction, self:LuaInterface.LuaTable, flag:boolean):(fun(args:any[]):any)> @static
local m = {}

---@static
function m.Init() end

---@static
function m.Register() end

---@overload fun(t:System.Type):(fun(args:any[]):any) @static
---@overload fun(t:System.Type, func:LuaInterface.LuaFunction, self:LuaInterface.LuaTable):(fun(args:any[]):any) @static
---@static
---@param t System.Type
---@param func LuaInterface.LuaFunction
---@return fun(args:any[]):any
function m.CreateDelegate(t, func) end

---@overload fun(obj:(fun(args:any[]):any), dg:(fun(args:any[]):any)):(fun(args:any[]):any) @static
---@static
---@param obj fun(args:any[]):any
---@param func LuaInterface.LuaFunction
---@return fun(args:any[]):any
function m.RemoveDelegate(obj, func) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun()
function m:System_Action(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun()
function m:UnityEngine_Events_UnityAction(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:number):boolean
function m:System_Predicate_int(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:number)
function m:System_Action_int(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(x:number, y:number):number
function m:System_Comparison_int(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(arg1:number):number
function m:System_Func_int_int(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:string)
function m:System_Action_string(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(arg1:FairyGUI.GObject):boolean
function m:System_Func_FairyGUI_GObject_bool(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(context:FairyGUI.EventContext)
function m:FairyGUI_EventCallback1(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun()
function m:FairyGUI_EventCallback0(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(data:EventData)
function m:EventDispatcherNode_EventListenerDele(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:GetGPSFinishEvent.GPSLocationInfo)
function m:System_Action_GetGPSFinishEvent_GPSLocationInfo(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:UnityEngine.Object)
function m:System_Action_UnityEngine_Object(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:LocationAddressResultData)
function m:System_Action_LocationAddressResultData(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:UnityEngine.AssetBundle)
function m:System_Action_UnityEngine_AssetBundle(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:AsynTask)
function m:System_Action_AsynTask(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:TaskBase[])
function m:System_Action_System_Collections_Generic_List_TaskBase(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(index:number, item:FairyGUI.GObject)
function m:FairyGUI_ListItemRenderer(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(index:number):string
function m:FairyGUI_ListItemProvider(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(cam:UnityEngine.Camera)
function m:UnityEngine_Camera_CameraCallback(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun()
function m:UnityEngine_Application_LowMemoryCallback(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(advertisingId:string, trackingEnabled:boolean, errorMsg:string)
function m:UnityEngine_Application_AdvertisingIdentifierCallback(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(condition:string, stackTrace:string, type:UnityEngine.LogType)
function m:UnityEngine_Application_LogCallback(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(data:number[])
function m:UnityEngine_AudioClip_PCMReaderCallback(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(position:number)
function m:UnityEngine_AudioClip_PCMSetPositionCallback(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun():number
function m:DG_Tweening_Core_DOGetter_float(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(pNewValue:number)
function m:DG_Tweening_Core_DOSetter_float(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun()
function m:DG_Tweening_TweenCallback(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(value:number)
function m:DG_Tweening_TweenCallback_int(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:string):boolean
function m:System_Predicate_string(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(x:string, y:string):number
function m:System_Comparison_string(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:UnityEngine.Transform):boolean
function m:System_Predicate_UnityEngine_Transform(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:UnityEngine.Transform)
function m:System_Action_UnityEngine_Transform(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(x:UnityEngine.Transform, y:UnityEngine.Transform):number
function m:System_Comparison_UnityEngine_Transform(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:UnityEngine.GameObject):boolean
function m:System_Predicate_UnityEngine_GameObject(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:UnityEngine.GameObject)
function m:System_Action_UnityEngine_GameObject(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(x:UnityEngine.GameObject, y:UnityEngine.GameObject):number
function m:System_Comparison_UnityEngine_GameObject(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:TaskBase):boolean
function m:System_Predicate_TaskBase(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:TaskBase)
function m:System_Action_TaskBase(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(x:TaskBase, y:TaskBase):number
function m:System_Comparison_TaskBase(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:FairyGUI.Controller):boolean
function m:System_Predicate_FairyGUI_Controller(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:FairyGUI.Controller)
function m:System_Action_FairyGUI_Controller(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(x:FairyGUI.Controller, y:FairyGUI.Controller):number
function m:System_Comparison_FairyGUI_Controller(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(arg0:UnityEngine.SceneManagement.Scene, arg1:UnityEngine.SceneManagement.LoadSceneMode)
function m:UnityEngine_Events_UnityAction_UnityEngine_SceneManagement_Scene_UnityEngine_SceneManagement_LoadSceneMode(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(arg0:UnityEngine.SceneManagement.Scene)
function m:UnityEngine_Events_UnityAction_UnityEngine_SceneManagement_Scene(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(arg0:UnityEngine.SceneManagement.Scene, arg1:UnityEngine.SceneManagement.Scene)
function m:UnityEngine_Events_UnityAction_UnityEngine_SceneManagement_Scene_UnityEngine_SceneManagement_Scene(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(textField:FairyGUI.InputTextField, text:string)
function m:FairyGUI_InputTextField_CopyHandler(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(textField:FairyGUI.InputTextField)
function m:FairyGUI_InputTextField_PasteHandler(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun()
function m:FairyGUI_PlayCompleteCallback(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun()
function m:FairyGUI_TransitionHook(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(name:string, extension:string, type:System.Type):any
function m:FairyGUI_UIPackage_LoadResource(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(result:FairyGUI.GObject)
function m:FairyGUI_UIPackage_CreateObjectCallback(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:FairyGUI.GObject)
function m:FairyGUI_GObjectPool_InitCallbackDelegate(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(param:any)
function m:FairyGUI_TimerCallback(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(url:string):UnityEngine.AudioClip
function m:FairyGUI_UIConfig_SoundLoader(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun():BaseUI
function m:System_Func_BaseUI(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:BaseUI)
function m:System_Action_BaseUI(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:ITask)
function m:System_Action_ITask(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(arg1:string, arg2:string)
function m:System_Action_string_string(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun():SceneBase
function m:System_Func_SceneBase(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:UnityEngine.WWW)
function m:System_Action_UnityEngine_WWW(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(from:IState, to:IState, param1:any, param2:any)
function m:StateMachine_BetweenSwitchState(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun(obj:HotUpdateRessMgr.DecompressionOrDownInfo)
function m:System_Action_HotUpdateRessMgr_DecompressionOrDownInfo(func, self, flag) end

---@param func LuaInterface.LuaFunction
---@param self LuaInterface.LuaTable
---@param flag boolean
---@return fun()
function m:FairyGUI_NGraphics_MeshModifier(func, self, flag) end

DelegateFactory = m
return m
