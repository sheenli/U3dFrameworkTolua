---@class UnityEngine_UI_TextWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_UI_TextWrap = m
return m
