---@class FairyGUI_PopupMenuWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_PopupMenuWrap = m
return m
