---@class HelloWorld : UnityEngine.MonoBehaviour
local m = {}

HelloWorld = m
return m
