---@class LuaInterface_LuaConstructorWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

LuaInterface_LuaConstructorWrap = m
return m
