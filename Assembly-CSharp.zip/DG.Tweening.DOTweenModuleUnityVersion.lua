---@class DG.Tweening.DOTweenModuleUnityVersion : System.Object
local m = {}

---@overload fun(target:UnityEngine.Material, gradient:UnityEngine.Gradient, property:string, duration:number):DG.Tweening.Sequence @static
---@static
---@param target UnityEngine.Material
---@param gradient UnityEngine.Gradient
---@param duration number
---@return DG.Tweening.Sequence
function m.DOGradientColor(target, gradient, duration) end

---@static
---@param t DG.Tweening.Tween
---@param returnCustomYieldInstruction boolean
---@return UnityEngine.CustomYieldInstruction
function m.WaitForCompletion(t, returnCustomYieldInstruction) end

---@static
---@param t DG.Tweening.Tween
---@param returnCustomYieldInstruction boolean
---@return UnityEngine.CustomYieldInstruction
function m.WaitForRewind(t, returnCustomYieldInstruction) end

---@static
---@param t DG.Tweening.Tween
---@param returnCustomYieldInstruction boolean
---@return UnityEngine.CustomYieldInstruction
function m.WaitForKill(t, returnCustomYieldInstruction) end

---@static
---@param t DG.Tweening.Tween
---@param elapsedLoops number
---@param returnCustomYieldInstruction boolean
---@return UnityEngine.CustomYieldInstruction
function m.WaitForElapsedLoops(t, elapsedLoops, returnCustomYieldInstruction) end

---@static
---@param t DG.Tweening.Tween
---@param position number
---@param returnCustomYieldInstruction boolean
---@return UnityEngine.CustomYieldInstruction
function m.WaitForPosition(t, position, returnCustomYieldInstruction) end

---@static
---@param t DG.Tweening.Tween
---@param returnCustomYieldInstruction boolean
---@return UnityEngine.CustomYieldInstruction
function m.WaitForStart(t, returnCustomYieldInstruction) end

DG.Tweening.DOTweenModuleUnityVersion = m
return m
