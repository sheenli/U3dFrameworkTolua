---@class FairyGUI_DisplayObjectWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_DisplayObjectWrap = m
return m
