---@class System_Collections_Generic_List_TaskBaseWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

System_Collections_Generic_List_TaskBaseWrap = m
return m
