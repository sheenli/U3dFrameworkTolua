---@class BaseUIWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

BaseUIWrap = m
return m
