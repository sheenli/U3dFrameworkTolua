---@class DelegateFactory.UnityEngine_Events_UnityAction_UnityEngine_SceneManagement_Scene_UnityEngine_SceneManagement_Scene_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 UnityEngine.SceneManagement.Scene
---@param param1 UnityEngine.SceneManagement.Scene
function m:Call(param0, param1) end

---@param param0 UnityEngine.SceneManagement.Scene
---@param param1 UnityEngine.SceneManagement.Scene
function m:CallWithSelf(param0, param1) end

DelegateFactory.UnityEngine_Events_UnityAction_UnityEngine_SceneManagement_Scene_UnityEngine_SceneManagement_Scene_Event = m
return m
