---@class YKSupportLua_LuaStateBaseWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

YKSupportLua_LuaStateBaseWrap = m
return m
