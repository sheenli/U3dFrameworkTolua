---@class FairyGUI_EventDispatcherWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_EventDispatcherWrap = m
return m
