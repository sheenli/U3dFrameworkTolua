---@class EventData_1_ErrorData_ : EventData
local m = {}

EventData_1_ErrorData_ = m
return m
