---@class UnityEngine_SphereColliderWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_SphereColliderWrap = m
return m
