---@class YKSupportLua_LuaUBBParserWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

YKSupportLua_LuaUBBParserWrap = m
return m
