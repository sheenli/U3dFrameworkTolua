---@class FairyGUI_NGraphicsWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_NGraphicsWrap = m
return m
