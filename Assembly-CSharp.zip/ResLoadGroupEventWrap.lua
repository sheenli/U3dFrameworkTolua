---@class ResLoadGroupEventWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

ResLoadGroupEventWrap = m
return m
