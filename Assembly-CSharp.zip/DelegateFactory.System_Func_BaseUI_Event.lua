---@class DelegateFactory.System_Func_BaseUI_Event : LuaInterface.LuaDelegate
local m = {}

---@return BaseUI
function m:Call() end

---@return BaseUI
function m:CallWithSelf() end

DelegateFactory.System_Func_BaseUI_Event = m
return m
