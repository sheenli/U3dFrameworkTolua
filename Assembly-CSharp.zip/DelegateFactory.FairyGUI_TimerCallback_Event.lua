---@class DelegateFactory.FairyGUI_TimerCallback_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 any
function m:Call(param0) end

---@param param0 any
function m:CallWithSelf(param0) end

DelegateFactory.FairyGUI_TimerCallback_Event = m
return m
