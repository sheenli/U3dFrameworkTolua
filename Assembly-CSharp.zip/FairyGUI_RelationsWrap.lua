---@class FairyGUI_RelationsWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_RelationsWrap = m
return m
