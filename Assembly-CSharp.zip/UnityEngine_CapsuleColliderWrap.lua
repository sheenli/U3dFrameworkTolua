---@class UnityEngine_CapsuleColliderWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_CapsuleColliderWrap = m
return m
