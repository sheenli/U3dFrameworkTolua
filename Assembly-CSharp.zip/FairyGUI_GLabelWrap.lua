---@class FairyGUI_GLabelWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_GLabelWrap = m
return m
