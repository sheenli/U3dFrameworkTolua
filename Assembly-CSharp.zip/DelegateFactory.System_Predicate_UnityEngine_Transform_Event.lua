---@class DelegateFactory.System_Predicate_UnityEngine_Transform_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 UnityEngine.Transform
---@return boolean
function m:Call(param0) end

---@param param0 UnityEngine.Transform
---@return boolean
function m:CallWithSelf(param0) end

DelegateFactory.System_Predicate_UnityEngine_Transform_Event = m
return m
