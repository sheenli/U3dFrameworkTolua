---@class DelegateFactory.DG_Tweening_TweenCallback_Event : LuaInterface.LuaDelegate
local m = {}

function m:Call() end

function m:CallWithSelf() end

DelegateFactory.DG_Tweening_TweenCallback_Event = m
return m
