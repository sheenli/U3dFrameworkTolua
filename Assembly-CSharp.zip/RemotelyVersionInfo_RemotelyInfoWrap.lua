---@class RemotelyVersionInfo_RemotelyInfoWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

RemotelyVersionInfo_RemotelyInfoWrap = m
return m
