---@class System_NullObjectWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

System_NullObjectWrap = m
return m
