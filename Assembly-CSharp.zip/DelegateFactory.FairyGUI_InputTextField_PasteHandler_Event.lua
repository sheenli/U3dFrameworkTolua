---@class DelegateFactory.FairyGUI_InputTextField_PasteHandler_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 FairyGUI.InputTextField
function m:Call(param0) end

---@param param0 FairyGUI.InputTextField
function m:CallWithSelf(param0) end

DelegateFactory.FairyGUI_InputTextField_PasteHandler_Event = m
return m
