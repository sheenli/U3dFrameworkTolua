---@class FairyGUI_Utils_UBBParserWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_Utils_UBBParserWrap = m
return m
