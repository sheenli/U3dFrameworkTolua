---@class UnityEngine_RenderSettingsWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_RenderSettingsWrap = m
return m
