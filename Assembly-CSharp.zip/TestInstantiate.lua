---@class TestInstantiate : UnityEngine.MonoBehaviour
local m = {}

TestInstantiate = m
return m
