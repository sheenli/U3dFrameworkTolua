---@class DelegateFactory.System_Comparison_string_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 string
---@param param1 string
---@return number
function m:Call(param0, param1) end

---@param param0 string
---@param param1 string
---@return number
function m:CallWithSelf(param0, param1) end

DelegateFactory.System_Comparison_string_Event = m
return m
