---@class UnityEngine_KeyCodeWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_KeyCodeWrap = m
return m
