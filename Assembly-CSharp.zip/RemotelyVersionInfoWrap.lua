---@class RemotelyVersionInfoWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

RemotelyVersionInfoWrap = m
return m
