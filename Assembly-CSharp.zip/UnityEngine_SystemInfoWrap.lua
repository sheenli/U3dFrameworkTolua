---@class UnityEngine_SystemInfoWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_SystemInfoWrap = m
return m
