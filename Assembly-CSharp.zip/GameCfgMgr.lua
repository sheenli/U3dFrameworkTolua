---@class GameCfgMgr : System.Object
---@field public Instance GameCfgMgr @static
---@field public localGameCfg LocalGameCfgData
---@field public resCfg ResCfg
local m = {}

---@param assetName string
---@return ResInfoData
function m:GetResInfo(assetName) end

---@param groupName string
---@return ResGroupCfg
function m:GetGroupInfo(groupName) end

---@param groupData ResGroupCfg
---@return System.Collections.Generic.Dictionary_2_System_String_System_Collections_Generic_List_1_ResInfoData__
function m:GetGroupABs(groupData) end

function m:Init() end

function m:LoadResCfg() end

GameCfgMgr = m
return m
