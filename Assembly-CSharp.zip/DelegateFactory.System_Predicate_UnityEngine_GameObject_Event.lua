---@class DelegateFactory.System_Predicate_UnityEngine_GameObject_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 UnityEngine.GameObject
---@return boolean
function m:Call(param0) end

---@param param0 UnityEngine.GameObject
---@return boolean
function m:CallWithSelf(param0) end

DelegateFactory.System_Predicate_UnityEngine_GameObject_Event = m
return m
