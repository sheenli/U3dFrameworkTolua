---@class LuaInterface.LuaThread : LuaInterface.LuaBaseRef
local m = {}

---@overload fun(arg1:any):number
---@overload fun(arg1:any, arg2:any):number
---@overload fun(arg1:any, arg2:any, arg3:any):number
---@overload fun():number, any
---@overload fun(arg1:any):number, any
---@overload fun(arg1:any, arg2:any):number, any
---@overload fun(arg1:any, arg2:any, arg3:any):number, any
---@return number
function m:Resume() end

LuaInterface.LuaThread = m
return m
