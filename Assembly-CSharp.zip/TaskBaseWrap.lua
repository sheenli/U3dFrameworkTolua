---@class TaskBaseWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

TaskBaseWrap = m
return m
