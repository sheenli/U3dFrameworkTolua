---@class UnityEngine_QueueModeWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_QueueModeWrap = m
return m
