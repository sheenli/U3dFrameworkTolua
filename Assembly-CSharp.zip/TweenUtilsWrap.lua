---@class TweenUtilsWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

TweenUtilsWrap = m
return m
