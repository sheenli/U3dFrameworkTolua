---@class GetGPSFinishEvent_GPSLocationInfoWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

GetGPSFinishEvent_GPSLocationInfoWrap = m
return m
