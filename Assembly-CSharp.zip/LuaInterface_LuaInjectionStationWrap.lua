---@class LuaInterface_LuaInjectionStationWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

LuaInterface_LuaInjectionStationWrap = m
return m
