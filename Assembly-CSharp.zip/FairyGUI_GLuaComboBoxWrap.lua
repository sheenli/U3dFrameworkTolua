---@class FairyGUI_GLuaComboBoxWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_GLuaComboBoxWrap = m
return m
