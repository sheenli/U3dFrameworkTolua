---@class FairyGUI_GGroupWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_GGroupWrap = m
return m
