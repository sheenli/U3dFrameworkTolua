---@class SimplePool_1_T_ : System.Object
---@field public initCallback fun(obj:any)
---@field public returnCallback fun(obj:any)
---@field public createCallback fun(type:System.Type):any
local m = {}

---@virtual
function m:Clear() end

---@virtual
---@return any
function m:Get() end

---@virtual
---@param obj any
function m:Pop(obj) end

SimplePool_1_T_ = m
return m
