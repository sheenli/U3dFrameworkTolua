---@class TestInstantiate2 : UnityEngine.MonoBehaviour
local m = {}

TestInstantiate2 = m
return m
