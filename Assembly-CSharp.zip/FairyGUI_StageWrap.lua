---@class FairyGUI_StageWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

FairyGUI_StageWrap = m
return m
